نظام OpenSubtitles لمشروع AFVeo

ضع الملفات بنفس المسارات (player.js هنا يستبدل النسخة السابقة، ولا تحتاج ملفات مصدر ScarperApi):
  includes/opensubtitles.php        بحث + ترتيب النسخ + تسجيل الدخول + تحميل وتحويل SRT->VTT + كاش
  api/opensubtitles.php             يرجع أفضل النسخ لكل لغة للمشغّل
  api/opensubtitles_file.php        يقدّم ملف VTT (موقّع بـ HMAC، ويحمّل من OpenSubtitles مرة واحدة فقط)
  player/src/core/player.js         (معدّل) يعتمد OpenSubtitles فقط ويرجع للمصادر الأخرى إذا لم يجد شيئاً
  storage/opensubtitles/            مجلد الملفات المحمّلة (كاش دائم)

المتغيرات المطلوبة:
  OPENSUBTITLES_API_KEY , OPENSUBTITLES_USERNAME , OPENSUBTITLES_PASSWORD

الإعدادات في أعلى includes/opensubtitles.php:
  OS_LANGUAGES = 'ar,en'   اللغات
  OS_MAX_PER_LANG = 3      عدد النسخ المرسلة لكل لغة (كل نسخة تُحمَّل مرة واحدة وتُخزَّن)

التشخيص إذا ما ظهرت الترجمات:
  افتح في المتصفح:  /api/opensubtitles.php?type=movie&id=550
  الحقل reason يوضح السبب:
    not_configured_api_key / not_configured_username_password  -> المتغيرات ناقصة
    login_failed                                               -> اسم المستخدم أو كلمة السر خطأ
    search_http_401 / search_http_403                          -> مفتاح API غير صالح
    no_results                                                 -> لا توجد ترجمة لهذا العنوان
    quota_exhausted                                            -> انتهت حصة التحميل اليوم
