<?php
require_once __DIR__ . '/common.php';
$code = wp_code((string)($_GET['code'] ?? $_POST['code'] ?? ''));
if (!preg_match('/^AFV-[A-Z0-9]{5}$/', $code)) wp_json(['ok'=>false,'error'=>'Invalid room code'], 422);
if (!sec_rate_limit('watch-party-state:' . get_client_ip(), 180, 60)) sec_rate_block('state');
$rooms = wp_read(); wp_cleanup($rooms); $room = wp_find($rooms, $code);
if (!$room) wp_json(['ok'=>false,'error'=>'Room not found or expired'], 404);
$id = wp_member_id(); $now = time();
if (!isset($room['members'][$id])) $room['members'][$id] = ['id'=>$id,'name'=>'Guest','last_seen'=>$now];
else $room['members'][$id]['last_seen'] = $now;
$room['updated_at'] = $now; $rooms[$code] = $room; wp_write($rooms);
wp_json(['ok'=>true,'room'=>wp_public($room),'member_id'=>$id,'is_host'=>$room['host_id'] === $id]);
