<?php
/** AFVeo Watch Party — PHP polling backend. */
require_once __DIR__ . '/../config.php';

function wp_json(array $payload, int $status = 200): never {
    http_response_code($status);
    sec_api_headers();
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function wp_require_post(): void {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') wp_json(['ok'=>false,'error'=>'POST required'], 405);
    sec_assert_same_origin();
    if (!sec_rate_limit('watch-party:' . get_client_ip(), 120, 60)) sec_rate_block('watch-party');
    if (!sec_csrf_verify()) wp_json(['ok'=>false,'error'=>'Invalid CSRF token'], 419);
}

function wp_input(): array {
    $raw = file_get_contents('php://input');
    $json = json_decode($raw ?: '', true);
    return is_array($json) ? $json : $_POST;
}

function wp_code(string $value): string {
    return strtoupper(trim(substr($value, 0, 12)));
}

function wp_member_id(): string {
    return hash_hmac('sha256', session_id() . '|' . get_client_ip(), APP_SECRET);
}

function wp_name(array $input): string {
    $user = auth_user();
    $name = $user['username'] ?? ($input['name'] ?? 'Guest');
    $name = trim(preg_replace('/[^\p{L}\p{N}_ .-]/u', '', (string)$name));
    return substr($name ?: 'Guest', 0, 40);
}

function wp_file(): string {
    $dir = DATA_DIR . '/watch_party';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    return $dir . '/rooms.json';
}

function wp_read(): array {
    $file = wp_file();
    if (!is_file($file)) return [];
    $fp = fopen($file, 'rb');
    if (!$fp) return [];
    flock($fp, LOCK_SH);
    $data = json_decode(stream_get_contents($fp) ?: '', true);
    flock($fp, LOCK_UN); fclose($fp);
    return is_array($data) ? $data : [];
}

function wp_write(array $rooms): void {
    $file = wp_file();
    $tmp = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
    file_put_contents($tmp, json_encode($rooms, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
    @chmod($tmp, 0640);
    @rename($tmp, $file);
}

function wp_cleanup(array &$rooms): void {
    $now = time();
    foreach ($rooms as $code => &$room) {
        $members = $room['members'] ?? [];
        foreach ($members as $id => $member) {
            if ($now - (int)($member['last_seen'] ?? 0) > 35) unset($members[$id]);
        }
        if (!$members || $now - (int)($room['updated_at'] ?? 0) > 86400) {
            unset($rooms[$code]); continue;
        }
        if (!isset($members[$room['host_id']])) {
            $next = reset($members);
            $room['host_id'] = $next['id'];
        }
        $room['members'] = $members;
    }
    unset($room);
}

function wp_public(array $room): array {
    $members = array_values($room['members'] ?? []);
    return [
        'code' => $room['code'],
        'host_id' => $room['host_id'],
        'host_name' => $room['members'][$room['host_id']]['name'] ?? 'Host',
        'members' => array_map(fn($m) => ['id'=>$m['id'], 'name'=>$m['name']], $members),
        'member_count' => count($members),
        'state' => $room['state'],
        'updated_at' => $room['updated_at'],
    ];
}

function wp_find(array $rooms, string $code): ?array {
    return ($code && isset($rooms[$code]) && is_array($rooms[$code])) ? $rooms[$code] : null;
}

function wp_state_from_input(array $input, array $old): array {
    $state = $old;
    $type = strtolower((string)($input['event'] ?? $input['type'] ?? 'sync'));
    $position = (float)($input['position'] ?? $old['position'] ?? 0);
    $position = max(0, min($position, 86400));
    if (in_array($type, ['play','pause','seek','episode','sync'], true)) {
        $state['playing'] = $type === 'play' ? true : ($type === 'pause' ? false : (bool)($input['playing'] ?? $old['playing']));
        $state['position'] = $position;
        if ($type === 'episode') $state['episode'] = substr(trim((string)($input['episode'] ?? '')), 0, 120);
        if (isset($input['video'])) $state['video'] = substr(trim((string)$input['video']), 0, 160);
        $state['event'] = $type;
        $state['revision'] = (int)($old['revision'] ?? 0) + 1;
    }
    return $state;
}
