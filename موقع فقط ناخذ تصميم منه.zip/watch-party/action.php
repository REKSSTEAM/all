<?php
require_once __DIR__ . '/common.php';
wp_require_post();
$input = wp_input(); $code = wp_code((string)($input['code'] ?? ''));
if (!preg_match('/^AFV-[A-Z0-9]{5}$/', $code)) wp_json(['ok'=>false,'error'=>'Invalid room code'], 422);
$rooms = wp_read(); wp_cleanup($rooms); $room = wp_find($rooms, $code);
if (!$room) wp_json(['ok'=>false,'error'=>'Room not found or expired'], 404);
$id = wp_member_id(); $now = time();
if (!isset($room['members'][$id])) wp_json(['ok'=>false,'error'=>'Not a room member'], 403);
$room['members'][$id]['last_seen'] = $now;
if (($room['host_id'] ?? '') !== $id) wp_json(['ok'=>false,'error'=>'Only the Host can control playback'], 403);
$room['state'] = wp_state_from_input($input, $room['state'] ?? []);
$room['updated_at'] = $now; $rooms[$code] = $room; wp_write($rooms);
wp_json(['ok'=>true,'room'=>wp_public($room),'member_id'=>$id,'is_host'=>true]);
