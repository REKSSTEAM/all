<?php
require_once __DIR__ . '/common.php';
wp_require_post();
$input = wp_input();
$rooms = wp_read(); wp_cleanup($rooms);
$code = '';
for ($i = 0; $i < 8; $i++) {
    $candidate = 'AFV-' . substr(strtoupper(bin2hex(random_bytes(4))), 0, 5);
    if (!isset($rooms[$candidate])) { $code = $candidate; break; }
}
if (!$code) wp_json(['ok'=>false,'error'=>'Could not create room'], 503);
$id = wp_member_id();
$now = time();
$rooms[$code] = [
    'code'=>$code, 'host_id'=>$id, 'created_at'=>$now, 'updated_at'=>$now,
    'members'=>[$id=>['id'=>$id,'name'=>wp_name($input),'last_seen'=>$now]],
    'state'=>[
        'event'=>'sync','playing'=>false,'position'=>0,'episode'=>substr(trim((string)($input['episode'] ?? '')),0,120),
        'video'=>substr(trim((string)($input['video'] ?? '')),0,160),'revision'=>1,
        'media_type'=>in_array(($input['type'] ?? ''), ['movie','tv'], true) ? $input['type'] : '',
        'media_id'=>max(0, (int)($input['id'] ?? 0)),
        'season'=>max(1, (int)($input['season'] ?? 1)),
        'episode_number'=>max(1, (int)($input['episode'] ?? 1)),
    ],
];
wp_write($rooms);
wp_json(['ok'=>true,'room'=>wp_public($rooms[$code]),'member_id'=>$id]);
