<?php
require_once __DIR__ . '/common.php';
wp_require_post();
$input = wp_input(); $code = wp_code((string)($input['code'] ?? ''));
if (!preg_match('/^AFV-[A-Z0-9]{5}$/', $code)) wp_json(['ok'=>false,'error'=>'Invalid room code'], 422);
$rooms = wp_read(); wp_cleanup($rooms); $room = wp_find($rooms, $code);
if (!$room) wp_json(['ok'=>true]);
$id = wp_member_id(); unset($room['members'][$id]);
if (!$room['members']) unset($rooms[$code]);
else {
    if (($room['host_id'] ?? '') === $id) {
        $next = reset($room['members']); $room['host_id'] = $next['id'];
    }
    $room['updated_at'] = time(); $rooms[$code] = $room;
}
wp_write($rooms); wp_json(['ok'=>true]);
