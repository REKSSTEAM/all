<?php
require_once __DIR__ . '/common.php';
wp_require_post();
$input = wp_input(); $code = wp_code((string)($input['code'] ?? ''));
if (!preg_match('/^AFV-[A-Z0-9]{5}$/', $code)) wp_json(['ok'=>false,'error'=>'Invalid room code'], 422);
$rooms = wp_read(); wp_cleanup($rooms); $room = wp_find($rooms, $code);
if (!$room) wp_json(['ok'=>false,'error'=>'Room not found or expired'], 404);
$id = wp_member_id(); $now = time();
if (!isset($room['members'][$id])) $room['members'][$id] = ['id'=>$id,'name'=>wp_name($input),'last_seen'=>$now];
else $room['members'][$id]['last_seen'] = $now;
$room['updated_at'] = $now; $rooms[$code] = $room; wp_write($rooms);
wp_json(['ok'=>true,'room'=>wp_public($room),'member_id'=>$id]);
