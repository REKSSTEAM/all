<?php
require_once __DIR__ . '/common.php';

$code = wp_code((string)($_GET['code'] ?? ''));
if (!preg_match('/^AFV-[A-Z0-9]{5}$/', $code)) {
    http_response_code(400);
    exit('Invalid room code');
}

$rooms = wp_read();
wp_cleanup($rooms);
$room = wp_find($rooms, $code);
if (!$room) {
    http_response_code(404);
    exit('Room not found or expired');
}

$state = $room['state'] ?? [];
$type = in_array(($state['media_type'] ?? ''), ['movie', 'tv'], true) ? $state['media_type'] : '';
$id = (int)($state['media_id'] ?? 0);
$season = max(1, (int)($state['season'] ?? 1));
$episode = max(1, (int)($state['episode_number'] ?? 1));

if (!$type || !$id) {
    http_response_code(409);
    exit('This room does not contain a shareable movie or episode. Open the Watch page and enter the room code manually.');
}

$details = tmdb_details($type, $id);
$title = $details['title'] ?? $details['name'] ?? 'watch';
$slug = $id . '-' . slugify($title);
$path = $type === 'tv'
    ? '/watch/tv/' . $slug . '/' . $season . '/' . $episode
    : '/watch/movie/' . $slug;

header('Location: ' . $path . '?party=' . rawurlencode($code), true, 302);
exit;
