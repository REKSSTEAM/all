<?php
require_once __DIR__ . '/common.php';
sec_api_headers();
wp_json(['ok'=>true,'csrf'=>sec_csrf_token()]);
