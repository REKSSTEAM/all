/* HZ Flix — frontend interactivity */

(() => {
  'use strict';

  // -------- Persisted visual preferences --------
  const preferenceRoot = document.documentElement;
  const preferenceDefaults = { mode: 'light', accent: 'gold', font: 'bricolage', subtitleFont: 'bricolage', subtitleSize: '100', subtitleColor: 'gold', subtitleOpacity: '100', subtitleMargin: '4', subtitleBackground: 'transparent', subtitleBlur: '0' };
  const preferenceAccent = { gold: '#f4d33f', red: '#ff5661', violet: '#b58cff' };
  const preferenceFonts = { bricolage: "'Bricolage Grotesque', sans-serif", inter: "'Inter', sans-serif", system: 'system-ui, sans-serif' };
  let preferences = {};
  try { preferences = JSON.parse(localStorage.getItem('afveo_settings') || '{}'); } catch (_) {}
  const applyPreferences = () => {
    const mode = preferences.mode || preferenceDefaults.mode;
    preferenceRoot.dataset.mode = mode === 'system'
      ? (window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark')
      : mode;
    preferenceRoot.style.setProperty('--accent', preferenceAccent[preferences.accent || preferenceDefaults.accent] || preferenceAccent.gold);
    preferenceRoot.style.setProperty('--ui-font', preferenceFonts[preferences.font || preferenceDefaults.font] || preferenceFonts.bricolage);
    preferenceRoot.style.setProperty('--subtitle-font', preferenceFonts[preferences.subtitleFont || preferenceDefaults.subtitleFont] || preferenceFonts.bricolage);
    preferenceRoot.style.setProperty('--subtitle-size', (preferences.subtitleSize || preferenceDefaults.subtitleSize) + '%');
    preferenceRoot.style.setProperty('--subtitle-color', preferences.subtitleColor === 'white' ? '#fff' : preferences.subtitleColor === 'yellow' ? '#ffe76a' : preferenceAccent.gold);
    preferenceRoot.style.setProperty('--subtitle-opacity', (preferences.subtitleOpacity || preferenceDefaults.subtitleOpacity) / 100);
    preferenceRoot.style.setProperty('--subtitle-margin', (preferences.subtitleMargin || preferenceDefaults.subtitleMargin) + '%');
    preferenceRoot.dataset.subtitleBackground = preferences.subtitleBackground || preferenceDefaults.subtitleBackground;
    preferenceRoot.dataset.subtitleBlur = preferences.subtitleBlur || preferenceDefaults.subtitleBlur;
  };
  applyPreferences();

  // -------- Sticky nav background --------
  const nav = document.getElementById('siteNav');
  const onScroll = () => {
    if (!nav) return;
    if (window.scrollY > 40) nav.classList.add('is-scrolled');
    else nav.classList.remove('is-scrolled');
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // -------- Search overlay --------
  const overlay = document.getElementById('searchOverlay');
  const input   = document.getElementById('searchInput');
  const results = document.getElementById('searchResults');
  const open    = () => { overlay?.classList.add('is-open'); setTimeout(() => input?.focus(), 50); };
  const close   = () => { overlay?.classList.remove('is-open'); if (input) input.value = ''; if (results) results.innerHTML = ''; };

  document.getElementById('searchToggle')?.addEventListener('click', open);
  document.getElementById('bottomSearchToggle')?.addEventListener('click', open);
  document.getElementById('searchClose') ?.addEventListener('click', close);
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') close();
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); open(); }
  });

  // -------- Mobile Rivestream command sheet --------
  const mobileMenu = document.getElementById('mobileMenu');
  const mobileMenuToggle = document.getElementById('mobileMenuToggle');
  const closeMobileMenu = () => {
    if (!mobileMenu) return;
    mobileMenu.classList.remove('is-open');
    mobileMenu.hidden = true;
    mobileMenuToggle?.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('mobile-menu-open');
  };
  const openMobileMenu = () => {
    if (!mobileMenu) return;
    mobileMenu.hidden = false;
    requestAnimationFrame(() => mobileMenu.classList.add('is-open'));
    mobileMenuToggle?.setAttribute('aria-expanded', 'true');
    document.body.classList.add('mobile-menu-open');
  };
  mobileMenuToggle?.addEventListener('click', () => {
    if (mobileMenu?.classList.contains('is-open')) closeMobileMenu();
    else openMobileMenu();
  });
  mobileMenu?.addEventListener('click', e => {
    if (e.target.closest('[data-mobile-menu-close]')) closeMobileMenu();
    if (e.target.closest('.mobile-menu-unavailable')) e.preventDefault();
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeMobileMenu();
  });

  function roomInput(value) {
    const raw = String(value || '').trim();
    const text = raw.toUpperCase();
    const direct = text.match(/^AFV-[A-Z0-9]{5}$/);
    if (direct) return { code: direct[0], invalid: false };

    // يدعم رابط المشاركة الكامل أو رابط room.php?code=...
    try {
      const url = new URL(raw, window.location.origin);
      const candidate = url.searchParams.get('party') || url.searchParams.get('code') || url.searchParams.get('room');
      if (candidate) {
        const code = candidate.trim().toUpperCase();
        return { code: /^AFV-[A-Z0-9]{5}$/.test(code) ? code : '', invalid: true };
      }
    } catch (_) {}

    // إذا كان الإدخال يبدو ككود غرفة لكنه غير مكتمل، لا نحوله إلى بحث TMDB.
    const looksLikeRoom = /(?:^AFV[-_ ]?|WATCH[\s._-]*PARTY|(?:^|[/?])room\.php|[?&](?:party|code|room)=)/i.test(raw);
    return { code: '', invalid: looksLikeRoom };
  }

  function extractRoomCode(value) {
    return roomInput(value).code;
  }

  function roomJoinUrl(code) {
    return '/watch-party/room.php?code=' + encodeURIComponent(code);
  }

  let searchT = null;
  input?.addEventListener('input', () => {
    clearTimeout(searchT);
    const q = input.value.trim();
    if (!q) { results.innerHTML = ''; return; }
    const parsedRoom = roomInput(q);
    const roomCode = parsedRoom.code;
    if (roomCode) {
      results.innerHTML = `<a class="sr-item sr-room-item" href="${roomJoinUrl(roomCode)}">
        <i class="fa-solid fa-users"></i><div><strong>Join Watch Party</strong><small>Room ${roomCode}</small></div>
      </a>`;
      return;
    }
    if (parsedRoom.invalid) {
      results.innerHTML = '<p style="text-align:center;color:#ff9d9d;padding:20px">Invalid Watch Party code or link.</p>';
      return;
    }
    searchT = setTimeout(async () => {
      try {
        const r  = await fetch('/api/search?q=' + encodeURIComponent(q));
        const j  = await r.json();
        if (!j.results || j.results.length === 0) {
          results.innerHTML = '<p style="text-align:center;color:#888;padding:30px">No results found.</p>';
          return;
        }
        const esc = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
        results.innerHTML = j.results.map(it => `
          <a class="sr-item" href="${esc(it.href)}">
            <img src="${esc(it.poster)}" alt="" />
            <div>
              <strong>${esc(it.title)}</strong>
              <small>${it.type === 'tv' ? 'TV Show' : 'Movie'}${it.year ? ' · ' + it.year : ''} · ⭐ ${it.rating}</small>
            </div>
          </a>
        `).join('');
      } catch (err) { /* silent */ }
    }, 250);
  });
  input?.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      const q = input.value.trim();
      const parsedRoom = roomInput(q);
      if (parsedRoom.code) location.href = roomJoinUrl(parsedRoom.code);
      else if (parsedRoom.invalid) toast('Enter a valid Watch Party code or link');
      else if (q) location.href = '/search?q=' + encodeURIComponent(q);
    }
  });

  // -------- Hero slider --------
  const slides = document.querySelectorAll('.hero-slide');
  const dots   = document.querySelectorAll('.hero-dot');
  let curr = 0, heroT = null;
  const goTo = i => {
    if (!slides.length) return;
    slides.forEach(s => s.classList.remove('is-active'));
    dots.forEach(d => d.classList.remove('is-active'));
    curr = (i + slides.length) % slides.length;
    slides[curr].classList.add('is-active');
    dots[curr]?.classList.add('is-active');
  };
  const cycle = () => goTo(curr + 1);
  if (slides.length > 1) {
    heroT = setInterval(cycle, 6500);
    dots.forEach((d, i) => d.addEventListener('click', () => { goTo(i); clearInterval(heroT); heroT = setInterval(cycle, 6500); }));
  }

  // -------- Detail tabs --------
  const detailTabs = document.querySelectorAll('[data-detail-tab]');
  const detailPanels = document.querySelectorAll('[data-detail-panel]');
  if (detailTabs.length && detailPanels.length) {
    const selectDetailTab = name => {
      detailTabs.forEach(tab => {
        const selected = tab.dataset.detailTab === name;
        tab.classList.toggle('is-active', selected);
        tab.setAttribute('aria-selected', selected ? 'true' : 'false');
      });
      detailPanels.forEach(panel => {
        panel.hidden = panel.dataset.detailPanel !== name;
      });
    };
    detailTabs.forEach(tab => tab.addEventListener('click', () => selectDetailTab(tab.dataset.detailTab)));
    selectDetailTab(document.querySelector('[data-detail-tab].is-active')?.dataset.detailTab || 'overview');
  }

  // -------- Row arrows --------
  document.querySelectorAll('.row').forEach(row => {
    const track = row.querySelector('.row-track');
    if (!track) return;
    row.querySelectorAll('[data-arrow]').forEach(btn => {
      btn.addEventListener('click', () => {
        const dir = btn.dataset.arrow === 'left' ? -1 : 1;
        track.scrollBy({ left: dir * (track.clientWidth * 0.8), behavior: 'smooth' });
      });
    });
  });

  // -------- Saved list --------
  const KEY = 'hzflix_saved';
  const getSaved = () => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } };
  const setSaved = list => localStorage.setItem(KEY, JSON.stringify(list));
  const isSaved  = (id, type) => getSaved().some(i => String(i.id) === String(id) && i.type === type);

  const refreshSaveBtns = () => {
    document.querySelectorAll('[data-save]').forEach(b => {
      const on = isSaved(b.dataset.id, b.dataset.type);
      b.classList.toggle('is-saved', on);
      b.querySelector('i')?.classList.toggle('fa-plus',  !on);
      b.querySelector('i')?.classList.toggle('fa-check', on);
    });
  };
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-save]');
    if (!b) return;
    e.preventDefault();
    const list = getSaved();
    const idx  = list.findIndex(i => String(i.id) === String(b.dataset.id) && i.type === b.dataset.type);
    if (idx >= 0) list.splice(idx, 1);
    else list.unshift({ id: b.dataset.id, type: b.dataset.type, title: b.dataset.title, poster: b.dataset.poster, savedAt: Date.now() });
    setSaved(list);
    refreshSaveBtns();
  });
  refreshSaveBtns();

  // -------- Share --------
  // navigator.share / navigator.clipboard only exist on HTTPS pages, so on a
  // plain-HTTP host the old button silently did nothing. We use the native
  // sheet when it exists and fall back to our own share sheet otherwise.
  const copyText = async text => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (_) {}
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none';
      document.body.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, text.length);
      const ok = document.execCommand('copy');
      ta.remove();
      return ok;
    } catch (_) { return false; }
  };

  const mk = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  };

  function closeShareSheet() {
    document.getElementById('shareSheet')?.remove();
    document.removeEventListener('keydown', onShareKey);
  }
  function onShareKey(e) { if (e.key === 'Escape') closeShareSheet(); }

  function openShareSheet({ title, url }) {
    closeShareSheet();
    const enc = encodeURIComponent;
    const targets = [
      { name: 'WhatsApp', icon: 'fa-brands fa-whatsapp',    color: '#25d366', href: 'https://wa.me/?text=' + enc(title + ' ' + url) },
      { name: 'Telegram', icon: 'fa-brands fa-telegram',    color: '#29b6f6', href: 'https://t.me/share/url?url=' + enc(url) + '&text=' + enc(title) },
      { name: 'Facebook', icon: 'fa-brands fa-facebook-f',  color: '#1877f2', href: 'https://www.facebook.com/sharer/sharer.php?u=' + enc(url) },
      { name: 'X',        icon: 'fa-brands fa-x-twitter',   color: '#e7e9ea', href: 'https://twitter.com/intent/tweet?text=' + enc(title) + '&url=' + enc(url) }
    ];

    const root = mk('div', 'share-sheet');
    root.id = 'shareSheet';
    root.setAttribute('role', 'dialog');
    root.setAttribute('aria-modal', 'true');
    root.setAttribute('aria-label', 'Share');

    const backdrop = mk('div', 'share-sheet-backdrop');
    backdrop.addEventListener('click', closeShareSheet);

    const panel = mk('div', 'share-sheet-panel');
    const head = mk('div', 'share-sheet-head');
    head.append(mk('strong', '', 'Share'));
    const close = mk('button', 'share-sheet-close');
    close.type = 'button';
    close.setAttribute('aria-label', 'Close');
    close.innerHTML = '<i class="fa-solid fa-xmark"></i>';
    close.addEventListener('click', closeShareSheet);
    head.append(close);

    const name = mk('p', 'share-sheet-title', title);

    const grid = mk('div', 'share-sheet-grid');
    targets.forEach(t => {
      const a = mk('a', 'share-target');
      a.href = t.href;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      const ic = mk('span', 'share-target-icon');
      ic.style.color = t.color;
      ic.innerHTML = '<i class="' + t.icon + '"></i>';
      a.append(ic, mk('span', '', t.name));
      a.addEventListener('click', () => setTimeout(closeShareSheet, 150));
      grid.append(a);
    });

    const row = mk('div', 'share-sheet-copy');
    const input = mk('input');
    input.type = 'text';
    input.readOnly = true;
    input.value = url;
    input.setAttribute('aria-label', 'Link');
    input.addEventListener('focus', () => input.select());
    const copyBtn = mk('button', 'share-copy-btn', 'Copy');
    copyBtn.type = 'button';
    copyBtn.addEventListener('click', async () => {
      const ok = await copyText(url);
      if (!ok) input.select();
      copyBtn.textContent = ok ? 'Copied' : 'Press copy';
      toast(ok ? 'Link copied' : 'Select the link and copy it');
      setTimeout(() => { copyBtn.textContent = 'Copy'; }, 1800);
    });
    row.append(input, copyBtn);

    panel.append(head, name, grid, row);
    root.append(backdrop, panel);
    document.body.appendChild(root);
    document.addEventListener('keydown', onShareKey);
  }

  async function shareLink(data) {
    if (navigator.share) {
      try { await navigator.share(data); return; }
      catch (err) { if (err && err.name === 'AbortError') return; }
    }
    openShareSheet(data);
  }

  // Detail page share button — shares the title, not the "· AFVeo" tab title.
  document.getElementById('shareBtn')?.addEventListener('click', () => {
    const heading = document.querySelector('.detail-title');
    shareLink({
      title: (heading ? heading.textContent : document.title).trim(),
      url: location.href.split('#')[0]
    });
  });

  // Per-card share buttons (e.g. hero trending card)
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-share]');
    if (!b) return;
    e.preventDefault();
    shareLink({
      title: b.dataset.title || document.title,
      url: b.dataset.url ? (location.origin + b.dataset.url) : location.href.split('#')[0]
    });
  });

  // -------- Tiny toast --------
  function toast(msg) {
    const el = document.createElement('div');
    el.textContent = msg;
    Object.assign(el.style, {
      position: 'fixed', bottom: '90px', left: '50%', transform: 'translateX(-50%)',
      background: '#ffe000', color: '#0a0a0a', padding: '12px 20px', borderRadius: '999px',
      fontSize: '.9rem', fontWeight: '700', zIndex: '3000', boxShadow: '0 8px 24px rgba(0,0,0,.45)'
    });
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2200);
  }

  function escape(str) {
    return String(str).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
  }
})();
