(() => {
  'use strict';

  if (window.__afvWatchPartyAjaxInitialized) return;
  window.__afvWatchPartyAjaxInitialized = true;

  const panel = document.getElementById('settings-view-watchparty');
  const open = document.getElementById('main-watchparty-btn') || document.getElementById('main-watch-party-btn') || document.getElementById('wp-ajax-open');
  if (!panel || !open) return;

  const start = document.getElementById('wp-ajax-start');
  const roomView = document.getElementById('wp-ajax-room');
  const error = document.getElementById('wp-ajax-error');
  const codeEl = document.getElementById('wp-ajax-code');
  const linkEl = document.getElementById('wp-ajax-link');
  const members = document.getElementById('wp-ajax-members');
  const role = document.getElementById('wp-ajax-role');
  const nameEl = document.getElementById('wp-ajax-name');
  const codeInput = document.getElementById('wp-ajax-code-input');
  const api = new URL('../../watch-party/', document.baseURI).href;

  let room = null;
  let memberId = null;
  let timer = null;
  let applying = false;
  let lastRevision = 0;
  let csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

  // لا يوجد قيد خارج الغرفة؛ داخل الغرفة يتحكم المضيف فقط.
  let controlLocked = false;
  const playbackSelectors = [
    '#btn-play-main', '#btn-play', '#skip-left', '#skip-right',
    '#progress-container', '#track', '#btn-volume', '#volume-slider',
    '#btn-subtitles-shortcut', '#btn-episodes', '#btn-cast',
    '.settings-list-item[data-speed]', '.quality-row', '.subtitle-row',
    '.episode-item', '[data-episode]', '[data-source]', '.source-row'
  ].join(',');

  function setControlLock(locked) {
    controlLocked = !!locked;
    document.documentElement.classList.toggle('wp-member-readonly', controlLocked);
    document.querySelectorAll(playbackSelectors).forEach((el) => {
      el.setAttribute('aria-disabled', controlLocked ? 'true' : 'false');
      el.classList.toggle('wp-disabled-control', controlLocked);
    });
  }

  function canControl() {
    return !controlLocked;
  }

  // Capture يمنع onclick المضمّن في عناصر المشغل قبل وصوله إلى العنصر.
  ['click', 'touchend', 'pointerup'].forEach((eventName) => {
    document.addEventListener(eventName, (event) => {
      if (!controlLocked) return;
      const target = event.target && event.target.closest ? event.target.closest(playbackSelectors) : null;
      if (!target) return;
      event.preventDefault();
      event.stopImmediatePropagation();
    }, true);
  });
  window.watchPartyCanControl = canControl;

  function showError(message) {
    if (error) error.textContent = message || '';
  }

  function navigateSettings(view) {
    if (typeof window.afvSettingsNavigate === 'function') {
      window.afvSettingsNavigate(view);
      return true;
    }
    return false;
  }

  function openPanel() {
    navigateSettings('watchparty');
    panel.hidden = false;
    panel.classList.add('active');
    showError('');
  }

  function closePanel() {
    navigateSettings('main');
    panel.classList.remove('active');
    showError('');
  }

  function getShareUrl(code) {
    try {
      const parentUrl = window.top && window.top !== window ? window.top.location.href : window.location.href;
      const url = new URL(parentUrl);
      url.searchParams.set('party', code);
      return url.toString();
    } catch (_) {
      return `${location.origin}/?party=${encodeURIComponent(code)}`;
    }
  }

  function copyText(text) {
    if (navigator.clipboard?.writeText) return navigator.clipboard.writeText(text);
    const area = document.createElement('textarea');
    area.value = text;
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    area.remove();
    return Promise.resolve();
  }

  function ensureCsrf() {
    if (csrf) return Promise.resolve(csrf);
    return fetch(`${api}token.php`, { credentials: 'same-origin', cache: 'no-store' })
      .then(r => r.json())
      .then(data => {
        if (!data.ok || !data.csrf) throw new Error('Security token unavailable');
        csrf = data.csrf;
        return csrf;
      });
  }

  function post(file, data) {
    return ensureCsrf().then(() => fetch(api + file, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify({ ...data, _csrf: csrf })
    })).then(r => r.json());
  }

  function playbackContext() {
    const params = new URLSearchParams(location.search);
    return {
      type: params.get('type') || '',
      id: params.get('id') || '',
      season: params.get('season') || '',
      episode: params.get('episode') || ''
    };
  }

  function render(r) {
    room = r;
    setControlLock(r.host_id !== memberId);
    if (codeEl) codeEl.textContent = r.code;
    if (linkEl) linkEl.value = getShareUrl(r.code);
    if (members) members.textContent = `People watching: ${r.member_count}`;
    if (role) role.textContent = r.host_id === memberId ? 'You are the Host' : `Host: ${r.host_name}`;
    if (start) start.hidden = true;
    if (roomView) roomView.hidden = false;
  }

  function applyState(state) {
    const video = document.getElementById('v');
    if (!video || !state || applying || state.revision === lastRevision) return;
    lastRevision = state.revision || lastRevision;
    applying = true;
    if (typeof state.position === 'number' && Math.abs((video.currentTime || 0) - state.position) > 1.2) {
      video.currentTime = state.position;
    }
    const playback = state.playing ? video.play() : Promise.resolve(video.pause());
    Promise.resolve(playback).catch(() => {}).finally(() => {
      setTimeout(() => { applying = false; }, 80);
    });
  }

  function poll() {
    if (!room) return;
    fetch(`${api}state.php?code=${encodeURIComponent(room.code)}`, {
      credentials: 'same-origin',
      cache: 'no-store'
    }).then(r => r.json()).then(data => {
      if (!data.ok) {
        showError(data.error || 'Room unavailable');
        return;
      }
      memberId = data.member_id;
      render(data.room);
      applyState(data.room.state);
    }).catch(() => showError('Connection lost — retrying…'));
  }

  function enter(code) {
    code = String(code || '').trim().toUpperCase();
    if (!/^AFV-[A-Z0-9]{5}$/.test(code)) {
      showError('Enter a valid room code, for example AFV-7K29P');
      return;
    }
    openPanel();
    showError('Connecting…');
    post('join.php', { code, name: nameEl?.value || '' }).then(data => {
      if (!data.ok) throw new Error(data.error || 'Could not join room');
      memberId = data.member_id;
      render(data.room);
      applyState(data.room.state);
      clearInterval(timer);
      timer = setInterval(poll, 1000);
      showError('');
    }).catch(e => showError(e.message));
  }

  document.getElementById('wp-ajax-create')?.addEventListener('click', () => {
    showError('Creating room…');
    post('create.php', Object.assign({
      name: nameEl?.value || '',
      episode: window.currentEpisodeId || '',
      video: window._activeMediaUrl || ''
    }, playbackContext())).then(data => {
      if (!data.ok) throw new Error(data.error || 'Could not create room');
      memberId = data.member_id;
      render(data.room);
      clearInterval(timer);
      timer = setInterval(poll, 1000);
      showError('');
    }).catch(e => showError(e.message));
  });

  document.getElementById('wp-ajax-join')?.addEventListener('click', () => enter(codeInput?.value || ''));
  codeInput?.addEventListener('keydown', event => {
    if (event.key === 'Enter') enter(codeInput.value);
  });

  document.getElementById('wp-ajax-copy')?.addEventListener('click', () => {
    if (!room) return;
    copyText(room.code).then(() => showError('Room code copied')).catch(() => showError('Copy failed'));
  });

  document.getElementById('wp-ajax-share')?.addEventListener('click', () => {
    if (!room) return;
    const url = getShareUrl(room.code);
    if (navigator.share) {
      navigator.share({ title: 'Join my Watch Party', text: `Room ${room.code}`, url }).catch(() => {});
    } else {
      copyText(url).then(() => showError('Room link copied')).catch(() => showError('Copy failed'));
    }
  });

  document.getElementById('wp-ajax-leave')?.addEventListener('click', () => {
    if (!room) return;
    post('leave.php', { code: room.code }).finally(() => {
      room = null;
      setControlLock(false);
      clearInterval(timer);
      if (start) start.hidden = false;
      if (roomView) roomView.hidden = true;
      showError('');
      navigateSettings('watchparty');
    });
  });

  document.getElementById('wp-ajax-close')?.addEventListener('click', closePanel);
  open.addEventListener('click', openPanel);
  open.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      openPanel();
    }
  });

  function action(type, extra) {
    const video = document.getElementById('v');
    if (!room || room.host_id !== memberId || applying || !canControl()) return;
    post('action.php', Object.assign({
      code: room.code,
      event: type,
      position: video?.currentTime || 0,
      playing: video ? !video.paused : false
    }, extra || {})).then(data => {
      if (data.ok) lastRevision = data.room.state.revision;
    }).catch(() => {});
  }

  const video = document.getElementById('v');
  if (video) {
    video.addEventListener('play', () => action('play'));
    video.addEventListener('pause', () => action('pause'));
    video.addEventListener('seeked', () => action('seek'));
  }
  window.watchPartyAjaxAction = action;

  let initialCode = '';
  try {
    const parentUrl = window.top && window.top !== window ? window.top.location.href : window.location.href;
    initialCode = new URL(parentUrl).searchParams.get('party') || '';
  } catch (_) {}
  if (/^AFV-[A-Z0-9]{5}$/.test(initialCode.toUpperCase())) {
    if (codeInput) codeInput.value = initialCode.toUpperCase();
    openPanel();
    setTimeout(() => enter(initialCode), 250);
  }
})();
