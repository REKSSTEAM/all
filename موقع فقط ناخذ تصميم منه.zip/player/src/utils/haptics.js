export const _hxInput = (function () {
  if (!("ontouchstart" in window) && navigator.maxTouchPoints === 0) {
    return null;
  }
  var v1 = document.createElement("input");
  v1.type = "checkbox";
  v1.setAttribute("switch", "");
  v1.setAttribute("inert", "");
  v1.tabIndex = -1;
  v1.style.cssText =
    "position:fixed;top:-9999px;opacity:0;pointer-events:none;";
  document.body.appendChild(v1);
  var v2 = document.createElement("label");
  v2.htmlFor = v1.id = "__hx";
  v2.style.cssText =
    "position:fixed;top:-9999px;opacity:0;pointer-events:none;";
  document.body.appendChild(v2);
  return v2;
})();
export function haptic() {
  if (_hxInput) {
    _hxInput.click();
  }
}
(function () {
  if (!_hxInput) {
    return;
  }
  var v1 = [
    "button",
    "a[href]",
    '[role="button"]',
    '[role="tab"]',
    '[role="option"]',
    '[role="menuitem"]',
    "[tabindex]",
    ".settings-list-item",
    ".ep-item",
    ".ep-season-pill",
    ".ctrl-btn",
    "#track-wrap",
    "#next-ep-inner",
  ].join(",");
  document.addEventListener(
    "click",
    function (arg1) {
      if (arg1.target.id === "__hx") {
        return;
      }
      var v2 = arg1.target.closest(v1);
      if (v2) {
        haptic();
      }
    },
    true,
  );
  document.addEventListener(
    "input",
    function (arg1) {
      if (arg1.target.type === "range") {
        haptic();
      }
    },
    true,
  );
})();
