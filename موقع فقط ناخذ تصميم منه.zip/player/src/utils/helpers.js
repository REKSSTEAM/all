export function isMobile() {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
    navigator.userAgent,
  );
}
export function isIOS() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
}
export function fmt(arg1) {
  if (!arg1 || isNaN(arg1) || arg1 < 0) {
    return "0:00";
  }
  var v2 = Math.floor(arg1 / 3600);
  var v3 = Math.floor((arg1 % 3600) / 60);
  var v4 = Math.floor(arg1 % 60);
  var v5 = v4 < 10 ? "0" + v4 : "" + v4;
  if (v2 > 0) {
    var v6 = v3 < 10 ? "0" + v3 : "" + v3;
    return v2 + ":" + v6 + ":" + v5;
  }
  return v3 + ":" + v5;
}
