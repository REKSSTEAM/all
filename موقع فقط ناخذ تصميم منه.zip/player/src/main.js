import { TMDB_KEY, baseURL, liveBaseURL } from "./config.js";
import { store } from "./state.js";
import { isMobile, isIOS, fmt } from "./utils/helpers.js";
import { haptic } from "./utils/haptics.js";
import {
  initLoaderBackdrop,
  hideLoader,
  setShouldHideLoader,
} from "./ui/loader.js";
window.store = store;
window.TMDB_KEY = TMDB_KEY;
window.baseURL = baseURL;
window.liveBaseURL = liveBaseURL;
window.isMobile = isMobile;
window.isIOS = isIOS;
window.fmt = fmt;
window.haptic = haptic;
window.hideLoader = hideLoader;
window.getSessionToken = getSessionToken;
Object.defineProperty(window, "s", {
  get: () => store.s,
});
Object.defineProperty(window, "e", {
  get: () => store.e,
});
Object.defineProperty(window, "id", {
  get: () => store.id,
});
Object.defineProperty(window, "sources", {
  get: () => store.sources,
  set: (arg1) => (store.sources = arg1),
});
Object.defineProperty(window, "currentSourceIndex", {
  get: () => store.currentSourceIndex,
  set: (arg1) => (store.currentSourceIndex = arg1),
});
Object.defineProperty(window, "buildSourceList", {
  get: () => store.buildSourceList,
  set: (arg1) => (store.buildSourceList = arg1),
});
Object.defineProperty(window, "sourcesLoaded", {
  get: () => store.sourcesLoaded,
  set: (arg1) => (store.sourcesLoaded = arg1),
});
const BASE_URL = ""; // local backend only
let _playerPlay = null;
let _sourceDiscoveryCancelled = false;
window.__skipSourceDiscovery = false;
window.__sourceDebug = [];
window.__lastSourceError = null;
function reportSourceDebug(arg1, arg2) {
  const v3 = {
    message: arg1,
    details: arg2,
    timestamp: new Date().toISOString(),
  };
  if (!window.__sourceDebug) {
    window.__sourceDebug = [];
  }
  window.__sourceDebug.push(v3);
  if (window.__sourceDebug.length > 25) {
    window.__sourceDebug.shift();
  }
  window.__lastSourceError = v3;
  console.error("" + arg1, arg2);
  return v3;
}
window.setWatchPartySourceMode = function (arg1) {
  window.__skipSourceDiscovery = !!arg1;
  if (arg1) {
    _sourceDiscoveryCancelled = true;
    if (typeof window.setShouldHideLoader === "function") {
      window.setShouldHideLoader(true);
    }
    if (typeof window.hideLoader === "function") {
      window.hideLoader();
    }
  } else {
    _sourceDiscoveryCancelled = false;
  }
};
function shouldSkipSourceDiscovery() {
  const v1 = new URLSearchParams(location.search);
  const v2 = v1.get("wp");
  const v3 = (location.hash.match(/wp=([A-Z0-9]+)/) || [])[1] || null;
  return window.__skipSourceDiscovery || !!v2 || !!v3;
}
Object.defineProperty(window, "play", {
  get: () => {
    return async function (arg1, arg2, arg3) {
      if (arg1 === "__init__") {
        return;
      }
      if (_playerPlay) {
        return _playerPlay(arg1, arg2, arg3);
      }
    };
  },
  set: (arg1) => {
    _playerPlay = arg1;
  },
});
async function init() {
  await Promise.all([
    import("./api/tmdb.js"),
    import("./api/subtitles.js"),
    import("./ui/toast.js"),
    import("./core/player.js"),
    import("./ui/glow.js"),
    import("./features/episodes.js"),
    import("./features/watch-party-ajax.js"),
  ]);
  initLoaderBackdrop();
  if (isMobile()) {
    const v1 = document.getElementById("v");
    if (v1) {
      v1.removeAttribute("controls");
    }
  }
  if (store.live) {
    document.body.classList.add("is-live");
    applyLiveUiRestrictions();
    startLiveStream();
    return;
  }
  if (store.id) {
    try {
      window.play("__init__", store.id);
    } catch (v1) {}
    if (shouldSkipSourceDiscovery()) {
      if (typeof window.setShouldHideLoader === "function") {
        window.setShouldHideLoader(true);
      }
      if (typeof window.hideLoader === "function") {
        window.hideLoader();
      }
    } else {
      startSourceDiscovery();
    }
  }
}
// المصادقة أصبحت محلية بالكامل: لا يوجد خادم توكن خارجي.
// نُبقي getSessionToken موجودة للتوافق مع بقية الشيفرة، لكنها تعيد null فوراً.
async function getSessionToken() {
  return null;
}

// ── Direct Provider helpers ────────────────────────────────────────────────
// قائمة المزودين المتاحين — أضف مزوداً جديداً هنا عند إنشاء api/{id}/index.php
const PROVIDERS = [
  { id: "lookmovie",   name: "LookMovie" },
  { id: "newserver",   name: "New Server" },
  // AnimeCurX يستخدم واجهة action/format=player ويحتاج s/e بدل season/episode
  {
    id: "animecurx",
    name: "AnimeCurX",
    params: { action: "streams", format: "player" },
    seasonKeys: ["s", "e"],
  },
  // ── السيرفرات الجديدة ─────────────────────────────────────────────────────
  { id: "mooviefun",   name: "MoovieFun",   multiSources: true },
  { id: "overlook",    name: "Overlook",    multiSources: true },
  { id: "aoneroom",    name: "AoneRoom",    multiSources: true },
];

function _getProvider(providerId) {
  return PROVIDERS.find((p) => p.id === providerId) || { id: providerId };
}

function _genNonce() {
  if (typeof crypto !== "undefined" && crypto.getRandomValues) {
    return Array.from(
      crypto.getRandomValues(new Uint8Array(16)),
      (b) => b.toString(16).padStart(2, "0"),
    ).join("");
  }
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function _buildProviderUrl(providerId) {
  const provider = _getProvider(providerId);
  const params = new URLSearchParams({
    type: store.type || (store.s ? "tv" : "movie"),
    id: store.id,
    _st: store.st || "",
    _ts: Math.floor(Date.now() / 1000),
    _nonce: _genNonce(),
  });
  if (store.s) {
    params.set("season", store.s);
    params.set("episode", store.e || "1");
    if (provider.seasonKeys) {
      params.set(provider.seasonKeys[0], store.s);
      params.set(provider.seasonKeys[1], store.e || "1");
    }
  }
  if (store.title) params.set("title", store.title);
  if (provider.params) {
    Object.entries(provider.params).forEach(([k, v]) => params.set(k, v));
  }
  return "/api/" + provider.id + "/index.php?" + params.toString();
}

function _normalizeProviderResponse(data) {
  if (!data || !data.ok) {
    return { ok: false, error: data?.error || "Provider failed" };
  }
  // lookmovie / standard format: {source:{m3u8, qualities, subtitles}}
  if (data.source?.m3u8) {
    const sources = data.source.qualities?.length
      ? data.source.qualities.map((q) => ({ url: q.url, label: q.label }))
      : [{ url: data.source.m3u8, label: data.source.quality || "HD" }];
    return { ok: true, sources, subtitles: data.source.subtitles || [] };
  }
  // multiSources format: {servers:[{id, name, streams:[{label, url, type}]}]}
  if (Array.isArray(data.servers) && data.servers.length) {
    const sources = [];
    data.servers.forEach((srv) => {
      (srv.streams || []).forEach((st) => {
        if (st.url) sources.push({ url: st.url, label: st.label || srv.name, type: st.type || "hls", source: srv.name });
      });
    });
    if (sources.length) return { ok: true, sources, subtitles: data.subtitles || [] };
  }
  // already normalised: {sources:[{url}]}
  if (Array.isArray(data.sources) && data.sources.length) {
    return { ok: true, sources: data.sources, subtitles: data.subtitles || [] };
  }
  return { ok: false, error: "Unexpected provider response" };
}

async function testSource(arg1) {
  const url = _buildProviderUrl(arg1);
  const resp = await fetch(url, { cache: "no-store" });
  if (!resp.ok) throw new Error("Source check failed (" + resp.status + ")");
  const data = await resp.json();
  const norm = _normalizeProviderResponse(data);
  if (!norm.ok || !norm.sources?.length) throw new Error("No URL for " + arg1);
  return norm.sources[0].url;
}
function showErrorScreen(arg1 = null) {
  const v2 = document.getElementById("loader-spinner-wrap");
  if (v2) {
    v2.style.display = "none";
  }
  const v3 = document.getElementById("error-screen");
  const v4 = document.querySelector(".err-text");
  const v5 = document.querySelector(".err-sub");
  const v6 = arg1?.message || arg1 || "The video source could not be loaded.";
  if (v4) {
    v4.textContent = "Playback failed";
  }
  if (v5) {
    v5.textContent = v6;
  } else if (v4) {
    v4.insertAdjacentHTML(
      "afterend",
      '<div class="err-sub">' +
        String(v6).replace(/</g, "&lt;").replace(/>/g, "&gt;") +
        "</div>",
    );
  }
  if (v3) {
    v3.classList.add("show");
  }
}
function revealPlayerUi() {
  // نتأكد أن واجهة المشغّل تظهر بعد بدء التشغيل مهما حصل أثناء اكتشاف المصادر.
  window.__sourceDiscoveryUiHidden = false;
  const show = () => {
    window.__sourceDiscoveryUiHidden = false;
    if (typeof window.showUI === "function") {
      window.showUI(true);
    } else {
      const wrap = document.getElementById("player-controls-wrapper");
      const bar = document.getElementById("title-bar");
      const pl = document.getElementById("player");
      if (wrap) wrap.classList.add("on");
      if (bar) bar.classList.add("on");
      if (pl) pl.classList.add("ui-on");
    }
  };
  show();
  [150, 600, 1500].forEach((ms) => setTimeout(show, ms));
  const v = document.getElementById("v");
  if (v && !v.__uiRevealHooked) {
    v.__uiRevealHooked = true;
    ["loadedmetadata", "playing", "canplay"].forEach((ev) =>
      v.addEventListener(ev, show),
    );
  }
}

function setSourceDiscoveryUiHidden(arg1) {
  window.__sourceDiscoveryUiHidden = !!arg1;
  if (!arg1) {
    return;
  }
  if (typeof window.hideUI === "function") {
    window.hideUI();
  }
  const v2 = document.getElementById("player-controls-wrapper");
  const v3 = document.getElementById("title-bar");
  const v4 = document.getElementById("player");
  if (v2) {
    v2.classList.remove("on");
  }
  if (v3) {
    v3.classList.remove("on");
  }
  if (v4) {
    v4.classList.remove("ui-on");
  }
}
function applyLiveUiRestrictions() {
  const v1 = [
    "btn-subtitles-shortcut",
    "subtitle-toggle",
    "subtitle-display",
    "main-pip-btn",
    "main-watchparty-btn",
    "main-segment-btn",
  ];
  v1.forEach((arg1) => {
    const v4 = document.getElementById(arg1);
    if (v4) {
      v4.style.display = "none";
    }
  });
  const v2 = document.querySelector(
    ".settings-main-list .settings-main-divider",
  );
  if (v2) {
    v2.style.display = "none";
  }
  const v3 = [
    '.settings-tile[data-nav="subtitles"]',
    '.settings-tile[data-nav="download"]',
  ];
  v3.forEach((arg1) => {
    const v4 = document.querySelector(arg1);
    if (v4) {
      v4.style.display = "none";
    }
  });
}
async function startLiveStream() {
  setSourceDiscoveryUiHidden(true);
  const v1 = document.getElementById("loader-spinner-label");
  if (v1) {
    v1.textContent = "Resolving Live Match...";
  }
  try {
    if (!store.live.includes("/")) {
      throw new Error("Invalid Live Path");
    }
    const [v2, v3] = store.live.split("/");
    const v4 = await fetch(liveBaseURL + "/api/matches/" + v2);
    if (!v4.ok) {
      throw new Error("Match Schedule Unavailable");
    }
    const v5 = await v4.json();
    const v6 = v5.find((arg1) => arg1.id === v3 || arg1.slug === v3);
    if (!v6) {
      throw new Error("Match not found or concluded");
    }
    const v7 = document.getElementById("loader-bg");
    let v8 = v6.poster || v6.teams?.home?.badge || v6.teams?.away?.badge;
    if (v8 && v7) {
      let v15 = v8;
      if (v15.includes("/api/images/proxy//api/images/proxy/")) {
        v15 = v15.replace(
          "/api/images/proxy//api/images/proxy/",
          "/api/images/proxy/",
        );
      } else if (!v15.startsWith("http")) {
        const v16 = v8.startsWith("/") ? v8 : "/" + v8;
        v15 = "https://streamed.pk" + v16;
      }
      v7.style.backgroundImage = 'url("' + v15 + '")';
      v7.style.display = "block";
      v7.style.opacity = "1";
    }
    const v9 = ["golf", "admin", "echo"];
    let v10 = null;
    for (const v15 of v9) {
      v10 = (v6.sources || []).find((arg1) => arg1.source === v15);
      if (v10) {
        break;
      }
    }
    if (!v10) {
      throw new Error("No available stream sources");
    }
    if (v1) {
      v1.textContent = "Connecting to " + v10.source + "...";
    }
    const v11 = await fetch(
      liveBaseURL + "/api/stream/" + v10.source + "/" + v10.id,
    );
    if (!v11.ok) {
      throw new Error("Failed to fetch stream data");
    }
    const v12 = await v11.json();
    const v13 = Array.isArray(v12) ? v12 : [v12];
    if (!v13.length || !v13[0].streamUrl) {
      throw new Error("Stream offline");
    }
    store.sources = v13.map((arg1, arg2) => ({
      key: "live-" + arg2,
      source: "live",
      label: arg1.language || "Stream " + (arg2 + 1),
      url: arg1.streamUrl,
    }));
    store.currentSourceIndex = 0;
    store.sourcesLoaded = true;
    document.title = v6.title || "Live";
    if (typeof window.showNowPlayingToast === "function") {
      window.showNowPlayingToast(v6.title || "Live");
    }
    setShouldHideLoader(true);
    window.hideLoader();
    setSourceDiscoveryUiHidden(false);
    revealPlayerUi();
    let v14 = v13[0].streamUrl;
    window.play(v14, v10.id);
  } catch (v2) {
    reportSourceDebug("Live resolution error", {
      error: v2.message,
    });
    setSourceDiscoveryUiHidden(false);
    revealPlayerUi();
    showErrorScreen(v2);
  }
}
function shuffleArray(arg1) {
  const v2 = arg1.slice();
  for (let v1 = v2.length - 1; v1 > 0; v1--) {
    const v3 = Math.floor(Math.random() * (v1 + 1));
    [v2[v1], v2[v3]] = [v2[v3], v2[v1]];
  }
  return v2;
}
async function loadTitleMeta() {
  try {
    const v1 = store.s ? "tv" : "movie";
    const v2 = await fetch(
      "https://api.themoviedb.org/3/" +
        v1 +
        "/" +
        store.id +
        "?api_key=" +
        TMDB_KEY,
    );
    if (!v2.ok) {
      throw new Error("TMDB meta failed (" + v2.status + ")");
    }
    const v3 = await v2.json();
    let v4 = v3.title || v3.name || "Unknown";
    if (store.s) {
      v4 += " · S" + store.s + "E" + (store.e || "1");
    }
    document.title = v4;
    if (typeof window.setTitleWithTmdbImage === "function") {
      await window.setTitleWithTmdbImage(
        v4,
        Object.assign({}, v3, {
          tmdb_id: store.id,
        }),
      );
    }
    if (typeof window.showNowPlayingToast === "function") {
      window.showNowPlayingToast(v4);
    }
  } catch (v1) {
    reportSourceDebug("Title meta fetch error", {
      error: v1.message,
    });
  }
}
// اكتشاف تدريجي للمصادر:
// 1) نجلب قائمة المصادر (رد فوري بلا انتظار).
// 2) نفحص المصادر بالتوازي (كل مصدر بطلب مستقل).
// 3) نبدأ التشغيل فور نجاح أول مصدر، وبقية المصادر تُضاف للقائمة تباعاً.
const DISCOVERY_CONCURRENCY = 4;

async function probeSource(server) {
  const url = _buildProviderUrl(server.id);
  try {
    const resp = await fetch(url, { cache: "no-store" });
    const data = await resp.json().catch(() => null);
    if (!resp.ok || !data || !data.ok) {
      return { ok: false, error: (data && data.error) || "HTTP " + resp.status };
    }
    return _normalizeProviderResponse(data);
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

// استدعاء كل provider مباشرة من المتصفح بدون sources.php
// يعمل على أي استضافة بدون قيود PHP
async function probeAllSources() {
  const results = await Promise.allSettled(
    PROVIDERS.map(async (server) => {
      try {
        const url = _buildProviderUrl(server.id);
        const resp = await fetch(url, { cache: "no-store" });
        const data = await resp.json().catch(() => null);
        if (!resp.ok || !data || !data.ok) {
          return {
            id: server.id,
            name: server.name,
            ok: false,
            status: "offline",
            sources: [],
            subtitles: [],
            subtitleCount: 0,
            error: (data && data.error) || "HTTP " + resp.status,
          };
        }
        const norm = _normalizeProviderResponse(data);
        return {
          id: server.id,
          name: server.name,
          ok: norm.ok,
          status: norm.ok ? "online" : "offline",
          sources: norm.sources || [],
          subtitles: norm.subtitles || [],
          subtitleCount: (norm.subtitles || []).length,
          error: norm.ok ? null : norm.error,
        };
      } catch (err) {
        return {
          id: server.id,
          name: server.name,
          ok: false,
          status: "offline",
          sources: [],
          subtitles: [],
          subtitleCount: 0,
          error: err.message,
        };
      }
    })
  );
  return results.map((r) =>
    r.status === "fulfilled"
      ? r.value
      : { id: "", name: "", ok: false, status: "offline", sources: [], subtitles: [], subtitleCount: 0, error: r.reason?.message }
  );
}

// جمع الترجمات القادمة من كل مزوّد وإرسالها للمشغّل (تظهر مهما كان السيرفر الفعّال)
window.__providerSubtitles = window.__providerSubtitles || [];
function collectProviderSubtitles(providerName, list) {
  if (!Array.isArray(list) || !list.length) return;
  const tagged = list
    .filter((s) => s && (s.url || s.file))
    .map((s) => Object.assign({}, s, { source: s.source || providerName }));
  if (!tagged.length) return;
  window.__providerSubtitles = window.__providerSubtitles.concat(tagged);
  const flush = () => {
    if (typeof window.mergeSubtitles === "function") {
      window.mergeSubtitles(tagged);
      return true;
    }
    return false;
  };
  if (!flush()) {
    let tries = 0;
    const t = setInterval(() => {
      if (flush() || ++tries > 60) clearInterval(t);
    }, 500);
  }
}

// إعادة رسم قائمة السيرفرات حتى لو لم يكن المشغّل جاهزاً بعد
function requestSourceListRender() {
  if (typeof window.buildSourceList === "function") {
    window.buildSourceList();
    return;
  }
  let tries = 0;
  const t = setInterval(() => {
    if (typeof window.buildSourceList === "function") {
      window.buildSourceList();
      clearInterval(t);
    } else if (++tries > 60) {
      clearInterval(t);
    }
  }, 500);
}

async function startSourceDiscovery() {
  if (shouldSkipSourceDiscovery()) {
    if (typeof window.setShouldHideLoader === "function") {
      window.setShouldHideLoader(true);
    }
    if (typeof window.hideLoader === "function") {
      window.hideLoader();
    }
    return;
  }
  _sourceDiscoveryCancelled = false;
  setSourceDiscoveryUiHidden(true);
  store.sources = [];
  store.sourcesLoaded = false;
  // تصفير بيانات الترجمة للفيلم/المسلسل الجديد
  window.__subtitlePool = [];
  window.__providerSubtitles = [];
  window._autoSubDone = false;
  const labelEl = document.getElementById("loader-spinner-label");
  const setLabel = (text) => {
    if (labelEl) labelEl.textContent = text;
  };
  setLabel("جاري البحث عن مصادر...");
  loadTitleMeta();

  try {
    if (_sourceDiscoveryCancelled) return;
    const servers = PROVIDERS;
    // كل السيرفرات تظهر بالقائمة منذ البداية (بحالة "قيد الفحص")،
    // ويستمر الفحص بالخلفية حتى بعد بدء التشغيل من أول سيرفر ناجح.
    const statusSuffix = (st) =>
      st === "ok" ? "" : st === "failed" ? " ⚠️" : " ⏳";
    const slots = servers.map((sv) => ({
      key: sv.id,
      source: sv.id,
      label: sv.name + " ⏳",
      name: sv.name,
      url: null,
      items: null,
      status: "checking",
      subtitleCount: 0,
    }));
    let firstPlayed = false;
    let finished = 0;

    // إعادة بناء قائمة المصادر بالترتيب الأصلي
    const syncList = () => {
      const playingKey = store.sources[store.currentSourceIndex]?.key;
      // A provider can return more than one playable stream. Keep one
      // discovery slot per provider, but flatten every playable stream into
      // the actual source list so AnimeCurX/Earth #2, #3, ... are visible
      // and selectable instead of being hidden inside `streams`.
      store.sources = slots.flatMap((sl) => {
        if (Array.isArray(sl.items) && sl.items.length) return sl.items;
        return [
          Object.assign({}, sl, {
            label: sl.name + statusSuffix(sl.status),
            groupId: sl.key,
            isProviderStatus: true,
          }),
        ];
      });
      store.sourcesLoaded = true;
      if (playingKey) {
        const idx = store.sources.findIndex((s) => s.key === playingKey);
        if (idx !== -1) store.currentSourceIndex = idx;
      }
      requestSourceListRender();
    };

    // اعرض كل السيرفرات فوراً قبل بدء الفحص
    syncList();

    const applyResult = (i, server, res) => {
      if (res.ok && res.sources?.length) {
        const playableSources = res.sources.filter((source) => source?.url);
        if (!playableSources.length) {
          slots[i] = Object.assign({}, slots[i], {
            items: null,
            url: null,
            status: "failed",
            error: "No playable URL",
          });
          syncList();
          return false;
        }
        slots[i] = Object.assign({}, slots[i], {
          items: playableSources.map((source, sourceIndex) => ({
            key: `${server.id}:${sourceIndex}`,
            source: server.id,
            name: server.name,
            groupId: server.id,
            groupName: server.name,
            groupStatus: "online",
            groupSubtitleCount: res.subtitleCount || res.subtitles?.length || 0,
            label:
              source.label ||
              source.quality ||
              `${server.name} #${sourceIndex + 1}`,
            url: source.url,
            type: source.type,
            quality: source.quality,
            provider: source.provider || server.id,
            streams: [source],
            status: "ok",
          })),
          url: playableSources[0].url,
          status: "ok",
          error: null,
          subtitleCount: res.subtitleCount || res.subtitles?.length || 0,
        });
        collectProviderSubtitles(server.name, res.subtitles);
        syncList();
        if (!firstPlayed) {
          firstPlayed = true;
          store.currentSourceIndex = store.sources.findIndex(
            (s) => s.key === slots[i].items[0].key,
          );
          setLabel("جاري تشغيل " + server.name + "...");
          setShouldHideLoader(true);
          window.hideLoader();
          setSourceDiscoveryUiHidden(false);
          revealPlayerUi();
          window.play(slots[i].items[0].url, store.id);
        }
        return true;
      }
      // فشل الفحص لا يحذف السيرفر من القائمة — يبقى قابلاً للاختيار
      slots[i] = Object.assign({}, slots[i], {
        items: null,
        url: null,
        status: "failed",
        error: res.error || "unavailable",
        subtitleCount: res.subtitleCount || 0,
      });
      syncList();
      return false;
    };

    setLabel("جاري فحص السيرفرات...");
    const unifiedProviders = await probeAllSources();
    if (_sourceDiscoveryCancelled) return;
    unifiedProviders.forEach((provider) => {
      const index = servers.findIndex((server) => server.id === provider.id);
      if (index === -1) return;
      const server = servers[index];
      finished++;
      const normalized = provider.ok
        ? {
            ok: true,
            sources: provider.sources || [],
            subtitles: provider.subtitles || [],
          }
        : { ok: false, error: provider.error || "unavailable" };
      applyResult(index, server, Object.assign(normalized, {
        providerStatus: provider.status,
        subtitleCount: provider.subtitleCount || 0,
        rawResponse: provider.response,
      }));
    });
    // Providers omitted by a failed unified response remain visible as failed.
    servers.forEach((server, index) => {
      if (slots[index].status === "checking") {
        applyResult(index, server, {
          ok: false,
          error: "No response from unified source check",
        });
      }
    });

    // إعادة فحص دورية بالخلفية للسيرفرات التي فشلت (3 جولات)
    for (let round = 0; round < 3 && !_sourceDiscoveryCancelled; round++) {
      const pending = servers
        .map((sv, i) => ({ sv, i }))
        .filter(({ i }) => !slots[i]?.items?.length);
      if (!pending.length) break;
      await new Promise((r) => setTimeout(r, firstPlayed ? 8000 : 1000));
      if (_sourceDiscoveryCancelled) break;
      await Promise.all(
        pending.map(async ({ sv, i }) => {
          const retry = await probeSource(sv);
          if (_sourceDiscoveryCancelled) return;
          applyResult(i, sv, retry);
        }),
      );
    }

    if (!firstPlayed && !_sourceDiscoveryCancelled) {
      setSourceDiscoveryUiHidden(false);
      revealPlayerUi();
      showErrorScreen("No available streams found for this content.");
    }
  } catch (err) {
    if (!_sourceDiscoveryCancelled) {
      reportSourceDebug("Local source discovery error", { error: err.message });
      setSourceDiscoveryUiHidden(false);
      revealPlayerUi();
      showErrorScreen(err);
    }
  }
}


document.addEventListener(
  "click",
  async (arg1) => {
    const v2 = document.getElementById("sources-opts");
    if (v2 && v2.contains(arg1.target)) {
      const v1 = arg1.target.closest("#sources-opts .source-branch");
      if (v1) {
        const v3 = Number(v1.dataset.sourceIndex);
        if (v3 !== -1 && v3 !== store.currentSourceIndex) {
          const v4 = store.sources[v3];
          if (!v4.url) {
            if (v1.dataset.fetching) {
              return;
            }
            v1.dataset.fetching = "1";
            const v5 = document.getElementById("src-list-view");
            const v6 = document.getElementById("src-detail-view");
            const v7 = document.getElementById("src-detail-title");
            const v8 = document.getElementById("src-loading-state");
            const v9 = document.getElementById("src-failed-state");
            if (v7) {
              v7.textContent = v4.label;
            }
            if (v8) {
              v8.style.display = "flex";
            }
            if (v9) {
              v9.style.display = "none";
            }
            if (v5) {
              v5.style.display = "none";
            }
            if (v6) {
              v6.style.display = "flex";
            }
            try {
              const v10 = await testSource(v4.key);
              v4.url = v10;
              v1.removeAttribute("data-fetching");
              if (v5) {
                v5.style.display = "flex";
              }
              if (v6) {
                v6.style.display = "none";
              }
              v1.click();
            } catch (v10) {
              v1.removeAttribute("data-fetching");
              v8.style.display = "none";
              v9.style.display = "flex";
            }
          }
        }
      }
    }
  },
  true,
);
document.addEventListener("keydown", (arg1) => {
  if (["INPUT", "SELECT", "TEXTAREA"].includes(arg1.target.tagName)) {
    return;
  }
  const v2 = document.getElementById("v");
  if (!v2) {
    return;
  }
  if (arg1.key === "ArrowLeft") {
    v2.currentTime = Math.max(0, v2.currentTime - 10);
    window.showUI();
  }
  if (arg1.key === "ArrowRight") {
    v2.currentTime = Math.min(v2.duration || 0, v2.currentTime + 10);
    window.showUI();
  }
  if ([" ", "k", "K"].includes(arg1.key)) {
    arg1.preventDefault();
    haptic(10);
    if (v2.paused) {
      v2.play();
    } else {
      v2.pause();
    }
  }
});
init();
