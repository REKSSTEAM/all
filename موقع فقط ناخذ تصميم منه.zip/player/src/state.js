const p = new URLSearchParams(location.search);
export const store = {
  id: p.get("id"),
  type: p.get("type") || (p.get("season") ? "tv" : "movie"),
  s: p.get("season"),
  e: p.get("episode"),
  title: p.get("title") || "",
  st: p.get("_st") || "",
  ap: p.get("ap"),
  live: p.get("live"),
  sources: [],
  currentSourceIndex: 0,
  sourcesLoaded: false,
  buildSourceList: null,
  sessionToken: null,
  sessionTokenExpiresAt: null,
};
