cat > /home/claude/project/pages/reels.php << 'ENDOFFILE'
<?php
require_once __DIR__ . '/../config.php';

// ── مسار ملفات الخزن ────────────────────────────────────────────────────
$DATA = __DIR__ . '/../data';
if (!is_dir($DATA)) mkdir($DATA, 0755, true);

$COMMENTS_FILE = $DATA . '/reels_comments.json';
$SAVED_FILE    = $DATA . '/reels_saved.json';
$LIKES_FILE    = $DATA . '/reels_likes.json';

function rj_read($f)  { return file_exists($f) ? (json_decode(file_get_contents($f), true) ?: []) : []; }
function rj_write($f, $d) { file_put_contents($f, json_encode($d, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT), LOCK_EX); }

// ── AJAX handlers ────────────────────────────────────────────────────────
$ajax = $_SERVER['HTTP_X_REQUESTED_WITH'] ?? $_GET['ajax'] ?? '';
if ($ajax || isset($_GET['action'])) {
    header('Content-Type: application/json');
    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    $user   = auth_user();

    // ── جلب ريلز من TMDB ────────────────────────────────────────────────
    if ($action === 'reels') {
        $page   = max(1, intval($_GET['page'] ?? 1));
        $is_tv  = ($page % 2 === 0);
        $type   = $is_tv ? 'tv' : 'movie';
        $tp     = ceil($page / 2);
        $key    = TMDB_API_KEY;
        $ctx    = stream_context_create(['http'=>['timeout'=>8,'ignore_errors'=>true]]);

        $raw = @file_get_contents(TMDB_API_URL."/trending/{$type}/week?api_key={$key}&page={$tp}&language=en-US", false, $ctx);
        $data = $raw ? json_decode($raw, true) : [];
        if (empty($data['results'])) { echo json_encode(['ok'=>false,'reels'=>[]]); exit; }

        // جلب genre map
        $gmap = [];
        $gr = @file_get_contents(TMDB_API_URL."/genre/movie/list?api_key={$key}&language=en-US", false, $ctx);
        $gt = @file_get_contents(TMDB_API_URL."/genre/tv/list?api_key={$key}&language=en-US", false, $ctx);
        if ($gr) foreach ((json_decode($gr,true)['genres']??[]) as $g) $gmap[$g['id']] = $g['name'];
        if ($gt) foreach ((json_decode($gt,true)['genres']??[]) as $g) $gmap[$g['id']] = $g['name'];

        $reels = [];
        foreach ($data['results'] as $item) {
            $vr = @file_get_contents(TMDB_API_URL."/{$type}/{$item['id']}/videos?api_key={$key}&language=en-US", false, $ctx);
            if (!$vr) continue;
            $vd = json_decode($vr, true);
            $trailer_key = null;
            foreach (($vd['results']??[]) as $v) {
                if ($v['site']==='YouTube' && in_array($v['type'],['Trailer','Teaser'])) { $trailer_key=$v['key']; break; }
            }
            if (!$trailer_key) continue;

            $title   = $item['title'] ?? $item['name'] ?? '';
            $year    = substr($item['release_date'] ?? $item['first_air_date'] ?? '', 0, 4);
            $poster  = $item['poster_path']  ? TMDB_IMG."/w500{$item['poster_path']}"  : '';
            $backdrop= $item['backdrop_path'] ? TMDB_IMG."/w780{$item['backdrop_path']}" : $poster;
            $genres  = array_slice(array_values(array_filter(array_map(fn($id)=>$gmap[$id]??null, $item['genre_ids']??[]))), 0, 3);

            $reels[] = [
                'id'          => (string)$item['id'],
                'type'        => $type,
                'title'       => $title,
                'year'        => $year,
                'rating'      => round($item['vote_average']??0, 1),
                'overview'    => $item['overview'] ?? '',
                'poster'      => $poster,
                'backdrop'    => $backdrop,
                'genres'      => $genres,
                'trailer_key' => $trailer_key,
                'watch_url'   => "/{$type}/{$item['id']}",
                'detail_url'  => "/{$type}/{$item['id']}",
            ];
            if (count($reels) >= 5) break;
        }
        echo json_encode(['ok'=>true,'reels'=>$reels]); exit;
    }

    // ── جلب تعليقات ─────────────────────────────────────────────────────
    if ($action === 'get_comments') {
        $id   = $_GET['id']   ?? '';
        $type = $_GET['type'] ?? '';
        $all  = rj_read($COMMENTS_FILE);
        $list = array_values(array_filter($all, fn($c) => $c['item_id']===$id && $c['item_type']===$type));
        usort($list, fn($a,$b) => strcmp($b['created_at'], $a['created_at']));
        echo json_encode(['ok'=>true,'comments'=>$list]); exit;
    }

    // ── إرسال تعليق ─────────────────────────────────────────────────────
    if ($action === 'add_comment') {
        if (!$user) { echo json_encode(['ok'=>false,'error'=>'login']); exit; }
        $id   = trim($_POST['id']   ?? '');
        $type = trim($_POST['type'] ?? '');
        $body = trim($_POST['body'] ?? '');
        if (!$id || !$body || mb_strlen($body)>300) { echo json_encode(['ok'=>false]); exit; }
        $comment = [
            'id'         => uniqid('c',true),
            'item_id'    => $id,
            'item_type'  => $type,
            'user_id'    => $user['id'],
            'username'   => $user['username'] ?? 'User',
            'body'       => $body,
            'created_at' => date('c'),
        ];
        $all = rj_read($COMMENTS_FILE);
        $all[] = $comment;
        rj_write($COMMENTS_FILE, $all);
        echo json_encode(['ok'=>true,'comment'=>$comment]); exit;
    }

    // ── حفظ / إلغاء حفظ ─────────────────────────────────────────────────
    if ($action === 'toggle_save') {
        if (!$user) { echo json_encode(['ok'=>false,'error'=>'login']); exit; }
        $id     = trim($_POST['id']     ?? '');
        $type   = trim($_POST['type']   ?? 'movie');
        $title  = trim($_POST['title']  ?? '');
        $poster = trim($_POST['poster'] ?? '');
        if (!$id) { echo json_encode(['ok'=>false]); exit; }
        $all = rj_read($SAVED_FILE);
        $exists = false;
        foreach ($all as $k => $s) {
            if ($s['user_id']===$user['id'] && $s['item_id']===$id) { unset($all[$k]); $exists=true; break; }
        }
        if (!$exists) {
            $all[] = ['id'=>uniqid('s',true),'user_id'=>$user['id'],'item_id'=>$id,'item_type'=>$type,'title'=>$title,'poster'=>$poster,'saved_at'=>date('c')];
        }
        rj_write($SAVED_FILE, array_values($all));
        echo json_encode(['ok'=>true,'action'=>$exists?'removed':'added']); exit;
    }

    // ── إعجاب ────────────────────────────────────────────────────────────
    if ($action === 'toggle_like') {
        if (!$user) { echo json_encode(['ok'=>false,'error'=>'login']); exit; }
        $id   = trim($_POST['id']   ?? '');
        $type = trim($_POST['type'] ?? 'movie');
        if (!$id) { echo json_encode(['ok'=>false]); exit; }
        $all = rj_read($LIKES_FILE);
        $exists = false;
        foreach ($all as $k => $l) {
            if ($l['user_id']===$user['id'] && $l['item_id']===$id) { unset($all[$k]); $exists=true; break; }
        }
        if (!$exists) {
            $all[] = ['user_id'=>$user['id'],'item_id'=>$id,'item_type'=>$type,'liked_at'=>date('c')];
        }
        rj_write($LIKES_FILE, array_values($all));
        echo json_encode(['ok'=>true,'action'=>$exists?'unliked':'liked']); exit;
    }

    echo json_encode(['ok'=>false,'error'=>'unknown_action']); exit;
}

// ── صفحة HTML ────────────────────────────────────────────────────────────
$page_title = 'Reels · Discover';
$active     = 'reels';
$cur_user   = auth_user();
include __DIR__ . '/../includes/header.php';
?>
<style>
body { overflow: hidden; }
.site-main { padding: 0 !important; }
.site-footer, .bottom-nav { display: none !important; }

.reels-page {
  position: fixed; inset: 0; background: #000; z-index: 10;
  display: flex; flex-direction: column;
}
.reels-topbar {
  position: absolute; top: 0; left: 0; right: 0; z-index: 50;
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 18px; padding-top: calc(14px + env(safe-area-inset-top));
  background: linear-gradient(to bottom, rgba(0,0,0,.7) 0%, transparent 100%);
}
.reels-back {
  width: 38px; height: 38px; border-radius: 50%;
  background: rgba(255,255,255,.12); border: none;
  color: #fff; font-size: 1rem; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  backdrop-filter: blur(8px);
}
.reels-topbar-title { font-size: 1rem; font-weight: 700; color: #fff; letter-spacing: .02em; }
.reels-feed {
  flex: 1; overflow-y: scroll; overflow-x: hidden;
  scroll-snap-type: y mandatory; -webkit-overflow-scrolling: touch;
  scrollbar-width: none;
}
.reels-feed::-webkit-scrollbar { display: none; }
.reel-slide {
  position: relative; width: 100%; height: 100dvh;
  scroll-snap-align: start; scroll-snap-stop: always;
  overflow: hidden; background: #000;
  display: flex; align-items: center; justify-content: center;
}
.reel-bg {
  position: absolute; inset: -20px;
  background-size: cover; background-position: center;
  filter: blur(20px) brightness(.35) saturate(1.3);
  transform: scale(1.1); pointer-events: none;
}
.reel-poster {
  position: absolute; inset: 0; z-index: 2;
  display: flex; align-items: center; justify-content: center;
  background-size: cover; background-position: center;
  transition: opacity .3s;
}
.reel-play-btn {
  width: 72px; height: 72px; border-radius: 50%;
  background: rgba(229,9,20,.85); border: 3px solid rgba(255,255,255,.7);
  color: #fff; font-size: 1.6rem; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  backdrop-filter: blur(6px); box-shadow: 0 4px 24px rgba(0,0,0,.5);
  transition: transform .15s;
}
.reel-play-btn:active { transform: scale(.9); }
.reel-play-btn i { margin-left: 4px; }
.reel-player {
  position: absolute; inset: 0; z-index: 2;
  pointer-events: none; opacity: 0; transition: opacity .4s;
}
.reel-player.playing { opacity: 1; pointer-events: all; }
.reel-player iframe { width: 100%; height: 100%; border: none; display: block; }
.reel-bottom-fade {
  position: absolute; bottom: 0; left: 0; right: 0; z-index: 5;
  height: 65%; pointer-events: none;
  background: linear-gradient(to top, rgba(0,0,0,.9) 0%, rgba(0,0,0,.5) 50%, transparent 100%);
}
.reel-info {
  position: absolute; bottom: 100px; left: 16px; right: 80px; z-index: 10;
  padding-bottom: env(safe-area-inset-bottom);
}
.reel-info h2 { font-size: 1.15rem; font-weight: 800; margin: 0 0 6px; line-height: 1.25; color: #fff; }
.reel-meta { font-size: .8rem; color: rgba(255,255,255,.7); margin-bottom: 6px; display: flex; align-items: center; gap: 8px; }
.reel-type-badge {
  background: var(--primary); color: #fff; font-size: .65rem; font-weight: 700;
  padding: 2px 7px; border-radius: 4px; text-transform: uppercase; letter-spacing: .05em;
}
.reel-genres { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 7px; }
.reel-genre-tag {
  font-size: .72rem; padding: 3px 9px; border-radius: 20px;
  background: rgba(255,255,255,.12); color: rgba(255,255,255,.85);
  border: 1px solid rgba(255,255,255,.18); backdrop-filter: blur(6px);
}
.reel-overview {
  font-size: .82rem; color: rgba(255,255,255,.7); line-height: 1.45;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}
.reel-watch-btn {
  display: inline-flex; align-items: center; gap: 7px;
  background: #fff; color: #000;
  padding: 9px 18px; border-radius: 999px;
  font-size: .85rem; font-weight: 700; margin-top: 10px;
  transition: background .15s; text-decoration: none;
}
.reel-watch-btn i { font-size: .9rem; }
.reel-actions {
  position: absolute; right: 12px; bottom: 110px; z-index: 10;
  display: flex; flex-direction: column; align-items: center; gap: 18px;
  padding-bottom: env(safe-area-inset-bottom);
}
.reel-action-btn {
  display: flex; flex-direction: column; align-items: center; gap: 4px;
  background: none; border: none; color: #fff; cursor: pointer;
  -webkit-tap-highlight-color: transparent; padding: 0; text-decoration: none;
}
.reel-action-icon {
  width: 46px; height: 46px; border-radius: 50%;
  background: rgba(255,255,255,.15); backdrop-filter: blur(10px);
  border: 1px solid rgba(255,255,255,.2);
  display: flex; align-items: center; justify-content: center;
  font-size: 1.15rem; transition: background .15s, transform .1s;
}
.reel-action-btn:active .reel-action-icon { transform: scale(.88); }
.reel-action-btn.is-liked .reel-action-icon { background: rgba(229,9,20,.35); border-color: rgba(229,9,20,.6); }
.reel-action-btn.is-liked .reel-action-icon i { color: #ff4d5a; }
.reel-action-btn.is-saved .reel-action-icon { background: rgba(255,204,0,.2); border-color: rgba(255,204,0,.4); }
.reel-action-btn.is-saved .reel-action-icon i { color: #ffcc00; }
.reel-action-label { font-size: .65rem; color: rgba(255,255,255,.75); font-weight: 600; }
.reel-mute-btn {
  position: absolute; top: 68px; right: 14px; z-index: 20;
  width: 34px; height: 34px; border-radius: 50%;
  background: rgba(0,0,0,.45); backdrop-filter: blur(8px);
  border: 1px solid rgba(255,255,255,.2);
  color: #fff; font-size: .85rem; cursor: pointer;
  display: none; align-items: center; justify-content: center;
}
.reel-loader {
  display: flex; align-items: center; justify-content: center; height: 100dvh;
  scroll-snap-align: start;
}
.reel-spinner {
  width: 40px; height: 40px; border-radius: 50%;
  border: 3px solid rgba(255,255,255,.12); border-top-color: var(--primary);
  animation: spin .8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* Comment Sheet */
.reel-sheet-backdrop {
  position: fixed; inset: 0; background: rgba(0,0,0,.6);
  z-index: 200; opacity: 0; pointer-events: none; transition: opacity .3s;
}
.reel-sheet-backdrop.open { opacity: 1; pointer-events: all; }
.reel-sheet {
  position: fixed; bottom: 0; left: 0; right: 0; z-index: 201;
  background: #141420; border-radius: 22px 22px 0 0;
  transform: translateY(100%); transition: transform .35s cubic-bezier(.16,1,.3,1);
  max-height: 75dvh; display: flex; flex-direction: column;
  padding-bottom: env(safe-area-inset-bottom);
}
.reel-sheet.open { transform: translateY(0); }
.reel-sheet-handle {
  width: 36px; height: 4px; background: rgba(255,255,255,.2);
  border-radius: 2px; margin: 12px auto 0; flex-shrink: 0;
}
.reel-sheet-head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 18px 8px; border-bottom: 1px solid rgba(255,255,255,.07); flex-shrink: 0;
}
.reel-sheet-head h3 { font-size: .95rem; font-weight: 700; margin: 0; }
.reel-sheet-close { background: none; border: none; color: rgba(255,255,255,.5); font-size: 1.1rem; cursor: pointer; padding: 4px; }
.reel-comments-list {
  flex: 1; overflow-y: auto; padding: 10px 16px;
  scrollbar-width: thin; scrollbar-color: rgba(255,255,255,.1) transparent;
}
.reel-comment-item { display: flex; gap: 10px; padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,.05); }
.reel-comment-avatar {
  width: 32px; height: 32px; border-radius: 50%; flex-shrink: 0;
  background: var(--primary); display: flex; align-items: center; justify-content: center;
  font-size: .8rem; font-weight: 700; color: #fff;
}
.reel-comment-body { flex: 1; }
.reel-comment-user { font-size: .8rem; font-weight: 700; color: #fff; }
.reel-comment-text { font-size: .82rem; color: rgba(255,255,255,.7); margin-top: 2px; line-height: 1.4; }
.reel-sheet-input {
  display: flex; gap: 10px; padding: 10px 16px 12px;
  border-top: 1px solid rgba(255,255,255,.07); flex-shrink: 0;
}
.reel-sheet-input input {
  flex: 1; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.12);
  border-radius: 999px; padding: 9px 16px; color: #fff; font-size: .88rem;
  font-family: inherit; outline: none;
}
.reel-sheet-input input::placeholder { color: rgba(255,255,255,.35); }
.reel-send-btn {
  width: 38px; height: 38px; border-radius: 50%; flex-shrink: 0;
  background: var(--primary); border: none; color: #fff;
  font-size: .9rem; cursor: pointer; display: flex; align-items: center; justify-content: center;
}
.reel-no-login { padding: 14px 16px; font-size: .85rem; color: rgba(255,255,255,.45); text-align: center; flex: 1; }
.reel-no-login a { color: var(--primary); }
.reel-empty-comments { padding: 30px 0; text-align: center; color: rgba(255,255,255,.3); font-size: .85rem; }
</style>

<div class="reels-page" id="reelsPage">
  <div class="reels-topbar">
    <button class="reels-back" onclick="history.back()"><i class="fa-solid fa-arrow-left"></i></button>
    <span class="reels-topbar-title"><i class="fa-solid fa-clapperboard" style="color:var(--primary)"></i> Reels</span>
    <div style="width:38px"></div>
  </div>
  <div class="reels-feed" id="reelsFeed"></div>
</div>

<div class="reel-sheet-backdrop" id="sheetBackdrop" onclick="closeSheet()"></div>
<div class="reel-sheet" id="reelSheet">
  <div class="reel-sheet-handle"></div>
  <div class="reel-sheet-head">
    <h3>التعليقات</h3>
    <button class="reel-sheet-close" onclick="closeSheet()"><i class="fa-solid fa-xmark"></i></button>
  </div>
  <div class="reel-comments-list" id="commentsList"></div>
  <div class="reel-sheet-input">
    <?php if ($cur_user): ?>
      <input type="text" id="commentInput" placeholder="أضف تعليقاً…" maxlength="300" />
      <button class="reel-send-btn" id="sendCommentBtn"><i class="fa-solid fa-paper-plane"></i></button>
    <?php else: ?>
      <div class="reel-no-login"><a href="/login">سجّل دخول</a> للتعليق</div>
    <?php endif; ?>
  </div>
</div>

<script>
'use strict';
const LOGGED_IN = <?= $cur_user ? 'true' : 'false' ?>;
const API = '?ajax=1&action=';

let reelsData=[], currentIdx=0, apiPage=Math.ceil(Math.random()*4)+1, loading=false, muted=true, sheetItemId=null, sheetItemType=null;
const feed = document.getElementById('reelsFeed');

// ── localStorage للإعجابات والحفظ (guest) ──────────────────────────────
function getLiked() { try { return JSON.parse(localStorage.getItem('rl_likes')||'{}'); } catch { return {}; } }
function setLiked(o) { localStorage.setItem('rl_likes', JSON.stringify(o)); }
function getSaved() { try { return JSON.parse(localStorage.getItem('rl_saved')||'{}'); } catch { return {}; } }
function setSaved(o) { localStorage.setItem('rl_saved', JSON.stringify(o)); }

function esc(s) { const d=document.createElement('div'); d.textContent=s||''; return d.innerHTML; }

// ── جلب ريلز ──────────────────────────────────────────────────────────
async function loadReels() {
  if (loading) return; loading=true;
  const loader=document.getElementById('reelLoader');
  if (loader) loader.style.display='flex';
  try {
    const res=await fetch(API+'reels&page='+apiPage++);
    const data=await res.json();
    if (data.ok && data.reels.length) {
      const si=reelsData.length;
      reelsData.push(...data.reels);
      data.reels.forEach((r,i)=>feed.insertBefore(buildSlide(r,si+i), loader||null));
    }
  } catch(e){}
  loading=false;
  if (loader) loader.style.display='none';
}

// ── بناء شريحة ────────────────────────────────────────────────────────
function buildSlide(r, idx) {
  const liked_cls = getLiked()[r.id] ? ' is-liked' : '';
  const saved_cls = getSaved()[r.id] ? ' is-saved' : '';
  const genres    = (r.genres||[]).map(g=>`<span class="reel-genre-tag">${esc(g)}</span>`).join('');
  const ov        = r.overview ? r.overview.slice(0,110)+(r.overview.length>110?'…':'') : '';
  const bg        = r.backdrop||r.poster;

  const div=document.createElement('div');
  div.className='reel-slide';
  div.dataset.idx=idx; div.dataset.id=r.id; div.dataset.type=r.type;
  div.innerHTML=`
    <div class="reel-bg" style="background-image:url('${bg}')"></div>
    <div class="reel-poster" id="poster-${idx}" style="background-image:url('${bg}')" onclick="startPlay(${idx})">
      <button class="reel-play-btn" aria-label="تشغيل"><i class="fa-solid fa-play"></i></button>
    </div>
    <div class="reel-player" id="player-${idx}"></div>
    <div class="reel-bottom-fade"></div>
    <button class="reel-mute-btn" id="mute-${idx}" onclick="toggleMute(${idx})">
      <i class="fa-solid fa-volume-xmark"></i>
    </button>
    <div class="reel-info">
      <h2>${esc(r.title)}</h2>
      <div class="reel-meta">
        <span class="reel-type-badge">${r.type==='tv'?'TV':'Movie'}</span>
        ${r.year?`<span>${r.year}</span>`:''}
        ${r.rating>0?`<span>⭐ ${r.rating}</span>`:''}
      </div>
      ${genres?`<div class="reel-genres">${genres}</div>`:''}
      ${ov?`<p class="reel-overview">${esc(ov)}</p>`:''}
      <a class="reel-watch-btn" href="${r.watch_url}"><i class="fa-solid fa-play"></i> شاهد الآن</a>
    </div>
    <div class="reel-actions">
      <button class="reel-action-btn${liked_cls}" id="like-${idx}" onclick="toggleLike(${idx})">
        <div class="reel-action-icon"><i class="fa-solid fa-heart"></i></div>
        <span class="reel-action-label">إعجاب</span>
      </button>
      <button class="reel-action-btn" onclick="openSheet(${idx})">
        <div class="reel-action-icon"><i class="fa-regular fa-comment"></i></div>
        <span class="reel-action-label">تعليق</span>
      </button>
      <button class="reel-action-btn" onclick="shareReel(${idx})">
        <div class="reel-action-icon"><i class="fa-solid fa-share-nodes"></i></div>
        <span class="reel-action-label">مشاركة</span>
      </button>
      <button class="reel-action-btn${saved_cls}" id="save-${idx}" onclick="toggleSave(${idx})">
        <div class="reel-action-icon"><i class="fa-${getSaved()[r.id]?'solid':'regular'} fa-bookmark"></i></div>
        <span class="reel-action-label">حفظ</span>
      </button>
    </div>`;
  return div;
}

// ── تشغيل / إيقاف ────────────────────────────────────────────────────
function startPlay(idx) {
  const r=reelsData[idx]; if(!r) return;
  const poster=document.getElementById('poster-'+idx);
  const cont=document.getElementById('player-'+idx);
  const muteBtn=document.getElementById('mute-'+idx);
  if(poster){poster.style.opacity='0';poster.style.pointerEvents='none';}
  if(muteBtn) muteBtn.style.display='flex';
  if(!cont.querySelector('iframe')){
    const fr=document.createElement('iframe');
    fr.src=`https://www.youtube-nocookie.com/embed/${r.trailer_key}?autoplay=1&mute=1&loop=1&playlist=${r.trailer_key}&controls=1&rel=0&iv_load_policy=3`;
    fr.allow='autoplay; fullscreen; encrypted-media; picture-in-picture';
    fr.setAttribute('allowfullscreen','');
    cont.classList.add('playing'); cont.appendChild(fr);
    muted=true;
  }
}

function stopReel(idx) {
  const cont=document.getElementById('player-'+idx);
  const poster=document.getElementById('poster-'+idx);
  const muteBtn=document.getElementById('mute-'+idx);
  if(!cont) return;
  const fr=cont.querySelector('iframe');
  if(fr){fr.src='';cont.innerHTML='';cont.classList.remove('playing');}
  if(poster){poster.style.opacity='1';poster.style.pointerEvents='auto';}
  if(muteBtn) muteBtn.style.display='none';
}

function toggleMute(idx) {
  muted=!muted;
  const btn=document.getElementById('mute-'+idx);
  if(btn) btn.innerHTML=muted?'<i class="fa-solid fa-volume-xmark"></i>':'<i class="fa-solid fa-volume-high"></i>';
  const r=reelsData[idx]; const cont=document.getElementById('player-'+idx);
  if(!r||!cont) return;
  cont.innerHTML='';
  const fr=document.createElement('iframe');
  fr.src=`https://www.youtube-nocookie.com/embed/${r.trailer_key}?autoplay=1&mute=${muted?1:0}&loop=1&playlist=${r.trailer_key}&controls=1&rel=0&iv_load_policy=3`;
  fr.allow='autoplay; fullscreen; encrypted-media; picture-in-picture';
  fr.setAttribute('allowfullscreen','');
  cont.appendChild(fr);
}

// ── Observer ──────────────────────────────────────────────────────────
const observer=new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    const idx=parseInt(e.target.dataset.idx);
    if(e.isIntersecting){ currentIdx=idx; if(idx>=reelsData.length-3) loadReels(); }
    else stopReel(idx);
  });
},{root:feed,threshold:0.5});

// ── إعجاب ─────────────────────────────────────────────────────────────
async function toggleLike(idx) {
  const r=reelsData[idx]; const btn=document.getElementById('like-'+idx);
  if(!r||!btn) return;
  const liked=!!getLiked()[r.id];
  const obj=getLiked();
  liked ? delete obj[r.id] : obj[r.id]=1;
  setLiked(obj);
  btn.classList.toggle('is-liked',!liked);
  if(LOGGED_IN) {
    const fd=new FormData(); fd.append('id',r.id); fd.append('type',r.type);
    await fetch(API+'toggle_like',{method:'POST',body:fd}).catch(()=>{});
  }
}

// ── حفظ ───────────────────────────────────────────────────────────────
async function toggleSave(idx) {
  const r=reelsData[idx]; const btn=document.getElementById('save-'+idx);
  if(!r||!btn) return;
  const saved=!!getSaved()[r.id];
  const obj=getSaved();
  saved ? delete obj[r.id] : obj[r.id]=1;
  setSaved(obj);
  btn.classList.toggle('is-saved',!saved);
  const icon=btn.querySelector('i');
  if(icon) icon.className=saved?'fa-regular fa-bookmark':'fa-solid fa-bookmark';
  if(LOGGED_IN) {
    const fd=new FormData(); fd.append('id',r.id); fd.append('type',r.type); fd.append('title',r.title); fd.append('poster',r.poster);
    await fetch(API+'toggle_save',{method:'POST',body:fd}).catch(()=>{});
  }
}

// ── مشاركة ────────────────────────────────────────────────────────────
async function shareReel(idx) {
  const r=reelsData[idx]; if(!r) return;
  const url=location.origin+r.detail_url;
  if(navigator.share){ try{await navigator.share({title:r.title,url});return;}catch{} }
  await navigator.clipboard?.writeText(url).catch(()=>{});
  showToast('تم نسخ الرابط!');
}

function showToast(msg) {
  let t=document.getElementById('reelToast');
  if(!t){t=document.createElement('div');t.id='reelToast';Object.assign(t.style,{position:'fixed',bottom:'100px',left:'50%',transform:'translateX(-50%)',background:'rgba(255,255,255,.15)',backdropFilter:'blur(12px)',color:'#fff',padding:'8px 18px',borderRadius:'999px',fontSize:'.85rem',fontWeight:'600',zIndex:'999',transition:'opacity .3s',border:'1px solid rgba(255,255,255,.2)',whiteSpace:'nowrap'});document.body.appendChild(t);}
  t.textContent=msg;t.style.opacity='1';
  clearTimeout(t._to); t._to=setTimeout(()=>t.style.opacity='0',2000);
}

// ── تعليقات ───────────────────────────────────────────────────────────
async function openSheet(idx) {
  const r=reelsData[idx]; if(!r) return;
  sheetItemId=r.id; sheetItemType=r.type;
  document.getElementById('sheetBackdrop').classList.add('open');
  document.getElementById('reelSheet').classList.add('open');
  const list=document.getElementById('commentsList');
  list.innerHTML='<div class="reel-empty-comments"><i class="fa-solid fa-spinner fa-spin"></i></div>';
  try {
    const res=await fetch(API+'get_comments&id='+r.id+'&type='+r.type);
    const data=await res.json();
    renderComments(data.comments||[]);
  } catch { list.innerHTML='<div class="reel-empty-comments">تعذّر تحميل التعليقات</div>'; }
}

function renderComments(comments) {
  const list=document.getElementById('commentsList');
  if(!comments.length){list.innerHTML='<div class="reel-empty-comments">لا تعليقات بعد — كن الأول!</div>';return;}
  list.innerHTML=comments.map(c=>`
    <div class="reel-comment-item">
      <div class="reel-comment-avatar">${(c.username||'?')[0].toUpperCase()}</div>
      <div class="reel-comment-body">
        <div class="reel-comment-user">${esc(c.username||'User')}</div>
        <div class="reel-comment-text">${esc(c.body||'')}</div>
      </div>
    </div>`).join('');
}

function closeSheet() {
  document.getElementById('sheetBackdrop').classList.remove('open');
  document.getElementById('reelSheet').classList.remove('open');
}

const sendBtn=document.getElementById('sendCommentBtn');
const commentInput=document.getElementById('commentInput');
if(sendBtn&&commentInput){
  sendBtn.addEventListener('click',async()=>{
    const text=commentInput.value.trim();
    if(!text||!sheetItemId) return;
    const fd=new FormData(); fd.append('id',sheetItemId); fd.append('type',sheetItemType); fd.append('body',text);
    try {
      const res=await fetch(API+'add_comment',{method:'POST',body:fd});
      const data=await res.json();
      if(data.ok){
        commentInput.value='';
        const list=document.getElementById('commentsList');
        const ph=list.querySelector('.reel-empty-comments'); if(ph) ph.remove();
        const item=document.createElement('div');
        item.className='reel-comment-item';
        item.innerHTML=`<div class="reel-comment-avatar">${(data.comment?.username||'?')[0].toUpperCase()}</div><div class="reel-comment-body"><div class="reel-comment-user">${esc(data.comment?.username||'أنت')}</div><div class="reel-comment-text">${esc(text)}</div></div>`;
        list.appendChild(item); list.scrollTop=list.scrollHeight;
      }
    } catch{}
  });
  commentInput.addEventListener('keydown',e=>{if(e.key==='Enter') sendBtn.click();});
}

// ── تهيئة ─────────────────────────────────────────────────────────────
function addLoader(){const d=document.createElement('div');d.id='reelLoader';d.className='reel-loader';d.innerHTML='<div class="reel-spinner"></div>';feed.appendChild(d);}

addLoader();
loadReels().then(()=>{ feed.querySelectorAll('.reel-slide').forEach(s=>observer.observe(s)); });
const mutObs=new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(n=>{if(n.classList?.contains('reel-slide')) observer.observe(n);})));
mutObs.observe(feed,{childList:true});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
ENDOFFILE
echo "تم"