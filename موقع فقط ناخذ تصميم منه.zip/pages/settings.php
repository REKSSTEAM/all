<?php
$page_title = 'Settings';
$active     = 'settings';
$user       = auth_user();
include __DIR__ . '/../includes/header.php';
?>

<section class="settings-page">
  <div class="settings-heading">
    <span class="eyebrow">PERSONALIZE YOUR EXPERIENCE</span>
    <h1>Settings</h1>
    <p>Make AFVeo feel like your own streaming space.</p>
  </div>

  <div class="settings-layout">
    <aside class="settings-index" aria-label="Settings sections">
      <a href="#account" class="settings-index-link is-active"><i class="fa-regular fa-user"></i><span>Account</span></a>
      <a href="#appearance" class="settings-index-link"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Appearance</span></a>
      <a href="#subtitle" class="settings-index-link"><i class="fa-solid fa-closed-captioning"></i><span>Subtitle</span></a>
      <a href="#player" class="settings-index-link"><i class="fa-solid fa-sliders"></i><span>Player Center</span></a>
    </aside>

    <div class="settings-content">
      <section class="settings-section" id="account">
        <div class="settings-section-heading"><span class="settings-number">01</span><div><h2>Account</h2><p>Manage your profile and access.</p></div></div>
        <div class="settings-card account-settings-card">
          <?php if ($user): ?>
            <div class="settings-account-summary">
              <span class="settings-account-avatar"><?= mb_strtoupper(mb_substr($user['username'], 0, 1)) ?></span>
              <div><strong><?= htmlspecialchars($user['username']) ?></strong><small><?= htmlspecialchars($user['email']) ?></small></div>
              <a class="settings-card-action" href="/profile">View profile <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
            </div>
            <a class="settings-row settings-row-danger" href="/logout"><span><i class="fa-solid fa-right-from-bracket"></i> Sign out</span><i class="fa-solid fa-chevron-right"></i></a>
          <?php else: ?>
            <a class="settings-row" href="/login"><span><i class="fa-regular fa-user"></i> Log in</span><i class="fa-solid fa-chevron-right"></i></a>
            <a class="settings-row" href="/register"><span><i class="fa-solid fa-user-plus"></i> Sign up</span><i class="fa-solid fa-chevron-right"></i></a>
          <?php endif; ?>
        </div>
      </section>

      <section class="settings-section" id="appearance">
        <div class="settings-section-heading"><span class="settings-number">02</span><div><h2>Appearance</h2><p>Choose how the interface looks.</p></div></div>
        <div class="settings-card">
          <label class="setting-control"><span>Mode</span><select data-setting="mode"><option value="system">System</option><option value="dark">Dark</option><option value="light">Light</option></select></label>
          <label class="setting-control"><span>Auto accent color</span><select data-setting="autoAccent"><option value="enabled">Enable</option><option value="disabled">Disable</option></select></label>
          <label class="setting-control"><span>Accent color</span><select data-setting="accent"><option value="gold">Gold</option><option value="red">Red</option><option value="violet">Violet</option></select></label>
          <label class="setting-control"><span>System font family</span><select data-setting="font"><option value="bricolage">Bricolage Grotesque</option><option value="inter">Inter</option><option value="system">System default</option></select></label>
        </div>
        <div class="settings-preview"><span class="settings-preview-label">Preview</span><strong>Make every watch session feel yours.</strong><span class="settings-preview-subtitle" data-subtitle-preview>Subtitle preview · The night is still young.</span></div>
      </section>

      <section class="settings-section" id="subtitle">
        <div class="settings-section-heading"><span class="settings-number">03</span><div><h2>Subtitle</h2><p>Set your preferred subtitle presentation.</p></div></div>
        <div class="settings-card">
          <label class="setting-control"><span>Subtitle font family</span><select data-setting="subtitleFont"><option value="bricolage">Bricolage Grotesque</option><option value="inter">Inter</option><option value="system">System default</option></select></label>
          <label class="setting-control"><span>Subtitle font size</span><select data-setting="subtitleSize"><option value="100">100%</option><option value="90">90%</option><option value="110">110%</option><option value="125">125%</option></select></label>
          <label class="setting-control"><span>Subtitle font color</span><select data-setting="subtitleColor"><option value="gold">Gold</option><option value="white">White</option><option value="yellow">Yellow</option></select></label>
          <label class="setting-control"><span>Subtitle background color</span><select data-setting="subtitleBackground"><option value="transparent">Transparent</option><option value="black">Black</option><option value="gray">Gray</option></select></label>
          <label class="setting-control"><span>Subtitle background blurness</span><select data-setting="subtitleBlur"><option value="0">0%</option><option value="25">25%</option><option value="50">50%</option></select></label>
          <label class="setting-control"><span>Subtitle opacity</span><select data-setting="subtitleOpacity"><option value="100">100%</option><option value="75">75%</option><option value="50">50%</option></select></label>
          <label class="setting-control"><span>Subtitle margin</span><select data-setting="subtitleMargin"><option value="4">4%</option><option value="2">2%</option><option value="6">6%</option></select></label>
        </div>
      </section>

      <section class="settings-section" id="player">
        <div class="settings-section-heading"><span class="settings-number">04</span><div><h2>Player Center</h2><p>Save playback preferences for your next session.</p></div></div>
        <div class="settings-card">
          <label class="setting-control"><span>Autoplay</span><select data-setting="autoplay"><option value="on">On</option><option value="off">Off</option></select></label>
          <label class="setting-control"><span>Auto next episode</span><select data-setting="autoNext"><option value="on">On</option><option value="off">Off</option></select></label>
          <label class="setting-control"><span>Skip intro</span><select data-setting="skipIntro"><option value="enabled">Enable</option><option value="disabled">Disable</option></select></label>
          <label class="setting-control"><span>Default server</span><select data-setting="server"><option value="auto">Auto select</option><option value="vidsrc">VidSrc</option><option value="newserver">New Server</option></select></label>
          <label class="setting-control"><span>Default quality</span><select data-setting="quality"><option value="auto">Auto</option><option value="1080">1080p</option><option value="720">720p</option></select></label>
          <label class="setting-control"><span>Remember last server</span><select data-setting="rememberServer"><option value="enabled">Enable</option><option value="disabled">Disable</option></select></label>
          <label class="setting-control"><span>Player layout</span><select data-setting="playerLayout"><option value="cinema">Cinema</option><option value="compact">Compact</option></select></label>
        </div>
        <div class="settings-note"><i class="fa-solid fa-circle-info"></i><span>These preferences are saved on this device. Streaming servers and the player remain unchanged.</span></div>
      </section>
    </div>
  </div>
</section>

<script>
(() => {
  const defaults = { mode:'light', autoAccent:'enabled', accent:'gold', font:'bricolage', subtitleFont:'bricolage', subtitleSize:'100', subtitleColor:'gold', subtitleBackground:'transparent', subtitleBlur:'0', subtitleOpacity:'100', subtitleMargin:'4', autoplay:'on', autoNext:'on', skipIntro:'enabled', server:'auto', quality:'auto', rememberServer:'enabled', playerLayout:'cinema' };
  const key = 'afveo_settings';
  const root = document.documentElement;
  const accentMap = { gold:'#f4d33f', red:'#ff5661', violet:'#b58cff' };
  const fontMap = { bricolage:"'Bricolage Grotesque', sans-serif", inter:"'Inter', sans-serif", system:"system-ui, sans-serif" };
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(key) || '{}'); } catch (_) {}
  const applySettings = () => {
    const mode = saved.mode || defaults.mode;
    const resolvedMode = mode === 'system'
      ? (window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark')
      : mode;
    root.dataset.mode = resolvedMode;
    root.dataset.accent = saved.accent || defaults.accent;
    root.style.setProperty('--accent', accentMap[saved.accent || defaults.accent] || accentMap.gold);
    root.style.setProperty('--ui-font', fontMap[saved.font || defaults.font] || fontMap.bricolage);
    root.style.setProperty('--subtitle-font', fontMap[saved.subtitleFont || defaults.subtitleFont] || fontMap.bricolage);
    root.style.setProperty('--subtitle-size', (saved.subtitleSize || defaults.subtitleSize) + '%');
    root.style.setProperty('--subtitle-color', saved.subtitleColor === 'white' ? '#fff' : saved.subtitleColor === 'yellow' ? '#ffe76a' : accentMap.gold);
    root.style.setProperty('--subtitle-opacity', (saved.subtitleOpacity || defaults.subtitleOpacity) / 100);
    root.style.setProperty('--subtitle-margin', (saved.subtitleMargin || defaults.subtitleMargin) + '%');
    root.dataset.subtitleBackground = saved.subtitleBackground || defaults.subtitleBackground;
    root.dataset.subtitleBlur = saved.subtitleBlur || defaults.subtitleBlur;
    document.querySelectorAll('[data-subtitle-preview]').forEach(preview => {
      preview.style.fontFamily = fontMap[saved.subtitleFont || defaults.subtitleFont];
      preview.style.fontSize = `calc(.86rem * ${saved.subtitleSize || defaults.subtitleSize} / 100)`;
      preview.style.color = root.style.getPropertyValue('--subtitle-color');
      preview.style.opacity = root.style.getPropertyValue('--subtitle-opacity');
    });
  };
  document.querySelectorAll('[data-setting]').forEach(control => {
    const name = control.dataset.setting;
    control.value = saved[name] ?? defaults[name];
    control.addEventListener('change', () => {
      saved[name] = control.value;
      localStorage.setItem(key, JSON.stringify(saved));
      applySettings();
    });
  });
  applySettings();
  const media = window.matchMedia('(prefers-color-scheme: light)');
  media.addEventListener?.('change', () => { if ((saved.mode || defaults.mode) === 'system') applySettings(); });
  document.querySelectorAll('.settings-index-link').forEach(link => link.addEventListener('click', () => {
    document.querySelectorAll('.settings-index-link').forEach(item => item.classList.remove('is-active'));
    link.classList.add('is-active');
  }));
})();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>