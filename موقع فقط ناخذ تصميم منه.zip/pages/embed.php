<?php
/**
 * AFVeo Embed API
 * ──────────────────────────────────────────────────────────────
 * /embed/movie/{TMDB_ID}
 * /embed/tv/{TMDB_ID}/{season}/{episode}
 *
 * مثال:
 * <iframe src="https://afflix.xo.je/embed/movie/550"
 *         width="100%" style="aspect-ratio:16/9"
 *         allowfullscreen allow="autoplay; encrypted-media">
 * </iframe>
 */

// إعداد CORS — يسمح لأي موقع يستخدم الـ embed
header('Access-Control-Allow-Origin: *');
header('X-Frame-Options: ALLOWALL');
header('Content-Security-Policy: frame-ancestors *');

// جلب المعاملات من URL
// router.php يمرر: type, id, season, episode
$type    = ($_GET['type']    ?? 'movie') === 'tv' ? 'tv' : 'movie';
$id      = (int)($_GET['id'] ?? 0);
$season  = max(1, (int)($_GET['season']  ?? 1));
$episode = max(1, (int)($_GET['episode'] ?? 1));

// خيارات تخصيص
$color   = preg_replace('/[^a-fA-F0-9]/', '', $_GET['color'] ?? '');  // لون hex بدون #
$logo    = $_GET['logo']  ?? '';   // رابط لوغو مخصص
$title_override = $_GET['title'] ?? ''; // عنوان مخصص

if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'TMDB ID required']);
    exit;
}

// جلب بيانات TMDB
$d     = tmdb_details($type, $id);
$title = $title_override ?: ($d['title'] ?? $d['name'] ?? 'Watch');

// بناء رابط البلاير
$stream_token = sec_stream_token($type, $id);
$player_qs = http_build_query(array_filter([
    'type'    => $type,
    'id'      => $id,
    'season'  => $type === 'tv' ? $season  : null,
    'episode' => $type === 'tv' ? $episode : null,
    'title'   => $title,
    '_st'     => $stream_token,
    'color'   => $color ?: null,
    'logo'    => $logo  ?: null,
]));

$player_src = '/player/index.html?' . $player_qs;

// primary color
$primary = $color ? '#' . $color : '#6c63ff';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover"/>
<title><?= htmlspecialchars($title) ?></title>
<meta name="robots" content="noindex"/>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  html,body{width:100%;height:100%;background:#000;overflow:hidden}
  #player-frame{position:fixed;inset:0;width:100%;height:100%;border:0;background:#000}
</style>
</head>
<body>
<iframe id="player-frame"
        src="<?= htmlspecialchars($player_src) ?>"
        allow="autoplay; fullscreen; picture-in-picture; encrypted-media; accelerometer; gyroscope"
        allowfullscreen></iframe>
<script>
// تمرير events من البلاير للصفحة الأم
window.addEventListener('message', function(e) {
    try {
        var data = typeof e.data === 'string' ? JSON.parse(e.data) : e.data;
        window.parent.postMessage(data, '*');
    } catch(err) {}
});
</script>
</body>
</html>
