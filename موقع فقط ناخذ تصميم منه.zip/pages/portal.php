<?php
$portal = $_GET['portal'] ?? 'discover';
$labels = [
    'ai' => ['AI Assistant', 'Find something perfect to watch with a little help.', 'fa-robot'],
    'livesports' => ['Live Sports', 'Your live sports hub is ready for upcoming events.', 'fa-futbol'],
    'iptv' => ['IPTV', 'Browse your live television channels.', 'fa-satellite-dish'],
    'radio' => ['Radio', 'Listen to stations from around the world.', 'fa-radio'],
    'manga' => ['Manga', 'Keep your reading list in one place.', 'fa-book-open'],
    'kdrama' => ['K-Drama', 'Discover popular Korean series and films.', 'fa-clapperboard'],
];
[$heading, $description, $icon] = $labels[$portal] ?? $labels['ai'];
$active = $portal;
$page_title = $heading;
include __DIR__ . '/../includes/header.php';
?>
<section class="rive-page portal-page">
  <div class="portal-hero">
    <div class="portal-icon"><i class="fa-solid <?= $icon ?>"></i></div>
    <span class="rive-eyebrow">RIVE COLLECTION</span>
    <h1><?= htmlspecialchars($heading) ?></h1>
    <p><?= htmlspecialchars($description) ?></p>
  </div>
  <div class="portal-grid">
    <div class="portal-card"><i class="fa-solid fa-sparkles"></i><h3>Coming soon</h3><p>This space is connected to the same navigation and settings system.</p></div>
    <div class="portal-card"><i class="fa-solid fa-bookmark"></i><h3>Your library</h3><p>Save titles from the movie and TV pages to access them here.</p><a href="/library" class="btn btn-ghost">Open library</a></div>
    <div class="portal-card"><i class="fa-solid fa-compass"></i><h3>Explore titles</h3><p>Browse the catalog and discover something new to watch.</p><a href="/discover" class="btn btn-primary">Explore now</a></div>
  </div>
</section>
<?php include __DIR__ . '/../includes/footer.php'; ?>