<?php
// PHP built-in server router for the uploaded htdocs project.
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$file = __DIR__ . $path;

// Older player builds may still call this path. Preserve POST semantics.
if (str_starts_with($path, '/vyla/auth/api/')) {
    $target = '/api/' . substr($path, strlen('/vyla/auth/api/'));
    $query = $_SERVER['QUERY_STRING'] ?? '';
    http_response_code(307);
    header('Location: ' . $target . ($query !== '' ? '?' . $query : ''));
    exit;
}

$basename = basename($path);
$extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
$blockedPrefixes = [
    '/.git/', '/.agents/', '/.local/', '/.cache/', '/vendor/', '/node_modules/',
    '/includes/', '/data/', '/extractor/', '/videasy/', '/watch-party/',
];
$blockedExtensions = ['zip', 'tar', 'gz', 'sql', 'env', 'bak', 'log', 'json'];
$blockedExact = [
    '/.htaccess', '/.replit', '/replit.nix', '/php.ini', '/config.php',
    '/router.php', '/composer.json', '/composer.lock',
];

if (($basename !== '' && $basename[0] === '.') ||
    in_array($path, $blockedExact, true) ||
    ($extension !== '' && in_array($extension, $blockedExtensions, true))) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Forbidden';
    return true;
}

foreach ($blockedPrefixes as $prefix) {
    if (str_starts_with($path, $prefix)) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Forbidden';
        return true;
    }
}

if (str_starts_with($path, '/api/')) {
    require __DIR__ . '/index.php';
    return true;
}

if ($path !== '/' && is_file($file)) {
    return false;
}

require __DIR__ . '/index.php';
