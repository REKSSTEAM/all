<?php
// Site configuration
if (session_status() === PHP_SESSION_NONE) session_start();

define('SITE_NAME', 'AFVeo');
define('SITE_DESC', 'Movies & TV Shows - شاهد بلا حدود');

// ── Security ──────────────────────────────────────────────────────────────────
// APP_SECRET: used for HMAC signing of stream tokens and security hashes.
// Set SESSION_SECRET in Replit Secrets (or any env var) to a long random string.
define('APP_SECRET', getenv('SESSION_SECRET') ?: 'fallback_CHANGE_THIS_in_production');
// مفتاح عميل Android لمسار API المخصص. يمكن استبداله بمتغير البيئة AFVEO_MOBILE_API_KEY.
define('AFVEO_MOBILE_API_KEY', getenv('AFVEO_MOBILE_API_KEY') ?: 'afv_mobile_65da7d33dbbecae8a2f4cda9167c21c27a98007c99431934d0fe1699ebe5de60');

// TMDB API
define('TMDB_API_KEY', getenv('TMDB_API_KEY') ?: '60a8d6ad3b8e5fbdbde539526b196d9b');

// Subdl subtitle API
define('SUBDL_API_KEY', getenv('SUBDL_API_KEY') ?: '');
define('TMDB_API_URL', 'https://api.themoviedb.org/3');
define('TMDB_IMG', 'https://image.tmdb.org/t/p');

// Base URL
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
define('BASE_URL', $scheme . '://' . $host);

// ── EmbedMaster (embdmstrplayer.com) ────────────────────────────────────────
// cf_clearance: cookie من embdmstrplayer.com (تنتهي كل ~30 دقيقة، جدّدها من المتصفح)
// cf-turnstile-response: رمز Turnstile من الصفحة (اختياري — يُساعد في تجاوز التحقق)
define('EMBEDMASTER_CF_CLEARANCE', getenv('EMBEDMASTER_CF_CLEARANCE') ?: '');
define('EMBEDMASTER_TURNSTILE',    getenv('EMBEDMASTER_TURNSTILE')    ?: '');

// xpass.top credentials — set these in Replit Secrets (or environment variables).
// XPASS_AUTH_TOKEN: auth_token cookie from play.xpass.top
// XPASS_CF_CLEARANCE: Cloudflare clearance cookie (expires ~30 min, update as needed)
define('XPASS_AUTH_TOKEN',  getenv('XPASS_AUTH_TOKEN')  ?: '');
define('XPASS_CF_CLEARANCE', getenv('XPASS_CF_CLEARANCE') ?: '');

error_reporting(E_ALL);
ini_set('display_errors', 0);   // لا نكشف أخطاء داخلية للمستخدم
ini_set('log_errors', 1);
date_default_timezone_set('UTC');

// Security middleware يجب أن يُحمَّل أولاً
require_once __DIR__ . '/includes/security.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/hz_fetch.php';
