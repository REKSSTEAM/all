<?php
// includes/opensubtitles.php
// مصدر الترجمة الرئيسي: OpenSubtitles REST API v1 (https://api.opensubtitles.com)
// المتغيرات (Replit Secrets / environment):
//   OPENSUBTITLES_API_KEY   مفتاح Consumer من حسابك على opensubtitles.com
//   OPENSUBTITLES_USERNAME  اسم المستخدم   (مطلوب للتحميل)
//   OPENSUBTITLES_PASSWORD  كلمة السر       (مطلوب للتحميل)

if (!defined('OS_API_KEY'))   define('OS_API_KEY',   (string)(getenv('OPENSUBTITLES_API_KEY')  ?: ''));
if (!defined('OS_USERNAME'))  define('OS_USERNAME',  (string)(getenv('OPENSUBTITLES_USERNAME') ?: ''));
if (!defined('OS_PASSWORD'))  define('OS_PASSWORD',  (string)(getenv('OPENSUBTITLES_PASSWORD') ?: ''));
if (!defined('OS_USER_AGENT')) define('OS_USER_AGENT', 'AFVeo v1.0');
if (!defined('OS_LANGUAGES')) define('OS_LANGUAGES', 'ar,en');   // اللغات المطلوبة (اللغة الأولى هي الأهم)
if (!defined('OS_MAX_PER_LANG')) define('OS_MAX_PER_LANG', 3);   // كم نسخة نرسل للمشغّل لكل لغة (كل نسخة = تحميل واحد من حصتك)
if (!defined('OS_SEARCH_TTL')) define('OS_SEARCH_TTL', 12 * 3600);

function os_configured(): bool {
    return OS_API_KEY !== '';
}

function os_cache_dir(): string {
    $d = __DIR__ . '/../data/cache/opensubtitles';
    if (!is_dir($d)) @mkdir($d, 0777, true);
    return $d;
}

function os_files_dir(): string {
    $d = __DIR__ . '/../storage/opensubtitles';
    if (!is_dir($d)) @mkdir($d, 0777, true);
    return $d;
}

/** سبب آخر فشل/فراغ (للتشخيص فقط، بدون أي بيانات حساسة) */
function os_set_reason(?string $r): void { $GLOBALS['OS_REASON'] = $r; }
function os_reason(): ?string { return $GLOBALS['OS_REASON'] ?? null; }

/** علامة انتهاء حصة التحميل اليومية */
function os_quota_until(): int {
    $f = os_cache_dir() . '/quota.json';
    if (!is_file($f)) return 0;
    $d = json_decode((string)file_get_contents($f), true);
    return (int)($d['until'] ?? 0);
}
function os_quota_mark(?array $res): void {
    $until = time() + 3 * 3600;
    if (!empty($res['reset_time_utc']) && ($t = strtotime((string)$res['reset_time_utc'])) && $t > time()) {
        $until = min($t, time() + 24 * 3600);
    }
    @file_put_contents(os_cache_dir() . '/quota.json', json_encode(['until' => $until]));
}

/** طلب HTTP إلى OpenSubtitles. يرجع [httpCode, arrayOrNull]. */
function os_request(string $method, string $url, ?array $json = null, ?string $bearer = null): array {
    $headers = [
        'Api-Key: ' . OS_API_KEY,
        'User-Agent: ' . OS_USER_AGENT,
        'Accept: application/json',
    ];
    if ($json !== null)   $headers[] = 'Content-Type: application/json';
    if ($bearer !== null) $headers[] = 'Authorization: Bearer ' . $bearer;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => $headers,
    ]);
    if ($json !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($json));
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $data = is_string($body) ? json_decode($body, true) : null;
    return [$code, is_array($data) ? $data : null];
}

/** تسجيل الدخول مع تخزين التوكن (صالح 24 ساعة، نخزنه 20 ساعة). يرجع [token, host]. */
function os_login(bool $force = false): ?array {
    if (OS_USERNAME === '' || OS_PASSWORD === '') return null;
    $file = os_cache_dir() . '/token.json';
    if (!$force && is_file($file)) {
        $t = json_decode((string)file_get_contents($file), true);
        if (is_array($t) && !empty($t['token']) && ($t['exp'] ?? 0) > time()) {
            return [$t['token'], $t['host'] ?? 'api.opensubtitles.com'];
        }
    }
    [$code, $res] = os_request('POST', 'https://api.opensubtitles.com/api/v1/login', [
        'username' => OS_USERNAME, 'password' => OS_PASSWORD,
    ]);
    if ($code !== 200 || empty($res['token'])) return null;
    $host = preg_replace('#^https?://#', '', (string)($res['base_url'] ?? 'api.opensubtitles.com'));
    $host = preg_replace('/[^a-z0-9.\-]/i', '', $host) ?: 'api.opensubtitles.com';
    @file_put_contents($file, json_encode(['token' => $res['token'], 'host' => $host, 'exp' => time() + 20 * 3600]));
    return [$res['token'], $host];
}

function os_lang_label(string $code): string {
    static $m = [
        'ar' => 'Arabic', 'en' => 'English', 'fr' => 'French', 'es' => 'Spanish', 'de' => 'German',
        'it' => 'Italian', 'pt' => 'Portuguese', 'pt-br' => 'Portuguese', 'tr' => 'Turkish', 'ru' => 'Russian',
        'fa' => 'Persian', 'ur' => 'Urdu', 'hi' => 'Hindi', 'ja' => 'Japanese', 'ko' => 'Korean',
        'zh-cn' => 'Chinese', 'zh-tw' => 'Chinese', 'nl' => 'Dutch', 'pl' => 'Polish', 'id' => 'Indonesian',
    ];
    $k = strtolower($code);
    return $m[$k] ?? ucfirst($k);
}

/**
 * درجة جودة/مطابقة نسخة الترجمة (كلما ارتفعت كانت أفضل).
 * ملاحظة: الـ API لا يعطي مدة الفيديو، فالمطابقة النهائية بالمدة تتم داخل المشغّل.
 */
function os_score(array $attr): float {
    $score = 0.0;
    $rel = strtolower((string)($attr['release'] ?? '') . ' ' . (string)($attr['files'][0]['file_name'] ?? ''));

    if (!empty($attr['moviehash_match'])) $score += 1000;

    // مصادر البث عادة WEB، فنفضّل نسخ الويب ثم البلو-راي
    if (preg_match('/\bweb[-. ]?(dl|rip)?\b|\bamzn\b|\bnf\b|\bdsnp\b|\bhmax\b/', $rel)) $score += 30;
    elseif (preg_match('/blu[-. ]?ray|brrip|bdrip/', $rel))            $score += 20;
    elseif (preg_match('/hdtv|dvdrip/', $rel))                          $score += 8;
    if (preg_match('/\b(cam|hdcam|ts|telesync|hdts)\b/', $rel))        $score -= 100;

    if (!empty($attr['from_trusted']))          $score += 25;
    $score += log(1 + max(0, (int)($attr['download_count'] ?? 0))) * 5;
    $score += max(0.0, (float)($attr['ratings'] ?? 0)) * 2;

    if (!empty($attr['hearing_impaired']))      $score -= 8;
    if (!empty($attr['ai_translated']))         $score -= 40;
    if (!empty($attr['machine_translated']))    $score -= 60;
    if (!empty($attr['foreign_parts_only']))    $score -= 100;
    return $score;
}

/** توقيع رابط ملف الترجمة حتى لا يستهلك أحد حصة التحميل بأرقام عشوائية */
function os_sign(int $fileId): string {
    return substr(hash_hmac('sha256', 'os-file:' . $fileId, APP_SECRET), 0, 24);
}

/** بحث + ترتيب. يرجع قائمة بشكل المشغّل: [{label, language, source, format, file, url, release}] */
function os_find_raw(string $type, int $tmdbId, int $season = 1, int $episode = 1, ?string $langs = null): array {
    if ($tmdbId <= 0) { os_set_reason('bad_id'); return []; }
    $type  = $type === 'tv' ? 'tv' : 'movie';
    $langs = strtolower(preg_replace('/[^a-zA-Z,\-]/', '', $langs ?: OS_LANGUAGES));
    $langList = array_values(array_filter(explode(',', $langs)));
    if (!$langList) return [];

    $cacheFile = os_cache_dir() . '/search-' . md5("$type|$tmdbId|$season|$episode|$langs") . '.json';
    if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < OS_SEARCH_TTL) {
        $c = json_decode((string)file_get_contents($cacheFile), true);
        if (is_array($c)) return $c;
    }

    $base = ['languages' => $langs];
    if ($type === 'tv') {
        $base += ['parent_tmdb_id' => $tmdbId, 'season_number' => $season, 'episode_number' => $episode, 'type' => 'episode'];
    } else {
        $base += ['tmdb_id' => $tmdbId, 'type' => 'movie'];
    }

    // المحاولة الأولى بدون الترجمات الآلية، وإذا لم نجد شيئاً نسمح بها
    $rows = [];
    foreach ([['ai_translated' => 'exclude', 'machine_translated' => 'exclude'], []] as $extra) {
        $params = $base + $extra;
        ksort($params);
        [$code, $res] = os_request('GET', 'https://api.opensubtitles.com/api/v1/subtitles?' . http_build_query($params));
        if ($code !== 200) { os_set_reason('search_http_' . $code); continue; }
        if (!empty($res['data'])) { $rows = $res['data']; os_set_reason(null); break; }
        os_set_reason('no_results');
    }
    if (!$rows) return [];

    // تجميع حسب اللغة وترتيب كل مجموعة
    $byLang = [];
    foreach ($rows as $row) {
        $a = $row['attributes'] ?? [];
        $fileId = (int)($a['files'][0]['file_id'] ?? 0);
        if ($fileId <= 0) continue;
        $lang = strtolower((string)($a['language'] ?? ''));
        if ($lang === '') continue;
        $byLang[$lang][] = ['attr' => $a, 'file_id' => $fileId, 'score' => os_score($a)];
    }

    $out = [];
    foreach ($langList as $want) {
        // ar يطابق ar فقط؛ zh يطابق zh-cn / zh-tw
        $group = [];
        foreach ($byLang as $l => $items) {
            if ($l === $want || strpos($l, $want . '-') === 0) $group = array_merge($group, $items);
        }
        usort($group, fn($x, $y) => $y['score'] <=> $x['score']);
        $n = 0;
        foreach (array_slice($group, 0, OS_MAX_PER_LANG) as $g) {
            $n++;
            $label = os_lang_label($want);
            $url = '/api/opensubtitles_file.php?id=' . $g['file_id'] . '&sig=' . os_sign($g['file_id']);
            $out[] = [
                'label'    => $n > 1 ? "$label $n" : $label,
                'language' => $want,
                'source'   => 'opensubtitles',
                'format'   => 'vtt',
                'file'     => $url,
                'url'      => $url,
                'release'  => (string)($g['attr']['release'] ?? ''),
            ];
        }
    }

    if ($out) @file_put_contents($cacheFile, json_encode($out, JSON_UNESCAPED_UNICODE));
    return $out;
}


/**
 * الواجهة العامة: تتأكد أن الإعداد سليم وأن التحميل ممكن، وإلا ترجع [] مع سبب
 * حتى يرجع المشغّل للمصادر الأخرى بدل أن تبقى بلا ترجمة.
 */
function os_find(string $type, int $tmdbId, int $season = 1, int $episode = 1, ?string $langs = null): array {
    os_set_reason(null);
    if (!os_configured()) { os_set_reason('not_configured_api_key'); return []; }
    if (OS_USERNAME === '' || OS_PASSWORD === '') { os_set_reason('not_configured_username_password'); return []; }
    if (!os_login()) { os_set_reason('login_failed'); return []; }

    $list = os_find_raw($type, $tmdbId, $season, $episode, $langs);
    if (!$list) return [];

    // إذا انتهت حصة التحميل اليوم نبقي فقط النسخ المخزّنة مسبقاً
    if (os_quota_until() > time()) {
        $list = array_values(array_filter($list, function ($it) {
            return preg_match('/id=(\d+)/', (string)$it['file'], $m) && is_file(os_files_dir() . '/' . $m[1] . '.vtt');
        }));
        if (!$list) os_set_reason('quota_exhausted');
    }
    return $list;
}

/** تحويل نص SRT (أو VTT) إلى VTT بترميز UTF-8 */
function os_to_vtt(string $raw): string {
    if (strncmp($raw, "\xEF\xBB\xBF", 3) === 0) $raw = substr($raw, 3);
    if (!preg_match('//u', $raw)) {
        // ترجمات عربية قديمة غالباً Windows-1256
        $conv = function_exists('iconv') ? @iconv('Windows-1256', 'UTF-8//IGNORE', $raw) : false;
        if ($conv !== false && $conv !== '') $raw = $conv;
    }
    $raw = str_replace(["\r\n", "\r"], "\n", $raw);
    if (stripos(ltrim($raw), 'WEBVTT') === 0) return trim($raw) . "\n";
    $raw = preg_replace('/(\d{2}:\d{2}:\d{2}),(\d{3})/', '$1.$2', $raw);
    return "WEBVTT\n\n" . trim($raw) . "\n";
}

/**
 * يرجع نص VTT للملف (من الكاش أو بتحميله من OpenSubtitles مرة واحدة فقط).
 * الأخطاء: 'quota' عند انتهاء الحصة اليومية، 'auth' عند مشكلة الدخول، 'fail' لأي شيء آخر.
 * @return array [vttOrNull, errorOrNull]
 */
function os_get_vtt(int $fileId): array {
    $path = os_files_dir() . '/' . $fileId . '.vtt';
    if (is_file($path) && filesize($path) > 20) return [(string)file_get_contents($path), null];
    if (!os_configured()) return [null, 'fail'];

    // قفل حتى لا يحمّل طلبان متزامنان نفس الملف (توفيراً للحصة)
    $lock = fopen(os_cache_dir() . '/dl-' . $fileId . '.lock', 'c');
    if ($lock) flock($lock, LOCK_EX);
    try {
        if (is_file($path) && filesize($path) > 20) return [(string)file_get_contents($path), null];

        $auth = os_login();
        if (!$auth) return [null, 'auth'];
        $res = null; $code = 0;
        for ($try = 0; $try < 2; $try++) {
            [$token, $host] = $auth;
            [$code, $res] = os_request('POST', "https://{$host}/api/v1/download",
                ['file_id' => $fileId, 'sub_format' => 'srt'], $token);
            if ($code === 401 && $try === 0) { $auth = os_login(true); if (!$auth) return [null, 'auth']; continue; }
            break;
        }
        if ($code === 406 || $code === 429) { os_quota_mark($res); return [null, 'quota']; }
        if ($code !== 200 || empty($res['link'])) return [null, 'fail'];

        $ch = curl_init((string)$res['link']);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT => OS_USER_AGENT,
        ]);
        $body = curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($http !== 200 || !is_string($body) || strlen($body) < 20) return [null, 'fail'];

        $vtt = os_to_vtt($body);
        @file_put_contents($path, $vtt);
        return [$vtt, null];
    } finally {
        if ($lock) { flock($lock, LOCK_UN); fclose($lock); }
    }
}
