</main>

<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand">
      <span class="brand-text">AF<span>Veo</span></span>
      <p>Stream unlimited movies and TV shows from around the world.</p>
    </div>
    <div class="footer-cols">
      <div>
        <h4>Browse</h4>
        <a href="/">Home</a>
        <a href="/movies">Movies</a>
        <a href="/tv">TV Shows</a>
        <a href="/explore">Explore</a>
      </div>
      <div>
        <h4>Lists</h4>
        <a href="/movies?list=popular">Popular</a>
        <a href="/movies?list=top_rated">Top Rated</a>
        <a href="/movies?list=upcoming">Upcoming</a>
        <a href="/movies?list=now_playing">Now Playing</a>
      </div>
      <div>
        <h4>الحساب</h4>
        <?php if(auth_user()): ?>
          <a href="/profile">حسابي</a>
          <a href="/profile">محفوظاتي</a>
          <a href="/logout">تسجيل الخروج</a>
        <?php else: ?>
          <a href="/login">تسجيل الدخول</a>
          <a href="/register">إنشاء حساب</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="footer-socials">
    <a href="https://www.instagram.com/" target="_blank" rel="noopener" class="fsoc-btn fsoc-instagram" aria-label="Instagram">
      <i class="fa-brands fa-instagram"></i>
    </a>
    <a href="https://www.tiktok.com/" target="_blank" rel="noopener" class="fsoc-btn fsoc-tiktok" aria-label="TikTok">
      <i class="fa-brands fa-tiktok"></i>
    </a>
    <a href="https://www.facebook.com/" target="_blank" rel="noopener" class="fsoc-btn fsoc-facebook" aria-label="Facebook">
      <i class="fa-brands fa-facebook-f"></i>
    </a>
    <a href="https://twitter.com/" target="_blank" rel="noopener" class="fsoc-btn fsoc-twitter" aria-label="Twitter / X">
      <i class="fa-brands fa-x-twitter"></i>
    </a>
    <a href="https://www.snapchat.com/" target="_blank" rel="noopener" class="fsoc-btn fsoc-snapchat" aria-label="Snapchat">
      <i class="fa-brands fa-snapchat"></i>
    </a>
  </div>
  <div class="footer-bottom">
    © <?= date('Y') ?> <?= SITE_NAME ?>. Powered by TMDB.
  </div>
</footer>

<nav class="bottom-nav">
  <a href="/" class="bn-item <?= ($active ?? '') === 'home' ? 'is-active' : '' ?>"><i class="fa-solid fa-house"></i><span>Home</span></a>
  <button type="button" class="bn-item bn-search" id="bottomSearchToggle"><i class="fa-solid fa-magnifying-glass"></i><span>Search</span></button>
  <a href="/movies" class="bn-item <?= ($active ?? '') === 'movies' ? 'is-active' : '' ?>"><i class="fa-solid fa-circle-play"></i><span>Movies</span></a>
  <a href="/tv" class="bn-item <?= ($active ?? '') === 'tv' ? 'is-active' : '' ?>"><i class="fa-solid fa-tv"></i><span>TV</span></a>
  <a href="/saved" class="bn-item <?= ($active ?? '') === 'saved' ? 'is-active' : '' ?>"><i class="fa-regular fa-bookmark"></i><span>Saved</span></a>
  <button type="button" class="bn-item bn-menu" id="mobileMenuToggle" aria-label="Open menu" aria-controls="mobileMenu" aria-expanded="false"><i class="fa-solid fa-sliders"></i><span>Settings</span></button>
</nav>

<?php $__mobile_u = auth_user(); ?>
<div class="mobile-menu" id="mobileMenu" hidden>
  <div class="mobile-menu-backdrop" data-mobile-menu-close></div>
  <section class="mobile-menu-sheet" role="dialog" aria-modal="true" aria-labelledby="mobileMenuTitle">
    <div class="mobile-menu-handle" aria-hidden="true"></div>
    <div class="mobile-menu-header">
      <span id="mobileMenuTitle">Command menu</span>
      <button type="button" class="mobile-menu-close" data-mobile-menu-close aria-label="Close menu"><i class="fa-solid fa-xmark"></i></button>
    </div>

    <a class="mobile-account-card" href="<?= $__mobile_u ? '/profile' : '/login' ?>">
      <span class="mobile-account-avatar"><i class="fa-regular fa-user"></i></span>
      <span>
        <strong><?= $__mobile_u ? htmlspecialchars($__mobile_u['username']) : 'Guest User' ?></strong>
        <small><?= $__mobile_u ? 'View your profile' : 'Sign in to sync your profile' ?></small>
      </span>
      <i class="fa-solid fa-chevron-right"></i>
    </a>

    <div class="mobile-menu-group">
      <h3>Menu</h3>
      <a href="/" class="<?= ($active ?? '') === 'home' ? 'is-current' : '' ?>"><i class="fa-solid fa-house"></i><span>Home</span></a>
      <a href="/search" class="<?= ($active ?? '') === 'search' ? 'is-current' : '' ?>"><i class="fa-solid fa-magnifying-glass"></i><span>Search</span></a>
      <a href="/discover" class="<?= ($active ?? '') === 'explore' ? 'is-current' : '' ?>"><i class="fa-regular fa-compass"></i><span>Discover</span></a>
      <a href="#" class="mobile-menu-unavailable"><i class="fa-solid fa-command"></i><span>Command Menu</span></a>
      <a href="/ai" class="<?= ($active ?? '') === 'ai' ? 'is-current' : '' ?>"><i class="fa-solid fa-robot"></i><span>Rive AI</span></a>
      <a href="/library" class="<?= ($active ?? '') === 'saved' ? 'is-current' : '' ?>"><i class="fa-solid fa-layer-group"></i><span>Library</span></a>
    </div>

    <div class="mobile-menu-group">
      <h3>Media</h3>
      <a href="/movies" class="<?= ($active ?? '') === 'movies' ? 'is-current' : '' ?>"><i class="fa-solid fa-film"></i><span>Movies</span></a>
      <a href="/tv" class="<?= ($active ?? '') === 'tv' ? 'is-current' : '' ?>"><i class="fa-solid fa-tv"></i><span>TV Shows</span></a>
      <a href="/anime" class="<?= ($active ?? '') === 'anime' ? 'is-current' : '' ?>"><i class="fa-solid fa-circle-half-stroke"></i><span>Anime</span></a>
      <a href="/kdrama" class="<?= ($active ?? '') === 'kdrama' ? 'is-current' : '' ?>"><i class="fa-solid fa-masks-theater"></i><span>K-Drama</span></a>
      <a href="/collections" class="<?= ($active ?? '') === 'collections' ? 'is-current' : '' ?>"><i class="fa-solid fa-folder-open"></i><span>Collections</span></a>
    </div>

    <div class="mobile-menu-group">
      <h3>Services</h3>
      <a href="/livesports" class="<?= ($active ?? '') === 'livesports' ? 'is-current' : '' ?>"><i class="fa-regular fa-futbol"></i><span>Live Sports</span></a>
      <a href="/iptv" class="<?= ($active ?? '') === 'iptv' ? 'is-current' : '' ?>"><i class="fa-solid fa-tv"></i><span>IPTV</span></a>
      <a href="/radio" class="<?= ($active ?? '') === 'radio' ? 'is-current' : '' ?>"><i class="fa-solid fa-radio"></i><span>Radio</span></a>
      <a href="/manga" class="<?= ($active ?? '') === 'manga' ? 'is-current' : '' ?>"><i class="fa-solid fa-book-open"></i><span>Manga</span></a>
    </div>

    <div class="mobile-menu-group">
      <h3>System</h3>
      <a href="#" class="mobile-menu-unavailable"><i class="fa-regular fa-bell"></i><span>Announcements</span><b></b></a>
      <a href="/settings" class="<?= ($active ?? '') === 'settings' ? 'is-current' : '' ?>"><i class="fa-solid fa-gear"></i><span>Settings</span></a>
    </div>
  </section>
</div>

<script src="/assets/js/app.js?v=17"></script>
</body>
</html>
