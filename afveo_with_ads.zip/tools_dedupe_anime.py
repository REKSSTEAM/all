from pathlib import Path

p = Path('lib/main.dart')
s = p.read_text()

old_sig = """    String path, {
    String type = '',
    int page = 1,
  }) async {"""
new_sig = """    String path, {
    String type = '',
    int page = 1,
    Map<String, String> params = const {},
  }) async {"""
if old_sig not in s:
    raise SystemExit('TMDB list signature not found')
s = s.replace(old_sig, new_sig, 1)
old_query = """        'include_adult': 'false',
        'page': '$page',
      },"""
new_query = """        'include_adult': 'false',
        'page': '$page',
        ...params,
      },"""
if old_query not in s:
    raise SystemExit('TMDB query block not found')
s = s.replace(old_query, new_query, 1)

home_start = s.index('class Home extends StatelessWidget {')
home_end = s.index('class HeroBlock extends StatefulWidget {', home_start)
new_home = r'''class _HomeSectionData {
  final String title;
  final String path;
  final String type;
  final List<MediaItem> items;
  const _HomeSectionData(this.title, this.path, this.type, this.items);
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late final Future<List<_HomeSectionData>> _sections;

  @override
  void initState() {
    super.initState();
    _sections = _loadSectionsWithoutDuplicates();
  }

  Future<List<_HomeSectionData>> _loadSectionsWithoutDuplicates() async {
    final used = <String>{};
    final sections = <_HomeSectionData>[];

    Future<void> add(
      String title,
      String path,
      String type,
      Future<List<MediaItem>> request, {
      Map<String, String> params = const {},
    }) async {
      final results = await request;
      final unique = results.where((item) {
        final key = '${item.type}:${item.id}';
        return used.add(key);
      }).toList();
      sections.add(_HomeSectionData(title, path, type, unique));
    }

    await add(
      'Trending This Week',
      'trending/all/week',
      '',
      tmdb.list('trending/all/week'),
    );
    await add(
      'Now Playing in Theaters',
      'movie/now_playing',
      'movie',
      tmdb.list('movie/now_playing', type: 'movie'),
    );
    await add(
      'Most Popular',
      'movie/popular',
      'movie',
      tmdb.list('movie/popular', type: 'movie'),
    );
    await add(
      'Top Rated',
      'movie/top_rated',
      'movie',
      tmdb.list('movie/top_rated', type: 'movie'),
    );
    await add(
      'Coming Soon',
      'movie/upcoming',
      'movie',
      tmdb.list('movie/upcoming', type: 'movie'),
    );
    await add(
      'Trending TV This Week',
      'trending/tv/week',
      'tv',
      tmdb.list('trending/tv/week', type: 'tv'),
    );
    await add(
      'Most Popular TV Shows',
      'tv/popular',
      'tv',
      tmdb.list('tv/popular', type: 'tv'),
    );
    await add(
      'Currently Airing',
      'tv/on_the_air',
      'tv',
      tmdb.list('tv/on_the_air', type: 'tv'),
    );
    await add(
      'Top Rated TV Shows',
      'tv/top_rated',
      'tv',
      tmdb.list('tv/top_rated', type: 'tv'),
    );
    await add(
      'Anime',
      'discover/tv',
      'tv',
      tmdb.list(
        'discover/tv',
        type: 'tv',
        params: const {
          'with_genres': '16',
          'with_original_language': 'ja',
          'sort_by': 'popularity.desc',
        },
      ),
    );
    return sections;
  }

  @override
  Widget build(BuildContext c) => CustomScrollView(
    slivers: [
      const SliverToBoxAdapter(child: Header()),
      SliverToBoxAdapter(child: HeroBlock()),
      const SliverToBoxAdapter(child: SizedBox(height: 18)),
      SliverToBoxAdapter(
        child: FutureBuilder<List<_HomeSectionData>>(
          future: _sections,
          builder: (c, s) {
            if (s.connectionState == ConnectionState.waiting) {
              return const Padding(
                padding: EdgeInsets.all(35),
                child: Center(child: CircularProgressIndicator(color: red)),
              );
            }
            if (s.hasError) {
              return const Padding(
                padding: EdgeInsets.all(32),
                child: Text('Unable to load sections', style: TextStyle(color: Colors.white60)),
              );
            }
            return Column(
              children: [
                for (final section in s.data ?? <_HomeSectionData>[])
                  Section(
                    title: section.title,
                    future: Future.value(section.items),
                    allPath: section.path,
                    allType: section.type,
                  ),
                const TitleBlock(icon: Icons.movie_outlined, text: 'Browse More'),
                const Footer(),
              ],
            );
          },
        ),
      ),
    ],
  );
}

'''
s = s[:home_start] + new_home + s[home_end:]
p.write_text(s)
print('deduplication and anime section added')
