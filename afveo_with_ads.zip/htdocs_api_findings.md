# نتائج فحص htdocs وواجهة التشغيل

- DNS للنطاق `afflix.xo.je` يعيد IPv4: `185.27.134.115`.
- طلب `https://afflix.xo.je/api/v1/stream.php?action=token&type=movie&id=550` من عميل HTTP عادي يرجع `HTTP 200` و`Content-Type: text/html` وليس JSON.
- بداية الرد تحتوي `/aes.js` و`document.cookie="__test=..."` ثم إعادة توجيه إلى نفس الرابط، وهذا يدل على طبقة حماية OpenResty/AES أمام PHP. ملف `htdocs.zip` لا يحتوي إعداد OpenResty/Nginx أو `aes.js`، لذلك لا يمكن تعطيلها من ملفات PHP وحدها.
- داخل `htdocs/api/v1/stream.php` المسار الصحيح هو Token ثم Sources. التوكن HMAC مرتبط بـ `type` و`id` ويدوم 24 ساعة، وطلب Sources يقبل `season` و`episode` للمسلسلات.
- `htdocs/index.php` يطبق أيضًا على resolvers الأخرى `nonce` و`timestamp` وstream token، لكن هذه الحماية لا تظهر في كود `/api/v1/stream.php` نفسه.
- `setup_key.php` يوثق Header باسم `X-API-Key`، لكن `stream.php` الذي فُحص لا يتحقق منه؛ يجب توحيد ذلك قبل الإنتاج.
- تعديل Android إلى IP `185.27.134.115` لن يحل المشكلة، لأن الـ IP نفسه يعيد تحدي AES؛ الحل الصحيح هو استثناء مسار API من تحدي AES أو توفير subdomain/API origin مخصص للتطبيق، ثم إرسال JSON مباشرة.
