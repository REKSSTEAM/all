from pathlib import Path
import re
p = Path('/home/ubuntu/afveo-app/lib/main.dart')
s = p.read_text()
pattern = r"class _CatalogPageState extends State<CatalogPage> \{.*?\n\}\n\nclass Explore"
replacement = r'''class _CatalogPageState extends State<CatalogPage> {
  int page = 1;

  @override
  Widget build(BuildContext c) => Scaffold(
    backgroundColor: bg,
    body: SafeArea(
      child: FutureBuilder<List<MediaItem>>(
        future: tmdb.list(widget.path, type: widget.type, page: page),
        builder: (c, s) {
          final items = s.data ?? <MediaItem>[];
          return CustomScrollView(
            slivers: [
              const SliverToBoxAdapter(child: Header()),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(28, 4, 28, 16),
                  child: Row(
                    children: [
                      Text(widget.title, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                      const Spacer(),
                      Text('Page $page', style: const TextStyle(color: Colors.white54, fontSize: 15)),
                    ],
                  ),
                ),
              ),
              if (s.connectionState == ConnectionState.waiting)
                const SliverFillRemaining(hasScrollBody: false, child: Center(child: CircularProgressIndicator(color: red)))
              else if (s.hasError)
                const SliverFillRemaining(hasScrollBody: false, child: Center(child: Text('Unable to load content', style: TextStyle(color: Colors.white60))))
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(
                      (c, i) => CardItem(items[i], width: double.infinity, compact: true),
                      childCount: items.length,
                    ),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 18,
                      childAspectRatio: .53,
                    ),
                  ),
                ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 4, 24, 120),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton.icon(
                        onPressed: page > 1 ? () => setState(() => page--) : null,
                        icon: const Icon(Icons.arrow_back),
                        label: const Text('Previous'),
                      ),
                      Text('Page $page', style: const TextStyle(color: Colors.white70)),
                      TextButton.icon(
                        onPressed: () => setState(() => page++),
                        icon: const Icon(Icons.arrow_forward),
                        label: const Text('Next'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    ),
  );
}

class Explore'''
new_s, count = re.subn(pattern, replacement, s, count=1, flags=re.S)
if count != 1:
    raise SystemExit('CatalogPage pattern not found')
p.write_text(new_s)
''
