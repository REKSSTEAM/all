from pathlib import Path

p = Path('lib/main.dart')
s = p.read_text()

anchor = "final streamApi = StreamApi();"
helper = r'''Map<String, dynamic> decodeApiJson(http.Response r, String operation) {
  final body = r.body.trim();
  final contentType = r.headers['content-type'] ?? '';
  if (body.isEmpty) {
    throw Exception('$operation API returned an empty response (HTTP ${r.statusCode})');
  }
  if (body.startsWith('<') || contentType.contains('text/html')) {
    throw Exception(
      '$operation API returned HTML instead of JSON (HTTP ${r.statusCode}). '
      'The server may be redirecting or blocking the request.',
    );
  }
  try {
    final decoded = jsonDecode(body);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Response is not a JSON object');
    }
    return decoded;
  } on FormatException catch (e) {
    throw Exception('$operation API returned invalid JSON: ${e.message}');
  }
}

'''
if helper not in s:
    if anchor not in s:
        raise SystemExit('streamApi anchor not found')
    s = s.replace(anchor, helper + anchor, 1)

s = s.replace(
"final r = await http.get(u).timeout(const Duration(seconds: 25));\n    final d = jsonDecode(r.body);",
"final r = await http.get(u, headers: const {'Accept': 'application/json', 'User-Agent': 'AFVeo Android'}).timeout(const Duration(seconds: 25));\n    final d = decodeApiJson(r, 'Token');",
1,
)
s = s.replace(
".get(\n          Uri.parse(ApiConfig.streamApi).replace(\n            queryParameters: {",
".get(\n          Uri.parse(ApiConfig.streamApi).replace(\n            queryParameters: {",
1,
)
s = s.replace(
"              'token': t,\n            },\n          ),\n        )\n        .timeout(const Duration(seconds: 50));\n    final d = jsonDecode(r.body);",
"              'token': t,\n            },\n          ),\n          headers: const {'Accept': 'application/json', 'User-Agent': 'AFVeo Android'},\n        )\n        .timeout(const Duration(seconds: 50));\n    final d = decodeApiJson(r, 'Sources');",
1,
)
p.write_text(s)
print('guarded token and sources JSON responses')
