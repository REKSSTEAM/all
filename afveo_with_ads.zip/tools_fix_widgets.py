from pathlib import Path
import re
p = Path('/home/ubuntu/afveo-app/lib/main.dart')
s = p.read_text()
card = r'''class CardItem extends StatelessWidget {
  final MediaItem item;
  const CardItem(this.item, {super.key});
  @override
  Widget build(BuildContext c) {
    return GestureDetector(
      onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => Details(item: item))),
      child: SizedBox(
        width: 280,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: AspectRatio(
                    aspectRatio: .68,
                    child: CachedNetworkImage(
                      imageUrl: image(item.poster, 'w500'),
                      fit: BoxFit.cover,
                      errorWidget: (_, __, ___) => const ColoredBox(
                        color: panel,
                        child: Icon(Icons.movie, color: Colors.white24),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 12,
                  left: 12,
                  child: Badge(icon: Icons.star, color: const Color(0xff252a2d), text: item.rating.toStringAsFixed(1)),
                ),
                Positioned(
                  top: 12,
                  right: 12,
                  child: Badge(color: const Color(0xff252a2d), text: item.type == 'tv' ? 'TV' : 'Movie'),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text(item.date.length >= 4 ? item.date.substring(0, 4) : item.date, style: const TextStyle(color: Colors.white60, fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
'''
badge = r'''class Badge extends StatelessWidget {
  final IconData? icon;
  final Color color;
  final String text;
  const Badge({super.key, this.icon, required this.color, required this.text});
  @override
  Widget build(BuildContext c) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(color: color.withOpacity(.92), borderRadius: BorderRadius.circular(18)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) Icon(icon, color: const Color(0xffffc72c), size: 18),
          if (icon != null) const SizedBox(width: 4),
          Text(text, style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}
'''
s = re.sub(r'class CardItem extends StatelessWidget \{.*?\nclass Badge extends StatelessWidget \{', card + '\nclass Badge extends StatelessWidget {', s, count=1, flags=re.S)
s = re.sub(r'class Badge extends StatelessWidget \{.*?\nclass Home extends StatelessWidget \{', badge + '\nclass Home extends StatelessWidget {', s, count=1, flags=re.S)
p.write_text(s)

