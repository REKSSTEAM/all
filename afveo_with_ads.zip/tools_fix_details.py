from pathlib import Path
p = Path('/home/ubuntu/afveo-app/lib/main.dart')
s = p.read_text()
old = "final cast=((data?['credits']?['cast']??[]) as List).take(8).toList();"
new = "final credits = data != null && data!['credits'] is Map ? data!['credits'] as Map<String,dynamic> : <String,dynamic>{}; final cast = ((credits['cast'] ?? []) as List).take(8).toList();"
s = s.replace(old, new)
s = s.replace("if(data?['recommendations']?['results'] is List)", "if(data != null && data!['recommendations'] is Map && (data!['recommendations'] as Map)['results'] is List)")
s = s.replace("((data!['recommendations']['results']) as List)", "(((data!['recommendations'] as Map)['results']) as List)")
s = s.replace("(data!['recommendations']['results'][i])", "(((data!['recommendations'] as Map)['results'] as List)[i])")
p.write_text(s)
