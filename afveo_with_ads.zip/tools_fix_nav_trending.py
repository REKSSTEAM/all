from pathlib import Path
import re

path = Path('lib/main.dart')
s = path.read_text()

# CatalogPage is already hosted by Shell, so it must not render a second bottom bar.
catalog_nav = """    bottomNavigationBar: BottomBar(
      index: widget.type == 'tv' ? 2 : 1,
      onTap: (i) {
        Navigator.pushReplacement(
          c,
          MaterialPageRoute(builder: (_) => Shell(initialIndex: i)),
        );
      },
    ),
"""
if catalog_nav not in s:
    raise SystemExit('Catalog bottom bar block not found')
s = s.replace(catalog_nav, '', 1)

hero_start = s.index('class HeroBlock extends StatelessWidget {')
hero_end = s.index('class TitleBlock extends StatelessWidget {', hero_start)
new_hero = r'''class HeroBlock extends StatefulWidget {
  const HeroBlock({super.key});
  @override
  State<HeroBlock> createState() => _HeroBlockState();
}

class _HeroBlockState extends State<HeroBlock> {
  late final Future<List<MediaItem>> _future;
  PageController? _controller;
  Timer? _timer;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _future = tmdb.list('trending/all/week');
  }

  void _startAutoPlay(int count) {
    if (count < 2 || _timer != null) return;
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted || _controller == null || !_controller!.hasClients) return;
      final next = (_index + 1) % count;
      _controller!.animateToPage(
        next,
        duration: const Duration(milliseconds: 550),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller?.dispose();
    super.dispose();
  }

  Widget _slide(BuildContext context, MediaItem x) => Stack(
        fit: StackFit.expand,
        children: [
          CachedNetworkImage(
            imageUrl: image(x.backdrop, 'w1280'),
            fit: BoxFit.cover,
          ),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Color(0xff070809)],
              ),
            ),
          ),
          Positioned(
            left: 20,
            right: 20,
            bottom: 20,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  x.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 7),
                Text(
                  '${x.date.length >= 4 ? x.date.substring(0, 4) : ''}  •  ${x.type == 'tv' ? 'TV' : 'Movie'}  •  ⭐ ${x.rating.toStringAsFixed(1)}',
                  style: const TextStyle(color: Colors.white70, fontSize: 15),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: red),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => Details(item: x)),
                  ),
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('Watch Now'),
                ),
              ],
            ),
          ),
        ],
      );

  @override
  Widget build(BuildContext context) => FutureBuilder<List<MediaItem>>(
        future: _future,
        builder: (context, snapshot) {
          final media = (snapshot.data ?? [])
              .where((x) => x.backdrop.isNotEmpty)
              .take(10)
              .toList();
          if (media.isEmpty) return const SizedBox(height: 240);
          _startAutoPlay(media.length);
          _controller ??= PageController();
          return SizedBox(
            height: 360,
            child: Stack(
              children: [
                PageView.builder(
                  controller: _controller,
                  itemCount: media.length,
                  onPageChanged: (value) => setState(() => _index = value),
                  itemBuilder: (_, i) => _slide(context, media[i]),
                ),
                if (media.length > 1)
                  Positioned(
                    right: 20,
                    bottom: 12,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: List.generate(
                        media.length,
                        (i) => AnimatedContainer(
                          duration: const Duration(milliseconds: 220),
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          width: i == _index ? 18 : 6,
                          height: 6,
                          decoration: BoxDecoration(
                            color: i == _index ? red : Colors.white54,
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      );
}

'''
s = s[:hero_start] + new_hero + s[hero_end:]

# Genre result pages are pushed outside Shell, therefore give them one shared bottom bar.
genre_start = s.index('class GenreResults extends StatelessWidget {')
genre_end = s.index('class SearchPage extends StatefulWidget {', genre_start)
new_genre = r'''class GenreResults extends StatelessWidget {
  final String name;
  const GenreResults({super.key, required this.name});
  @override
  Widget build(BuildContext c) => Scaffold(
        backgroundColor: bg,
        body: SafeArea(
          child: Column(
            children: [
              const Header(),
              Padding(
                padding: const EdgeInsets.fromLTRB(32, 8, 32, 16),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    name,
                    style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
                  ),
                ),
              ),
              Expanded(
                child: FutureBuilder<List<MediaItem>>(
                  future: tmdb.list('discover/movie', type: 'movie'),
                  builder: (c, s) {
                    if (s.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator(color: red));
                    }
                    final items = s.data ?? [];
                    return GridView.builder(
                      padding: const EdgeInsets.fromLTRB(24, 8, 24, 28),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 14,
                        mainAxisSpacing: 18,
                        childAspectRatio: .62,
                      ),
                      itemCount: items.length,
                      itemBuilder: (_, i) => CardItem(items[i]),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: BottomBar(
          index: 3,
          onTap: (i) => Navigator.pushReplacement(
            c,
            MaterialPageRoute(builder: (_) => Shell(initialIndex: i)),
          ),
        ),
      );
}

'''
s = s[:genre_start] + new_genre + s[genre_end:]

path.write_text(s)
print('updated navigation and trending')
