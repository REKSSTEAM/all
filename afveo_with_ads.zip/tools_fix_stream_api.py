from pathlib import Path

p = Path('lib/main.dart')
s = p.read_text()
start = s.index('class StreamApi {')
end = s.index('final streamApi = StreamApi();', start)
new = r'''class StreamApi {
  final cache = <String, Map<String, dynamic>>{};

  Future<String> token(String type, int id) async {
    final k = '$type:$id';
    final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final saved = cache[k];
    if (saved != null && (saved['refresh_at'] ?? 0) > now) {
      return '${saved['token']}';
    }

    final u = Uri.parse(ApiConfig.streamApi).replace(
      queryParameters: {
        'action': 'token',
        'type': type,
        'id': '$id',
      },
    );
    final r = await http.get(u).timeout(const Duration(seconds: 25));
    final d = jsonDecode(r.body);
    if (r.statusCode != 200 || d is! Map || d['ok'] != true) {
      throw Exception(d is Map ? (d['error'] ?? 'Token failed') : 'Token failed');
    }
    cache[k] = Map<String, dynamic>.from(d);
    return '${d['token']}';
  }

  Future<List<Quality>> sources(MediaItem m) async {
    final firstToken = await token(m.type, m.id);
    try {
      return await _requestSources(m, firstToken);
    } catch (_) {
      // The API exposes refresh_at. If the source request rejects an expired
      // token, remove it and perform the exact token -> sources sequence again.
      cache.remove('${m.type}:${m.id}');
      final refreshedToken = await token(m.type, m.id);
      return _requestSources(m, refreshedToken);
    }
  }

  Future<List<Quality>> _requestSources(MediaItem m, String t) async {
    final r = await http
        .get(
          Uri.parse(ApiConfig.streamApi).replace(
            queryParameters: {
              'action': 'sources',
              'type': m.type,
              'id': '${m.id}',
              'token': t,
            },
          ),
        )
        .timeout(const Duration(seconds: 50));
    final d = jsonDecode(r.body);
    if (r.statusCode != 200 || d is! Map || d['ok'] != true) {
      throw Exception(d is Map ? (d['error'] ?? 'No sources') : 'No sources');
    }

    // The API can return either {source: {...}} or {sources: [{...}]}.
    final raw = d['sources'] ?? d['source'];
    final providers = raw is List
        ? raw
        : raw is Map<String, dynamic>
            ? <dynamic>[raw]
            : <dynamic>[];
    final result = <Quality>[];
    final seenUrls = <String>{};

    for (final provider in providers) {
      if (provider is! Map) continue;
      final qualities = provider['qualities'];
      if (qualities is List) {
        for (final q in qualities) {
          if (q is! Map) continue;
          final url = '${q['url'] ?? ''}';
          if (url.isEmpty || !seenUrls.add(url)) continue;
          final label = '${q['label'] ?? provider['quality'] ?? provider['name'] ?? 'HD'}';
          result.add(Quality(label, url));
        }
      }
      if (result.isEmpty) {
        final url = '${provider['m3u8'] ?? ''}';
        if (url.isNotEmpty && seenUrls.add(url)) {
          result.add(Quality('${provider['quality'] ?? provider['name'] ?? 'HD'}', url));
        }
      }
    }
    if (result.isEmpty) throw Exception('No playable sources');
    return result;
  }
}

'''
s = s[:start] + new + s[end:]
p.write_text(s)
print('stream API sequence and response parsing fixed')
