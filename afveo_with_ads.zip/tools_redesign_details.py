from pathlib import Path
import re
p = Path('/home/ubuntu/afveo-app/lib/main.dart')
s = p.read_text()
# Remove the type pill that was covering posters; keep the rating badge only.
s, removed = re.subn(r"\n\s*Positioned\(\n\s*top: 12,\n\s*right: 12,\n\s*child: Badge\(\n\s*color: const Color\(0xff252a2d\),\n\s*text: item\.type == 'tv' \? 'TV' : 'Movie',\n\s*\),\n\s*\),", "", s, count=1)
if removed != 1:
    raise SystemExit('type badge not found')
pattern = r"class Details extends StatefulWidget \{.*?\nclass Watch extends StatefulWidget"
replacement = r'''class Details extends StatefulWidget {
  final MediaItem item;
  const Details({super.key, required this.item});
  @override
  State<Details> createState() => _DetailsState();
}

class _DetailsState extends State<Details> {
  Map<String, dynamic>? data;
  bool saved = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final a = p.getStringList('saved') ?? [];
      saved = a.any((x) => jsonDecode(x)['id'] == widget.item.id);
      final d = await tmdb.details(widget.item);
      if (mounted) setState(() => data = d);
    } catch (_) {}
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    final a = p.getStringList('saved') ?? [];
    if (saved) {
      a.removeWhere((x) => jsonDecode(x)['id'] == widget.item.id);
    } else {
      a.add(jsonEncode({
        'id': widget.item.id,
        'media_type': widget.item.type,
        'title': widget.item.title,
        'overview': widget.item.overview,
        'poster_path': widget.item.poster,
        'backdrop_path': widget.item.backdrop,
        'vote_average': widget.item.rating,
        'release_date': widget.item.date,
      }));
    }
    await p.setStringList('saved', a);
    if (mounted) setState(() => saved = !saved);
  }

  List<Map<String, dynamic>> listMap(dynamic value) {
    if (value is! List) return [];
    return value.whereType<Map>().map((x) => Map<String, dynamic>.from(x)).toList();
  }

  @override
  Widget build(BuildContext c) {
    final m = widget.item;
    final d = data ?? <String, dynamic>{};
    final cast = listMap((d['credits'] as Map?)?['cast']).take(9).toList();
    final crew = listMap((d['credits'] as Map?)?['crew']);
    final director = crew.where((x) => x['job'] == 'Director').take(1).toList();
    final recommendations = listMap((d['recommendations'] as Map?)?['results']).take(9).toList();
    final genres = listMap(d['genres']);
    final runtime = d['runtime'];
    final year = m.date.length >= 4 ? m.date.substring(0, 4) : '';

    return Scaffold(
      backgroundColor: bg,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: bg,
            pinned: true,
            expandedHeight: 270,
            leading: IconButton(onPressed: () => Navigator.pop(c), icon: const Icon(Icons.arrow_back)),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(fit: StackFit.expand, children: [
                CachedNetworkImage(imageUrl: image(m.backdrop, 'w1280'), fit: BoxFit.cover),
                const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, bg]))),
              ]),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 22, 20, 120),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                Text(m.title, style: const TextStyle(fontSize: 36, height: 1.08, fontWeight: FontWeight.w900)),
                if ((d['tagline'] ?? '').toString().isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text('“${d['tagline']}”', style: const TextStyle(color: Colors.white70, fontSize: 19, fontStyle: FontStyle.italic)),
                ],
                const SizedBox(height: 18),
                Wrap(spacing: 12, runSpacing: 10, children: [
                  Text('★ ${m.rating.toStringAsFixed(1)}', style: const TextStyle(color: Color(0xffffcf40), fontSize: 18, fontWeight: FontWeight.w700)),
                  if (year.isNotEmpty) Text(year, style: const TextStyle(color: Colors.white70, fontSize: 18)),
                  if (runtime is num && runtime > 0) Text('${runtime}m', style: const TextStyle(color: Colors.white70, fontSize: 18)),
                  Text(m.type == 'tv' ? 'TV' : 'Movie', style: const TextStyle(color: Colors.white70, fontSize: 18)),
                ]),
                const SizedBox(height: 18),
                Wrap(spacing: 9, runSpacing: 9, children: genres.isEmpty ? [const Chip(label: Text('Drama'), backgroundColor: panel)] : [for (final g in genres.take(5)) Chip(label: Text('${g['name'] ?? ''}'), backgroundColor: panel)]),
                const SizedBox(height: 28),
                const Text('Overview', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                Text(m.overview.isEmpty ? 'No overview available' : m.overview, style: const TextStyle(color: Colors.white70, fontSize: 18, height: 1.55)),
                const SizedBox(height: 26),
                Row(children: [
                  Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: red, padding: const EdgeInsets.symmetric(vertical: 16)), onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => Watch(item: m))), icon: const Icon(Icons.play_arrow), label: const Text('Watch Now', style: TextStyle(fontSize: 17)))),
                  const SizedBox(width: 10),
                  Expanded(child: OutlinedButton.icon(style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15), side: const BorderSide(color: Colors.white30)), onPressed: () {}, icon: const Icon(Icons.play_circle_outline), label: const Text('Trailer'))),
                ]),
                const SizedBox(height: 12),
                Row(children: [IconButton.filled(onPressed: save, icon: Icon(saved ? Icons.bookmark : Icons.bookmark_border)), const SizedBox(width: 10), IconButton.filled(onPressed: () {}, icon: const Icon(Icons.share))]),
                const SizedBox(height: 30),
                if (director.isNotEmpty) ...[
                  const Text('DIRECTOR', style: TextStyle(color: Colors.white60, fontSize: 17, fontWeight: FontWeight.w700, letterSpacing: 2)),
                  const SizedBox(height: 12),
                  PersonRow(person: director.first),
                  const SizedBox(height: 28),
                ],
                const Text('Top Cast', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
                const SizedBox(height: 14),
                CastGrid(cast: cast),
                const SizedBox(height: 30),
                if (recommendations.isNotEmpty) ...[
                  const Text('More Like This', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 14),
                  RecommendationGrid(items: recommendations, type: m.type),
                ],
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class PersonRow extends StatelessWidget {
  final Map<String, dynamic> person;
  const PersonRow({super.key, required this.person});
  @override
  Widget build(BuildContext c) => Container(
    height: 82,
    padding: const EdgeInsets.symmetric(horizontal: 12),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(42), border: Border.all(color: Colors.white12)),
    child: Row(children: [
      CircleAvatar(radius: 28, backgroundImage: CachedNetworkImageProvider(image('${person['profile_path'] ?? ''}', 'w185'))),
      const SizedBox(width: 14),
      Expanded(child: Text('${person['name'] ?? ''}', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700))),
    ]),
  );
}

class CastGrid extends StatelessWidget {
  final List<Map<String, dynamic>> cast;
  const CastGrid({super.key, required this.cast});
  @override
  Widget build(BuildContext c) => GridView.builder(
    shrinkWrap: true,
    physics: const NeverScrollableScrollPhysics(),
    itemCount: cast.length,
    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 18, childAspectRatio: .58),
    itemBuilder: (_, i) {
      final x = cast[i];
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(18), child: CachedNetworkImage(imageUrl: image('${x['profile_path'] ?? ''}', 'w185'), width: double.infinity, fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: panel, child: Icon(Icons.person, color: Colors.white38))))),
        const SizedBox(height: 7),
        Text('${x['name'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
        Text('${x['character'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54, fontSize: 12)),
      ]);
    },
  );
}

class RecommendationGrid extends StatelessWidget {
  final List<Map<String, dynamic>> items;
  final String type;
  const RecommendationGrid({super.key, required this.items, required this.type});
  @override
  Widget build(BuildContext c) => GridView.builder(
    shrinkWrap: true,
    physics: const NeverScrollableScrollPhysics(),
    itemCount: items.length,
    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 18, childAspectRatio: .53),
    itemBuilder: (_, i) => CardItem(MediaItem.fromJson(items[i], type), width: double.infinity, compact: true),
  );
}

class Watch extends StatefulWidget'''
new_s, count = re.subn(pattern, replacement, s, count=1, flags=re.S)
if count != 1:
    raise SystemExit('Details block not found')
p.write_text(new_s)
''
