from pathlib import Path

p = Path('lib/main.dart')
s = p.read_text()

old = """class Section extends StatelessWidget {
  final String title;
  final Future<List<MediaItem>> future;
  const Section({super.key, required this.title, required this.future});
  @override
  Widget build(BuildContext c) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(32, 22, 28, 14),
        child: Row(
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
            ),
            const Spacer(),
            const Text(
              'All  ›',
              style: TextStyle(color: Colors.white60, fontSize: 17),
            ),
          ],
        ),
      ),
      SizedBox(
        height: 245,
        child: FutureBuilder<List<MediaItem>>(
          future: future,
          builder: (c, s) {
            if (s.connectionState == ConnectionState.waiting)
              return const Center(child: CircularProgressIndicator(color: red));
            if (s.hasError)
              return const Padding(
                padding: EdgeInsets.symmetric(horizontal: 32),
                child: Text(
                  'Unable to load content',
                  style: TextStyle(color: Colors.white54),
                ),
              );
            final x = s.data ?? [];
            return ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              scrollDirection: Axis.horizontal,
              itemCount: x.length,
              itemBuilder: (_, i) => CardItem(x[i]),
              separatorBuilder: (_, __) => const SizedBox(width: 22),
            );
          },
        ),
      ),
    ],
  );
}
"""
new = """class Section extends StatelessWidget {
  final String title;
  final Future<List<MediaItem>> future;
  final String allPath;
  final String allType;
  const Section({
    super.key,
    required this.title,
    required this.future,
    required this.allPath,
    this.allType = '',
  });
  @override
  Widget build(BuildContext c) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(32, 20, 28, 10),
        child: Row(
          children: [
            Expanded(
              child: Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
              ),
            ),
            TextButton(
              onPressed: () => Navigator.push(
                c,
                MaterialPageRoute(
                  builder: (_) => CatalogPage(
                    title: title,
                    path: allPath,
                    type: allType,
                  ),
                ),
              ),
              style: TextButton.styleFrom(
                foregroundColor: Colors.white60,
                padding: const EdgeInsets.symmetric(horizontal: 4),
                minimumSize: Size.zero,
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
              child: const Text('All  ›', style: TextStyle(fontSize: 13)),
            ),
          ],
        ),
      ),
      SizedBox(
        height: 245,
        child: FutureBuilder<List<MediaItem>>(
          future: future,
          builder: (c, s) {
            if (s.connectionState == ConnectionState.waiting)
              return const Center(child: CircularProgressIndicator(color: red));
            if (s.hasError)
              return const Padding(
                padding: EdgeInsets.symmetric(horizontal: 32),
                child: Text(
                  'Unable to load content',
                  style: TextStyle(color: Colors.white54),
                ),
              );
            final x = s.data ?? [];
            return ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              scrollDirection: Axis.horizontal,
              itemCount: x.length,
              itemBuilder: (_, i) => CardItem(x[i]),
              separatorBuilder: (_, __) => const SizedBox(width: 22),
            );
          },
        ),
      ),
    ],
  );
}
"""
if old not in s:
    raise SystemExit('Section block not found')
s = s.replace(old, new, 1)

home_start = s.index('class Home extends StatelessWidget {')
home_end = s.index('class HeroBlock extends StatefulWidget {', home_start)
new_home = """class Home extends StatelessWidget {
  const Home({super.key});
  @override
  Widget build(BuildContext c) => CustomScrollView(
    slivers: [
      const SliverToBoxAdapter(child: Header()),
      SliverToBoxAdapter(child: HeroBlock()),
      const SliverToBoxAdapter(child: SizedBox(height: 18)),
      SliverToBoxAdapter(
        child: Section(
          title: 'Trending This Week',
          future: tmdb.list('trending/all/week'),
          allPath: 'trending/all/week',
        ),
      ),
      SliverToBoxAdapter(child: TitleBlock(icon: Icons.movie_outlined, text: 'Movies')),
      SliverToBoxAdapter(
        child: Section(
          title: 'Now Playing in Theaters',
          future: tmdb.list('movie/now_playing', type: 'movie'),
          allPath: 'movie/now_playing',
          allType: 'movie',
        ),
      ),
      SliverToBoxAdapter(
        child: Section(
          title: 'Most Popular',
          future: tmdb.list('movie/popular', type: 'movie'),
          allPath: 'movie/popular',
          allType: 'movie',
        ),
      ),
      SliverToBoxAdapter(
        child: Section(
          title: 'Top Rated',
          future: tmdb.list('movie/top_rated', type: 'movie'),
          allPath: 'movie/top_rated',
          allType: 'movie',
        ),
      ),
      SliverToBoxAdapter(
        child: Section(
          title: 'Coming Soon',
          future: tmdb.list('movie/upcoming', type: 'movie'),
          allPath: 'movie/upcoming',
          allType: 'movie',
        ),
      ),
      SliverToBoxAdapter(child: TitleBlock(icon: Icons.tv, text: 'TV Shows')),
      SliverToBoxAdapter(
        child: Section(
          title: 'Trending TV This Week',
          future: tmdb.list('trending/tv/week', type: 'tv'),
          allPath: 'trending/tv/week',
          allType: 'tv',
        ),
      ),
      SliverToBoxAdapter(
        child: Section(
          title: 'Most Popular TV Shows',
          future: tmdb.list('tv/popular', type: 'tv'),
          allPath: 'tv/popular',
          allType: 'tv',
        ),
      ),
      SliverToBoxAdapter(
        child: Section(
          title: 'Currently Airing',
          future: tmdb.list('tv/on_the_air', type: 'tv'),
          allPath: 'tv/on_the_air',
          allType: 'tv',
        ),
      ),
      SliverToBoxAdapter(
        child: Section(
          title: 'Top Rated TV Shows',
          future: tmdb.list('tv/top_rated', type: 'tv'),
          allPath: 'tv/top_rated',
          allType: 'tv',
        ),
      ),
      SliverToBoxAdapter(child: Footer()),
    ],
  );
}

"""
s = s[:home_start] + new_home + s[home_end:]
p.write_text(s)
print('home sections updated')
