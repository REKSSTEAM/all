# بناء AFVeo لـ iPhone

المشروع مبني بـ Flutter/Dart ويحتوي على مجلد ios جاهز لفتحه في Xcode. للبناء النهائي يجب استخدام جهاز macOS مثبت عليه Xcode وCocoaPods وحساب Apple Developer.

```bash
flutter pub get
cd ios
pod install
cd ..
flutter build ios --release
```

بعد ذلك افتح `ios/Runner.xcworkspace` في Xcode، اختر Signing & Capabilities، حدّد Team ومعرّف Bundle مناسباً، ثم نفّذ Archive من قائمة Product لتصدير IPA أو رفع التطبيق إلى TestFlight.

طريقة التشغيل داخل التطبيق لا تزال Embed عبر `https://afflix.xo.je/embed/...`، ولا توجد حاجة إلى Token/Providers/Sources.
