from pathlib import Path
from PIL import Image, ImageDraw, ImageOps

project = Path('/home/ubuntu/afveo-app')
source = Path('/home/ubuntu/upload/logo.jpg')
img = Image.open(source).convert('RGB')


def rounded_square(size: int, radius_ratio: float = 0.20) -> Image.Image:
    canvas = ImageOps.fit(img, (size, size), method=Image.Resampling.LANCZOS)
    rgba = canvas.convert('RGBA')
    mask = Image.new('L', (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        (0, 0, size - 1, size - 1),
        radius=int(size * radius_ratio),
        fill=255,
    )
    rgba.putalpha(mask)
    return rgba

sizes = {
    'mipmap-mdpi': 48,
    'mipmap-hdpi': 72,
    'mipmap-xhdpi': 96,
    'mipmap-xxhdpi': 144,
    'mipmap-xxxhdpi': 192,
}
for folder, size in sizes.items():
    out = project / 'android/app/src/main/res' / folder / 'ic_launcher.png'
    out.parent.mkdir(parents=True, exist_ok=True)
    rounded_square(size).save(out, 'PNG', optimize=True)

splash = rounded_square(720, 0.16)
splash.save(project / 'android/app/src/main/res/drawable/afveo_splash.png', 'PNG', optimize=True)

# Keep the Flutter asset in sync with the supplied external logo.
asset = project / 'assets/images/afveo_logo.jpg'
asset.parent.mkdir(parents=True, exist_ok=True)
source.replace(asset) if False else None
print('Generated rounded launcher icons and splash asset.')
