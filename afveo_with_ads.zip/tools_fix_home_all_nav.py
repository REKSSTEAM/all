from pathlib import Path

p = Path('lib/main.dart')
s = p.read_text()

# Make horizontal home-section posters slightly smaller while preserving their aspect ratio.
s = s.replace(
"              itemBuilder: (_, i) => CardItem(x[i]),\n              separatorBuilder: (_, __) => const SizedBox(width: 22),",
"              itemBuilder: (_, i) => CardItem(x[i], width: 136),\n              separatorBuilder: (_, __) => const SizedBox(width: 16),",
1,
)

# Add a flag so CatalogPage can show a bar when opened from an All link,
# while Movies and TV pages hosted inside Shell keep only Shell's bar.
s = s.replace(
"  final String type;\n  const CatalogPage({\n    super.key,\n    required this.title,\n    required this.path,\n    required this.type,\n  });",
"  final String type;\n  final bool showBottomBar;\n  const CatalogPage({\n    super.key,\n    required this.title,\n    required this.path,\n    required this.type,\n    this.showBottomBar = false,\n  });",
1,
)

# All links explicitly opt into the bottom bar.
s = s.replace(
"                    path: allPath,\n                    type: allType,\n                  ),",
"                    path: allPath,\n                    type: allType,\n                    showBottomBar: true,\n                  ),",
1,
)

# Put one bottom bar on standalone CatalogPage screens opened by All.
needle = """              ),
            ],
          );
        },
      ),
    ),
  );
}

class Explore extends StatelessWidget {"""
replacement = """              ),
            ],
          );
        },
      ),
    ),
    bottomNavigationBar: widget.showBottomBar
        ? BottomBar(
            index: widget.type == 'tv' ? 2 : 1,
            onTap: (i) => Navigator.pushReplacement(
              c,
              MaterialPageRoute(builder: (_) => Shell(initialIndex: i)),
            ),
          )
        : null,
  );
}

class Explore extends StatelessWidget {"""
if needle not in s:
    raise SystemExit('CatalogPage scaffold ending not found')
s = s.replace(needle, replacement, 1)
p.write_text(s)
print('home image sizing and All navigation updated')
