# AFVeo 1.9.0 — Deployment

## التطبيق

هذه النسخة تستخدم WebView داخليًا لتشغيل `https://afflix.xo.je/embed`، وتحمّل إعدادات الإدارة عند شاشة Splash من:

`https://rezx.dockhosting.dev/admin/api/config.php`

إذا كان مسار لوحة الإدارة مختلفًا، عدّل `AdminRuntime.base` في `lib/main.dart` ثم أعد بناء APK.

## لوحة الإدارة

ارفع محتويات مجلد `afveo-admin/public` إلى مجلد Public مستقل، بحيث تصبح النقطتان التاليتان متاحتين عبر HTTPS:

- `/admin/api/config.php`
- `/admin/api/heartbeat.php`

ثبّت قاعدة MySQL باستخدام `database.sql`، ثم اضبط متغيرات البيئة التالية أو عدّل القيم الافتراضية في `config/database.php`:

| المتغير | الوصف |
|---|---|
| `AFVEO_DB_HOST` | عنوان خادم MySQL |
| `AFVEO_DB_NAME` | اسم قاعدة البيانات |
| `AFVEO_DB_USER` | مستخدم قاعدة البيانات |
| `AFVEO_DB_PASS` | كلمة مرور قاعدة البيانات |

غيّر كلمة مرور مدير اللوحة الافتراضية قبل النشر، واستخدم HTTPS حتى لا تُرسل بيانات الإدارة أو heartbeat عبر اتصال غير مشفر.

## إعدادات الإدارة المدعومة

تعيد `config.php` إعدادات الصيانة، الإصدار، الأقسام الرئيسية، الإعلانات، والروابط الاجتماعية. عند تفعيل الصيانة يمنع التطبيق الدخول إلى Home. وعند تفعيل `force_update` يعرض رابط تنزيل التحديث. يتم عرض أول إعلان فعال عند دخول Home، وتُستخدم روابط Instagram وTelegram وFacebook وX في Footer.

## heartbeat

يرسل التطبيق `device_id` و`platform` و`app_version` إلى `heartbeat.php`. يجب أن يكون `device_id` ثابتًا لكل تثبيت في نسخة الإنتاج حتى لا يُحسب كل تشغيل كمستخدم جديد؛ يمكن استبدال القيمة الحالية بتخزين دائم عبر `shared_preferences` إذا رغبت بقراءة إحصاءات دقيقة جدًا.

## البناء

```bash
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH="$JAVA_HOME/bin:$PATH"
flutter pub get
flutter build apk --release --build-name=1.9.0 --build-number=19
```

ملف APK الناتج هو `build/app/outputs/flutter-apk/app-release.apk`.
