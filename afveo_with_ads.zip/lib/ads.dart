import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// ============================================================
/// إعدادات إعلانات AdMob
/// ============================================================
/// المعرّفات أدناه هي معرّفات AdMob التجريبية الرسمية من جوجل، وهي تعمل
/// فورًا أثناء التطوير والاختبار بدون أي إعداد إضافي.
///
/// قبل نشر التطبيق على المتجر:
/// 1) افتح حساب AdMob الخاص بك (https://apps.admob.com) وأنشئ وحدات
///    الإعلانات (App Open / Banner) لتطبيق Afveo كما بدأت بالفعل.
/// 2) انسخ "معرّف التطبيق" (Application ID) الخاص بك واستبدل به القيمة
///    الموجودة في:
///      - android/app/src/main/AndroidManifest.xml (مفتاح APPLICATION_ID)
///      - ios/Runner/Info.plist (مفتاح GADApplicationIdentifier)
/// 3) انسخ معرّفات وحدات الإعلان (Ad unit ID) الخاصة بك والصقها هنا
///    بدلاً من المعرّفات التجريبية بالأسفل.
class AdConfig {
  AdConfig._();

  // إعلان فتح التطبيق (App Open Ad) — يظهر أول ما تفتح التطبيق
  static const _testAndroidAppOpen = 'ca-app-pub-3940256099942544/9257395921';
  static const _testIosAppOpen = 'ca-app-pub-3940256099942544/5575463023';
  // ضع هنا معرّف وحدة "إعلان على شاشة فتح التطبيق" الحقيقي من AdMob
  static const androidAppOpenUnitId = _testAndroidAppOpen;
  static const iosAppOpenUnitId = _testIosAppOpen;

  // إعلان بانر (Banner) — يُستخدم بين الأقسام، وفي صفحتي البحث والتفاصيل
  static const _testAndroidBanner = 'ca-app-pub-3940256099942544/9214589741';
  static const _testIosBanner = 'ca-app-pub-3940256099942544/2934735716';
  // ضع هنا معرّف وحدة "إعلان بانر" الحقيقي من AdMob
  static const androidBannerUnitId = _testAndroidBanner;
  static const iosBannerUnitId = _testIosBanner;

  static bool get _isAndroid =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  static String get appOpenUnitId =>
      _isAndroid ? androidAppOpenUnitId : iosAppOpenUnitId;
  static String get bannerUnitId =>
      _isAndroid ? androidBannerUnitId : iosBannerUnitId;
}

/// يدير تحميل وعرض "إعلان فتح التطبيق" (App Open Ad).
/// يظهر بملء الشاشة مع زر إغلاق (X) صغير تضيفه شبكة AdMob تلقائيًا.
class AppOpenAdManager {
  AppOpenAdManager._();
  static final AppOpenAdManager instance = AppOpenAdManager._();

  AppOpenAd? _ad;
  bool _isLoading = false;
  bool _isShowing = false;
  DateTime? _loadedAt;

  bool get _isAdFresh =>
      _loadedAt != null &&
      DateTime.now().difference(_loadedAt!) < const Duration(hours: 4);

  bool get _isAdAvailable => _ad != null && _isAdFresh;

  /// يبدأ تحميل الإعلان مسبقًا (يُستدعى عند إقلاع التطبيق).
  void load() {
    if (_isLoading || _isAdAvailable) return;
    _isLoading = true;
    AppOpenAd.load(
      adUnitId: AdConfig.appOpenUnitId,
      request: const AdRequest(),
      adLoadCallback: AppOpenAdLoadCallback(
        onAdLoaded: (ad) {
          _ad = ad;
          _loadedAt = DateTime.now();
          _isLoading = false;
        },
        onAdFailedToLoad: (error) {
          _isLoading = false;
        },
      ),
    );
  }

  /// يعرض الإعلان إن كان جاهزًا، وإلا ينفّذ [onComplete] مباشرة (مع محاولة
  /// تحميل نسخة جديدة لاستخدامها لاحقًا).
  void showIfAvailable({required VoidCallback onComplete}) {
    if (_isShowing) return;
    if (!_isAdAvailable) {
      load();
      onComplete();
      return;
    }
    final ad = _ad!;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdShowedFullScreenContent: (_) => _isShowing = true,
      onAdDismissedFullScreenContent: (ad) {
        _isShowing = false;
        ad.dispose();
        _ad = null;
        load();
        onComplete();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        _isShowing = false;
        ad.dispose();
        _ad = null;
        load();
        onComplete();
      },
    );
    ad.show();
  }
}

/// عنصر واجهة قابل لإعادة الاستخدام يعرض إعلان بانر من AdMob.
/// يختفي تلقائيًا (دون حجز أي مساحة) إذا فشل تحميل الإعلان.
class BannerAdWidget extends StatefulWidget {
  const BannerAdWidget({super.key, this.margin});
  final EdgeInsetsGeometry? margin;

  @override
  State<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends State<BannerAdWidget> {
  BannerAd? _ad;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    final ad = BannerAd(
      adUnitId: AdConfig.bannerUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) {
          if (mounted) setState(() => _loaded = true);
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
        },
      ),
    );
    _ad = ad;
    ad.load();
  }

  @override
  void dispose() {
    _ad?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ad = _ad;
    if (!_loaded || ad == null) return const SizedBox.shrink();
    return Container(
      margin: widget.margin ?? const EdgeInsets.symmetric(vertical: 10),
      alignment: Alignment.center,
      width: ad.size.width.toDouble(),
      height: ad.size.height.toDouble(),
      child: AdWidget(ad: ad),
    );
  }
}
