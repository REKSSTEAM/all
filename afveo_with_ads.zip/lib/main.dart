import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'ads.dart';

class ApiConfig {
  static const tmdbBase = 'https://api.themoviedb.org/3';
  static const imageBase = 'https://image.tmdb.org/t/p/';
  static const streamApi = 'https://rezx.dockhosting.dev/api/easy/index.php';
  static const easyKey = '7';
 
  static const streamApiKey = '';
  // قالب Embed الخارجي؛ يمكن تبديله لاحقًا إلى نطاقك الخاص دون تغيير بقية التطبيق.
  static const embedBase = ''https://afveo.xo.je/embed';
  static const embedColor = '6c63ff';
  static const tmdbKey = '60a8d6ad3b8e5fbdbde539526b196d9b';
}

class AdminRuntime {
  static const base = 'https://rezx.dockhosting.dev/admin/api';
  static Map<String, dynamic> data = const {};
  static bool loaded = false;

  static Future<void> load() async {
    try {
      final r = await http
          .get(Uri.parse('$base/config.php'))
          .timeout(const Duration(seconds: 5));
      if (r.statusCode == 200) {
        final decoded = jsonDecode(r.body);
        if (decoded is Map<String, dynamic> && decoded['ok'] == true) {
          data = decoded;
          loaded = true;
        }
      }
      await http
          .post(
            Uri.parse('$base/heartbeat.php'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'device_id': 'afveo-${DateTime.now().millisecondsSinceEpoch}',
              'platform': 'android',
              'app_version': '1.9.0',
            }),
          )
          .timeout(const Duration(seconds: 4));
    } catch (_) {
      loaded = false;
    }
  }

  static Map<String, dynamic> get maintenance => (data['maintenance'] is Map)
      ? Map<String, dynamic>.from(data['maintenance'])
      : const {};
  static Map<String, dynamic> get version => (data['version'] is Map)
      ? Map<String, dynamic>.from(data['version'])
      : const {};
  static bool get isMaintenance =>
      maintenance['enabled'] == true ||
      maintenance['enabled'] == 1 ||
      maintenance['enabled'] == '1';
  static bool get forceUpdate =>
      version['force_update'] == true ||
      version['force_update'] == 1 ||
      version['force_update'] == '1';
  static List<Map<String, dynamic>> get sections =>
      (data['home_sections'] is List)
      ? (data['home_sections'] as List)
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList()
      : const [];
  static List<Map<String, dynamic>> get announcements =>
      (data['announcements'] is List)
      ? (data['announcements'] as List)
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList()
      : const [];
  static Map<String, dynamic> get social => (data['social'] is Map)
      ? Map<String, dynamic>.from(data['social'])
      : const {};
}

const red = Color(0xffff3039),
    bg = Color(0xff070809),
    panel = Color(0xff17191d);

class MediaItem {
  final int id;
  final String type, title, overview, poster, backdrop, date;
  final double rating;
  const MediaItem({
    required this.id,
    required this.type,
    required this.title,
    this.overview = '',
    this.poster = '',
    this.backdrop = '',
    this.date = '',
    this.rating = 0,
  });
  factory MediaItem.fromJson(Map<String, dynamic> j, [String? forced]) =>
      MediaItem(
        id: (j['id'] ?? 0) as int,
        type: forced ?? (j['media_type'] == 'tv' ? 'tv' : 'movie'),
        title: '${j['title'] ?? j['name'] ?? 'Unknown'}',
        overview: '${j['overview'] ?? ''}',
        poster: '${j['poster_path'] ?? ''}',
        backdrop: '${j['backdrop_path'] ?? ''}',
        date: '${j['release_date'] ?? j['first_air_date'] ?? ''}',
        rating: ((j['vote_average'] ?? 0) as num).toDouble(),
      );
}

String image(String p, String s) =>
    p.isEmpty ? '' : '${ApiConfig.imageBase}$s$p';

class Tmdb {
  Future<List<MediaItem>> list(
    String path, {
    String type = '',
    int page = 1,
    Map<String, String> params = const {},
  }) async {
    final u = Uri.parse('${ApiConfig.tmdbBase}/$path').replace(
      queryParameters: {
        'api_key': ApiConfig.tmdbKey,
        'language': 'en-US',
        'include_adult': 'false',
        'page': '$page',
        ...params,
      },
    );
    final r = await http.get(u).timeout(const Duration(seconds: 18));
    if (r.statusCode != 200) throw Exception('TMDB ${r.statusCode}');
    final d = jsonDecode(r.body) as Map<String, dynamic>;
    final inferred = type.isNotEmpty
        ? type
        : (path.startsWith('tv/')
              ? 'tv'
              : path.startsWith('movie/')
              ? 'movie'
              : null);
    return ((d['results'] ?? []) as List)
        .map((x) => MediaItem.fromJson(x, inferred))
        .toList();
  }

  Future<List<MediaItem>> search(String q) async {
    final u = Uri.parse('${ApiConfig.tmdbBase}/search/multi').replace(
      queryParameters: {
        'api_key': ApiConfig.tmdbKey,
        'language': 'en-US',
        'query': q,
      },
    );
    final r = await http.get(u).timeout(const Duration(seconds: 18));
    if (r.statusCode != 200) throw Exception('Search');
    final d = jsonDecode(r.body) as Map<String, dynamic>;
    return ((d['results'] ?? []) as List)
        .where((x) => x['media_type'] == 'movie' || x['media_type'] == 'tv')
        .map((x) => MediaItem.fromJson(x))
        .toList();
  }

  Future<Map<String, dynamic>> details(MediaItem m) async {
    final u = Uri.parse('${ApiConfig.tmdbBase}/${m.type}/${m.id}').replace(
      queryParameters: {
        'api_key': ApiConfig.tmdbKey,
        'language': 'en-US',
        'append_to_response': 'credits,similar,recommendations',
      },
    );
    final r = await http.get(u).timeout(const Duration(seconds: 18));
    if (r.statusCode != 200) throw Exception('Details');
    return jsonDecode(r.body) as Map<String, dynamic>;
  }
}

final tmdb = Tmdb();

class Quality {
  final String label, url;
  Quality(this.label, this.url);
  factory Quality.fromJson(Map<String, dynamic> j) =>
      Quality('${j['label'] ?? 'HD'}', '${j['url'] ?? ''}');
}

class StreamProvider {
  final String id;
  final String name;
  const StreamProvider(this.id, this.name);
}

class ApiDebugEntry {
  final String operation;
  final String url;
  final int statusCode;
  final String contentType;
  final Map<String, String> headers;
  final String bodyPreview;
  final DateTime time;
  ApiDebugEntry({
    required this.operation,
    required this.url,
    required this.statusCode,
    required this.contentType,
    required this.headers,
    required this.bodyPreview,
    required this.time,
  });
}

final apiDebugLog = <ApiDebugEntry>[];

String _safeDebugUrl(Uri uri) {
  final p = Map<String, String>.from(uri.queryParameters);
  if (p.containsKey('token')) p['token'] = '***hidden***';
  return uri.replace(queryParameters: p).toString();
}

void recordApiDebug(http.Response r, String operation, Uri uri) {
  final body = r.body;
  final preview = body.length > 4000
      ? '${body.substring(0, 4000)}\\n...[truncated]'
      : body;
  apiDebugLog.insert(
    0,
    ApiDebugEntry(
      operation: operation,
      url: _safeDebugUrl(uri),
      statusCode: r.statusCode,
      contentType: r.headers['content-type'] ?? '',
      headers: Map<String, String>.from(r.headers),
      bodyPreview: preview,
      time: DateTime.now(),
    ),
  );
  if (apiDebugLog.length > 20) apiDebugLog.removeLast();
}

class StreamApi {
  final cache = <String, Map<String, dynamic>>{};
  Map<String, String> get _headers => {
    'Accept': 'application/json',
    'User-Agent': 'AFVeo Android',
    'X-Easy-Key': ApiConfig.easyKey,
  };

  Uri _easyUri(Map<String, String> params) =>
      Uri.parse(ApiConfig.streamApi).replace(
        queryParameters: <String, String>{'key': ApiConfig.easyKey, ...params},
      );

  Future<List<StreamProvider>> easyProviders() async {
    final requestUri = _easyUri({'action': 'providers'});
    final r = await http
        .get(requestUri, headers: _headers)
        .timeout(const Duration(seconds: 25));
    recordApiDebug(r, 'Easy Providers', requestUri);
    final d = decodeApiJson(r, 'Easy Providers');
    if (r.statusCode != 200 || d['ok'] != true)
      throw Exception(d['error'] ?? 'No providers');
    final raw = d['providers'];
    final result = <StreamProvider>[];
    if (raw is List) {
      for (final x in raw) {
        if (x is Map) {
          final id = '${x['id'] ?? x['provider'] ?? ''}';
          final name = '${x['name'] ?? x['title'] ?? id}';
          if (id.isNotEmpty) result.add(StreamProvider(id, name));
        }
      }
    }
    if (result.isEmpty) throw Exception('No streaming servers available');
    return result;
  }

  Future<List<Quality>> easySources(
    MediaItem m,
    String provider, {
    int season = 1,
    int episode = 1,
  }) async {
    final params = <String, String>{
      'action': 'sources',
      'provider': provider,
      'type': m.type,
      'id': '${m.id}',
    };
    if (m.type == 'tv') {
      params['season'] = '$season';
      params['episode'] = '$episode';
    }
    final requestUri = _easyUri(params);
    final r = await http
        .get(requestUri, headers: _headers)
        .timeout(const Duration(seconds: 55));
    recordApiDebug(r, 'Easy Sources $provider', requestUri);
    final d = decodeApiJson(r, 'Easy Sources');
    if (r.statusCode != 200 || d['ok'] != true)
      throw Exception(d['error'] ?? 'No sources from $provider');
    final raw = d['sources'] ?? d['source'] ?? d['qualities'];
    final list = raw is List
        ? raw
        : raw is Map
        ? <dynamic>[raw]
        : <dynamic>[];
    final result = <Quality>[];
    final seen = <String>{};
    for (final x in list) {
      if (x is! Map) continue;
      final nested = x['qualities'];
      final qualities = nested is List ? nested : <dynamic>[x];
      for (final q in qualities) {
        if (q is! Map) continue;
        final url = '${q['url'] ?? q['m3u8'] ?? ''}';
        if (url.isEmpty || !seen.add(url)) continue;
        result.add(Quality('${q['label'] ?? q['quality'] ?? provider}', url));
      }
    }
    if (result.isEmpty) throw Exception('No playable sources from $provider');
    return result;
  }

  Future<String> token(String type, int id) async {
    final k = '$type:$id';
    final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final saved = cache[k];
    if (saved != null && (saved['refresh_at'] ?? 0) > now) {
      return '${saved['token']}';
    }
    final requestUri = Uri.parse(
      ApiConfig.streamApi,
    ).replace(queryParameters: {'action': 'token', 'type': type, 'id': '$id'});
    final r = await http
        .get(requestUri, headers: _headers)
        .timeout(const Duration(seconds: 25));
    recordApiDebug(r, 'Token', requestUri);
    final d = decodeApiJson(r, 'Token');
    if (r.statusCode != 200 ||
        d['ok'] != true ||
        '${d['token'] ?? ''}'.isEmpty) {
      throw Exception(d['error'] ?? 'Token failed');
    }
    cache[k] = Map<String, dynamic>.from(d);
    return '${d['token']}';
  }

  Future<List<StreamProvider>> providers(MediaItem m, String t) async {
    final requestUri = Uri.parse(ApiConfig.streamApi).replace(
      queryParameters: {
        'action': 'providers',
        'type': m.type,
        'id': '${m.id}',
        'token': t,
      },
    );
    final r = await http
        .get(requestUri, headers: _headers)
        .timeout(const Duration(seconds: 35));
    recordApiDebug(r, 'Providers', requestUri);
    final d = decodeApiJson(r, 'Providers');
    if (r.statusCode != 200 || d['ok'] != true) {
      throw Exception(d['error'] ?? 'No providers');
    }
    final raw = d['providers'] ?? d['data'] ?? d['sources'];
    final list = raw is List ? raw : <dynamic>[];
    final result = <StreamProvider>[];
    for (final x in list) {
      if (x is String && x.isNotEmpty) {
        result.add(StreamProvider(x, x));
      } else if (x is Map) {
        final id =
            '${x['id'] ?? x['slug'] ?? x['provider'] ?? x['name'] ?? ''}';
        final name = '${x['name'] ?? x['title'] ?? id}';
        if (id.isNotEmpty) result.add(StreamProvider(id, name));
      }
    }
    if (result.isEmpty) throw Exception('No streaming servers available');
    return result;
  }

  Future<List<Quality>> sources(
    MediaItem m,
    String t, {
    int? season,
    int? episode,
  }) async {
    final params = <String, String>{
      'action': 'sources',
      'type': m.type,
      'id': '${m.id}',
      'token': t,
    };
    if (m.type == 'tv') {
      if (season != null) params['season'] = '$season';
      if (episode != null) params['episode'] = '$episode';
    }
    final requestUri = Uri.parse(
      ApiConfig.streamApi,
    ).replace(queryParameters: params);
    final r = await http
        .get(requestUri, headers: _headers)
        .timeout(const Duration(seconds: 50));
    recordApiDebug(r, 'Sources', requestUri);
    final d = decodeApiJson(r, 'Sources');
    if (r.statusCode != 200 || d['ok'] != true) {
      throw Exception(d['error'] ?? 'No sources');
    }
    final raw = d['sources'] ?? d['source'] ?? d['qualities'];
    final list = raw is List
        ? raw
        : raw is Map
        ? <dynamic>[raw]
        : <dynamic>[];
    final result = <Quality>[];
    final seen = <String>{};
    for (final x in list) {
      if (x is! Map) continue;
      final nested = x['qualities'];
      final qualities = nested is List ? nested : <dynamic>[x];
      for (final q in qualities) {
        if (q is! Map) continue;
        final url = '${q['url'] ?? q['m3u8'] ?? ''}';
        if (url.isEmpty || !seen.add(url)) continue;
        result.add(Quality('${q['label'] ?? q['quality'] ?? 'HD'}', url));
      }
    }
    if (result.isEmpty) throw Exception('No playable sources');
    return result;
  }
}

Map<String, dynamic> decodeApiJson(http.Response r, String operation) {
  final body = r.body.trim();
  final contentType = r.headers['content-type'] ?? '';
  if (body.isEmpty) {
    throw Exception(
      '$operation API returned an empty response (HTTP ${r.statusCode})',
    );
  }
  if (body.startsWith('<') || contentType.contains('text/html')) {
    final isAesChallenge =
        body.contains('/aes.js') || body.contains('document.cookie');
    throw Exception(
      isAesChallenge
          ? 'الخادم محمي بتحدي AES ويمنع تطبيق Android من الوصول إلى API. يجب استثناء /api/v1/stream.php من الحماية في الخادم.'
          : 'الخادم أعاد صفحة HTML بدل JSON (HTTP ${r.statusCode}). تحقق من رابط API أو إعدادات الاستضافة.',
    );
  }
  try {
    final decoded = jsonDecode(body);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Response is not a JSON object');
    }
    return decoded;
  } on FormatException catch (e) {
    throw Exception('$operation API returned invalid JSON: ${e.message}');
  }
}

final streamApi = StreamApi();
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  AppOpenAdManager.instance.load();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'AFVeo',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(
        seedColor: red,
        brightness: Brightness.dark,
      ),
      fontFamily: 'Arial',
      useMaterial3: true,
    ),
    home: const Splash(),
  );
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    await Future.wait([
      AdminRuntime.load(),
      Future<void>.delayed(const Duration(milliseconds: 1200)),
    ]);
    if (!mounted) return;
    final destination = AdminRuntime.isMaintenance
        ? const AdminMessagePage(maintenance: true)
        : AdminRuntime.forceUpdate
        ? const AdminMessagePage(maintenance: false)
        : const Shell();

    void navigate() {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => destination),
      );
    }

    // يظهر إعلان فتح التطبيق (مع زر إغلاق X) فقط عند الدخول الطبيعي
    // للتطبيق، وليس في حالتي الصيانة أو التحديث الإجباري.
    if (destination is Shell) {
      AppOpenAdManager.instance.showIfAvailable(onComplete: navigate);
    } else {
      navigate();
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    backgroundColor: bg,
    body: Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(42),
            child: Image.asset(
              'assets/images/afveo_logo.jpg',
              width: 150,
              height: 150,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 22),
          const Text(
            'AFVeo',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 24),
          const SizedBox(
            width: 24,
            height: 24,
            child: CircularProgressIndicator(color: red, strokeWidth: 2),
          ),
        ],
      ),
    ),
  );
}

class AdminMessagePage extends StatelessWidget {
  final bool maintenance;
  const AdminMessagePage({super.key, required this.maintenance});

  @override
  Widget build(BuildContext context) {
    final source = maintenance
        ? AdminRuntime.maintenance
        : AdminRuntime.version;
    final title =
        '${source['title'] ?? (maintenance ? 'التطبيق تحت الصيانة' : 'يتوفر تحديث جديد')}';
    final message =
        '${source['description'] ?? (maintenance ? 'سنعود قريبًا.' : 'يرجى تنزيل أحدث نسخة للمتابعة.')}';
    final url = '${source['button_url'] ?? source['android_update_url'] ?? ''}';
    return Scaffold(
      backgroundColor: bg,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.system_update_alt, color: red, size: 64),
              const SizedBox(height: 18),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70, fontSize: 16),
              ),
              if (url.isNotEmpty && !maintenance) ...[
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  onPressed: () => launchUrl(
                    Uri.parse(url),
                    mode: LaunchMode.externalApplication,
                  ),
                  icon: const Icon(Icons.download),
                  label: const Text('تنزيل التحديث'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class Shell extends StatefulWidget {
  final int initialIndex;
  const Shell({super.key, this.initialIndex = 0});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  late int index;

  @override
  void initState() {
    super.initState();
    index = widget.initialIndex;
  }

  final pages = const [Home(), Movies(), TvShows(), Explore(), Saved()];
  @override
  Widget build(BuildContext c) => Scaffold(
    body: SafeArea(
      top: false,
      child: IndexedStack(index: index, children: pages),
    ),
    bottomNavigationBar: BottomBar(
      index: index,
      onTap: (i) => setState(() => index = i),
    ),
  );
}

class BottomBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const BottomBar({super.key, required this.index, required this.onTap});
  Widget item(int i, IconData icon, String text) => Expanded(
    child: InkWell(
      onTap: () => onTap(i),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: index == i ? red : Colors.white60, size: 21),
          const SizedBox(height: 3),
          Text(
            text,
            style: TextStyle(
              color: index == i ? red : Colors.white70,
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 3),
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: index == i ? 16 : 0,
            height: 2,
            decoration: BoxDecoration(
              color: red,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ],
      ),
    ),
  );
  @override
  Widget build(BuildContext c) => ClipRect(
    child: BackdropFilter(
      filter: ui.ImageFilter.blur(sigmaX: 14, sigmaY: 14),
      child: SafeArea(
        top: false,
        bottom: true,
        minimum: const EdgeInsets.only(bottom: 3),
        child: Container(
          height: 67,
          decoration: BoxDecoration(
            color: const Color(0xff0d0e11).withOpacity(.94),
            border: const Border(
              top: BorderSide(color: Color(0xff25262a)),
            ),
          ),
          child: Row(
            children: [
              item(0, Icons.home_filled, 'Home'),
              item(1, Icons.movie_outlined, 'Movies'),
              Expanded(
                child: InkWell(
                  onTap: () => onTap(2),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 43,
                        height: 43,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [red, Color(0xffff4242)],
                          ),
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                              color: red.withOpacity(.35),
                              blurRadius: 22,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.tv, size: 23),
                      ),
                      const Text(
                        'TV',
                        style: TextStyle(color: Colors.white70, fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ),
              item(3, Icons.explore_outlined, 'Explore'),
              item(4, Icons.bookmark_border, 'Saved'),
            ],
          ),
        ),
      ),
    ),
  );
}

class Header extends StatelessWidget {
  const Header({super.key});
  @override
  Widget build(BuildContext c) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
    child: Row(
      children: [
        _HeaderIconButton(
          icon: Icons.menu_rounded,
          tooltip: 'القائمة الجانبية',
          onTap: () => Navigator.push(
            c,
            MaterialPageRoute(builder: (_) => const SettingsPage()),
          ),
        ),
        const SizedBox(width: 10),
        const Text(
          'AF',
          style: TextStyle(
            color: red,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            letterSpacing: -.5,
          ),
        ),
        const Text(
          'Veo',
          style: TextStyle(
            color: Colors.white,
            fontSize: 26,
            fontWeight: FontWeight.w800,
            letterSpacing: -.5,
          ),
        ),
        const Spacer(),
        _HeaderIconButton(
          icon: Icons.search,
          tooltip: 'بحث',
          onTap: () => Navigator.push(
            c,
            MaterialPageRoute(builder: (_) => const SearchPage()),
          ),
        ),
      ],
    ),
  );
}

class _HeaderIconButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;
  const _HeaderIconButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });
  @override
  Widget build(BuildContext c) => Tooltip(
    message: tooltip,
    child: Material(
      color: Colors.white.withOpacity(.06),
      shape: CircleBorder(
        side: BorderSide(color: Colors.white.withOpacity(.08)),
      ),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(icon, size: 20, color: Colors.white),
        ),
      ),
    ),
  );
}

class Section extends StatelessWidget {
  final String title;
  final Future<List<MediaItem>> future;
  final String allPath;
  final String allType;
  const Section({
    super.key,
    required this.title,
    required this.future,
    required this.allPath,
    this.allType = '',
  });
  @override
  Widget build(BuildContext c) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 18, 9),
        child: Row(
          children: [
            Expanded(
              child: Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            TextButton(
              onPressed: () => Navigator.push(
                c,
                MaterialPageRoute(
                  builder: (_) => CatalogPage(
                    title: title,
                    path: allPath,
                    type: allType,
                    showBottomBar: true,
                  ),
                ),
              ),
              style: TextButton.styleFrom(
                foregroundColor: red,
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                minimumSize: Size.zero,
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
              child: const Text(
                'See All  ›',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      ),
      SizedBox(
        height: 245,
        child: FutureBuilder<List<MediaItem>>(
          future: future,
          builder: (c, s) {
            if (s.connectionState == ConnectionState.waiting)
              return const Center(child: CircularProgressIndicator(color: red));
            if (s.hasError)
              return const Padding(
                padding: EdgeInsets.symmetric(horizontal: 32),
                child: Text(
                  'Unable to load content',
                  style: TextStyle(color: Colors.white54),
                ),
              );
            final x = s.data ?? [];
            return ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              scrollDirection: Axis.horizontal,
              itemCount: x.length,
              itemBuilder: (_, i) => CardItem(x[i], width: 136, compact: true),
              separatorBuilder: (_, __) => const SizedBox(width: 16),
            );
          },
        ),
      ),
    ],
  );
}

class CardItem extends StatelessWidget {
  final MediaItem item;
  final double width;
  final bool compact;
  const CardItem(
    this.item, {
    super.key,
    this.width = 156,
    this.compact = false,
  });
  @override
  Widget build(BuildContext c) {
    return GestureDetector(
      onTap: () => Navigator.push(
        c,
        MaterialPageRoute(builder: (_) => Details(item: item)),
      ),
      child: SizedBox(
        width: width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(.4),
                    blurRadius: 14,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: AspectRatio(
                      aspectRatio: .68,
                      child: CachedNetworkImage(
                        imageUrl: image(item.poster, 'w500'),
                        fit: BoxFit.cover,
                        errorWidget: (_, __, ___) => const ColoredBox(
                          color: panel,
                          child: Icon(Icons.movie, color: Colors.white24),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 10,
                    left: 10,
                    child: Badge(
                      icon: Icons.star,
                      color: const Color(0xff252a2d),
                      text: item.rating.toStringAsFixed(1),
                    ),
                  ),
                  Positioned(
                    top: 10,
                    right: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(.55),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        item.type == 'tv' ? 'TV' : 'Movie',
                        style: const TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Text(
              item.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: compact ? 13 : 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              item.date.length >= 4 ? item.date.substring(0, 4) : item.date,
              style: TextStyle(
                color: Colors.white60,
                fontSize: compact ? 12 : 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Badge extends StatelessWidget {
  final IconData? icon;
  final Color color;
  final String text;
  const Badge({super.key, this.icon, required this.color, required this.text});
  @override
  Widget build(BuildContext c) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(.92),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null)
            Icon(icon, color: const Color(0xffffc72c), size: 18),
          if (icon != null) const SizedBox(width: 4),
          Text(text, style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class _HomeSectionData {
  final String title;
  final String path;
  final String type;
  final List<MediaItem> items;
  const _HomeSectionData(this.title, this.path, this.type, this.items);
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late final Future<List<_HomeSectionData>> _sections;

  @override
  void initState() {
    super.initState();
    _sections = _loadSectionsWithoutDuplicates();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => _showAdminAnnouncement(),
    );
  }

  Future<void> _showAdminAnnouncement() async {
    final list = AdminRuntime.announcements;
    if (!mounted || list.isEmpty) return;
    final a = list.first;
    final title = '${a['title'] ?? ''}'.trim();
    final description = '${a['description'] ?? ''}'.trim();
    final link = '${a['link_url'] ?? ''}'.trim();
    if (title.isEmpty && description.isEmpty) return;
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: panel,
        title: Text(title.isEmpty ? 'تنبيه' : title),
        content: Text(
          description,
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          if (link.isNotEmpty)
            TextButton(
              onPressed: () => launchUrl(
                Uri.parse(link),
                mode: LaunchMode.externalApplication,
              ),
              child: const Text('فتح الرابط'),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إغلاق'),
          ),
        ],
      ),
    );
  }

  Future<List<_HomeSectionData>> _loadSectionsWithoutDuplicates() async {
    final used = <String>{};
    final sections = <_HomeSectionData>[];

    Future<void> add(
      String title,
      String path,
      String type,
      Future<List<MediaItem>> request, {
      Map<String, String> params = const {},
    }) async {
      final results = await request;
      final unique = results.where((item) {
        final key = '${item.type}:${item.id}';
        return used.add(key);
      }).toList();
      sections.add(_HomeSectionData(title, path, type, unique));
    }

    final remote = AdminRuntime.sections;
    if (remote.isNotEmpty) {
      for (final config in remote) {
        final title = '${config['title'] ?? ''}'.trim();
        final path = '${config['api_path'] ?? ''}'.trim();
        final type = '${config['content_type'] ?? ''}'.trim();
        if (title.isEmpty || path.isEmpty) continue;
        try {
          await add(title, path, type, tmdb.list(path, type: type));
        } catch (_) {
          // القسم المُدار عن بعد لا يمنع ظهور بقية الصفحة عند فشل طلبه.
        }
      }
      if (sections.isNotEmpty) return sections;
    }

    await add(
      'Trending This Week',
      'trending/all/week',
      '',
      tmdb.list('trending/all/week'),
    );
    await add(
      'Now Playing in Theaters',
      'movie/now_playing',
      'movie',
      tmdb.list('movie/now_playing', type: 'movie'),
    );
    await add(
      'Most Popular',
      'movie/popular',
      'movie',
      tmdb.list('movie/popular', type: 'movie'),
    );
    await add(
      'Top Rated',
      'movie/top_rated',
      'movie',
      tmdb.list('movie/top_rated', type: 'movie'),
    );
    await add(
      'Coming Soon',
      'movie/upcoming',
      'movie',
      tmdb.list('movie/upcoming', type: 'movie'),
    );
    await add(
      'Trending TV This Week',
      'trending/tv/week',
      'tv',
      tmdb.list('trending/tv/week', type: 'tv'),
    );
    await add(
      'Most Popular TV Shows',
      'tv/popular',
      'tv',
      tmdb.list('tv/popular', type: 'tv'),
    );
    await add(
      'Currently Airing',
      'tv/on_the_air',
      'tv',
      tmdb.list('tv/on_the_air', type: 'tv'),
    );
    await add(
      'Top Rated TV Shows',
      'tv/top_rated',
      'tv',
      tmdb.list('tv/top_rated', type: 'tv'),
    );
    await add(
      'Anime',
      'discover/tv',
      'tv',
      tmdb.list(
        'discover/tv',
        type: 'tv',
        params: const {
          'with_genres': '16',
          'with_original_language': 'ja',
          'sort_by': 'popularity.desc',
        },
      ),
    );
    return sections;
  }

  @override
  Widget build(BuildContext c) => CustomScrollView(
    slivers: [
      const SliverToBoxAdapter(child: Header()),
      SliverToBoxAdapter(child: HeroBlock()),
      const SliverToBoxAdapter(child: SizedBox(height: 18)),
      SliverToBoxAdapter(
        child: FutureBuilder<List<_HomeSectionData>>(
          future: _sections,
          builder: (c, s) {
            if (s.connectionState == ConnectionState.waiting) {
              return const Padding(
                padding: EdgeInsets.all(35),
                child: Center(child: CircularProgressIndicator(color: red)),
              );
            }
            if (s.hasError) {
              return const Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Unable to load sections',
                  style: TextStyle(color: Colors.white60),
                ),
              );
            }
            final sectionsData = s.data ?? <_HomeSectionData>[];
            return Column(
              children: [
                for (int i = 0; i < sectionsData.length; i++) ...[
                  Section(
                    title: sectionsData[i].title,
                    future: Future.value(sectionsData[i].items),
                    allPath: sectionsData[i].path,
                    allType: sectionsData[i].type,
                  ),
                  // إعلان بانر بين أقسام الأفلام/المسلسلات كل قسمين.
                  if ((i + 1) % 2 == 0 && i != sectionsData.length - 1)
                    const BannerAdWidget(),
                ],
                const TitleBlock(
                  icon: Icons.movie_outlined,
                  text: 'Browse More',
                ),
                const Footer(),
              ],
            );
          },
        ),
      ),
    ],
  );
}

class HeroBlock extends StatefulWidget {
  const HeroBlock({super.key});
  @override
  State<HeroBlock> createState() => _HeroBlockState();
}

class _HeroBlockState extends State<HeroBlock> {
  late final Future<List<MediaItem>> _future;
  PageController? _controller;
  Timer? _timer;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _future = tmdb.list('trending/all/week');
  }

  void _startAutoPlay(int count) {
    if (count < 2 || _timer != null) return;
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted || _controller == null || !_controller!.hasClients) return;
      final next = (_index + 1) % count;
      _controller!.animateToPage(
        next,
        duration: const Duration(milliseconds: 550),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller?.dispose();
    super.dispose();
  }

  Widget _slide(BuildContext context, MediaItem x) => Stack(
    fit: StackFit.expand,
    children: [
      CachedNetworkImage(
        imageUrl: image(x.backdrop, 'w1280'),
        fit: BoxFit.cover,
      ),
      const DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.transparent, Color(0xff070809)],
            stops: [0.35, 1],
          ),
        ),
      ),
      const DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.centerRight,
            end: Alignment.centerLeft,
            colors: [Colors.transparent, Color(0xcc070809)],
          ),
        ),
      ),
      Positioned(
        left: 20,
        right: 20,
        bottom: 22,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.12),
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Text(
                'TRENDING',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.4,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              x.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w900,
                height: 1.15,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                if (x.date.length >= 4)
                  Text(
                    x.date.substring(0, 4),
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                const SizedBox(width: 8),
                Container(
                  width: 3,
                  height: 3,
                  decoration: const BoxDecoration(
                    color: Colors.white38,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  x.type == 'tv' ? 'TV' : 'Movie',
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 3,
                  height: 3,
                  decoration: const BoxDecoration(
                    color: Colors.white38,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                const Icon(Icons.star, color: Color(0xffffc72c), size: 14),
                const SizedBox(width: 3),
                Text(
                  x.rating.toStringAsFixed(1),
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            InkWell(
              borderRadius: BorderRadius.circular(999),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => Details(item: x)),
              ),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 22,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [red, Color(0xffff4242)],
                  ),
                  borderRadius: BorderRadius.circular(999),
                  boxShadow: [
                    BoxShadow(
                      color: red.withOpacity(.4),
                      blurRadius: 18,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.play_arrow_rounded, size: 20),
                    SizedBox(width: 6),
                    Text(
                      'Watch Now',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    ],
  );

  @override
  Widget build(BuildContext context) => FutureBuilder<List<MediaItem>>(
    future: _future,
    builder: (context, snapshot) {
      final media = (snapshot.data ?? [])
          .where((x) => x.backdrop.isNotEmpty)
          .take(10)
          .toList();
      if (media.isEmpty) return const SizedBox(height: 240);
      _startAutoPlay(media.length);
      _controller ??= PageController();
      return SizedBox(
        height: 420,
        child: Stack(
          children: [
            PageView.builder(
              controller: _controller,
              itemCount: media.length,
              onPageChanged: (value) => setState(() => _index = value),
              itemBuilder: (_, i) => _slide(context, media[i]),
            ),
            if (media.length > 1)
              Positioned(
                right: 20,
                bottom: 12,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(
                    media.length,
                    (i) => AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      width: i == _index ? 18 : 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: i == _index ? red : Colors.white54,
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      );
    },
  );
}

class TitleBlock extends StatelessWidget {
  final IconData icon;
  final String text;
  const TitleBlock({super.key, required this.icon, required this.text});
  @override
  Widget build(BuildContext c) => Padding(
    padding: const EdgeInsets.fromLTRB(32, 38, 20, 2),
    child: Row(
      children: [
        Container(
          width: 5,
          height: 42,
          decoration: BoxDecoration(
            color: red,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(width: 14),
        Icon(icon, color: red, size: 35),
        const SizedBox(width: 12),
        Text(
          text,
          style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900),
        ),
      ],
    ),
  );
}

class Footer extends StatelessWidget {
  const Footer({super.key});

  Widget _social(BuildContext context, String key, Widget icon) {
    final url = '${AdminRuntime.social[key] ?? ''}'.trim();
    return InkWell(
      onTap: url.isEmpty
          ? null
          : () =>
                launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
      borderRadius: BorderRadius.circular(30),
      child: Opacity(opacity: url.isEmpty ? .45 : 1, child: icon),
    );
  }

  @override
  Widget build(BuildContext c) => Padding(
    padding: const EdgeInsets.fromLTRB(32, 42, 32, 25),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'AFVeo',
          style: TextStyle(
            color: red,
            fontSize: 30,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          'Stream unlimited movies and TV shows\nfrom around the world.',
          style: TextStyle(color: Colors.white60, fontSize: 17, height: 1.45),
        ),
        const SizedBox(height: 25),
        const Row(
          children: [
            Text(
              'BROWSE',
              style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2),
            ),
            Spacer(),
            Text(
              'LISTS',
              style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2),
            ),
          ],
        ),
        const SizedBox(height: 12),
        const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Text(
                'Home\nMovies\nTV Shows\nExplore',
                style: TextStyle(fontSize: 16, height: 2),
              ),
            ),
            Expanded(
              child: Text(
                'Popular\nTop Rated\nUpcoming\nNow Playing',
                style: TextStyle(fontSize: 16, height: 2),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        const Text(
          'الحساب',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text(
          'حسابي\nمحفوظاتي\nتسجيل الخروج',
          style: TextStyle(fontSize: 17, height: 2),
        ),
        const SizedBox(height: 22),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _social(
              c,
              'instagram',
              const CircleAvatar(
                backgroundColor: Color(0xffe1306c),
                child: Icon(Icons.camera_alt),
              ),
            ),
            _social(
              c,
              'telegram',
              const CircleAvatar(
                backgroundColor: Color(0xff229ed9),
                child: Icon(Icons.send),
              ),
            ),
            _social(
              c,
              'facebook',
              const CircleAvatar(
                backgroundColor: Color(0xff1877f2),
                child: Text('f', style: TextStyle(fontSize: 25)),
              ),
            ),
            _social(
              c,
              'x',
              const CircleAvatar(
                backgroundColor: Colors.black,
                child: Text('X', style: TextStyle(fontSize: 20)),
              ),
            ),
          ],
        ),
      ],
    ),
  );
}

class Movies extends StatelessWidget {
  const Movies({super.key});
  @override
  Widget build(BuildContext c) =>
      const CatalogPage(title: 'Movies', path: 'movie/popular', type: 'movie');
}

class TvShows extends StatelessWidget {
  const TvShows({super.key});
  @override
  Widget build(BuildContext c) =>
      const CatalogPage(title: 'TV Shows', path: 'tv/popular', type: 'tv');
}

class CatalogPage extends StatefulWidget {
  final String title;
  final String path;
  final String type;
  final bool showBottomBar;
  const CatalogPage({
    super.key,
    required this.title,
    required this.path,
    required this.type,
    this.showBottomBar = false,
  });
  @override
  State<CatalogPage> createState() => _CatalogPageState();
}

class _CatalogPageState extends State<CatalogPage> {
  int page = 1;

  @override
  Widget build(BuildContext c) => Scaffold(
    backgroundColor: bg,
    body: SafeArea(
      child: FutureBuilder<List<MediaItem>>(
        future: tmdb.list(widget.path, type: widget.type, page: page),
        builder: (c, s) {
          final items = s.data ?? <MediaItem>[];
          return CustomScrollView(
            slivers: [
              const SliverToBoxAdapter(child: Header()),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(28, 4, 28, 16),
                  child: Row(
                    children: [
                      Text(
                        widget.title,
                        style: const TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        'Page $page',
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 15,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (s.connectionState == ConnectionState.waiting)
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: Center(child: CircularProgressIndicator(color: red)),
                )
              else if (s.hasError)
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: Center(
                    child: Text(
                      'Unable to load content',
                      style: TextStyle(color: Colors.white60),
                    ),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(
                      (c, i) => CardItem(
                        items[i],
                        width: double.infinity,
                        compact: true,
                      ),
                      childCount: items.length,
                    ),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 18,
                          childAspectRatio: .53,
                        ),
                  ),
                ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 4, 24, 120),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton.icon(
                        onPressed: page > 1
                            ? () => setState(() => page--)
                            : null,
                        icon: const Icon(Icons.arrow_back),
                        label: const Text('Previous'),
                      ),
                      Text(
                        'Page $page',
                        style: const TextStyle(color: Colors.white70),
                      ),
                      TextButton.icon(
                        onPressed: () => setState(() => page++),
                        icon: const Icon(Icons.arrow_forward),
                        label: const Text('Next'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    ),
    bottomNavigationBar: widget.showBottomBar
        ? BottomBar(
            index: widget.type == 'tv' ? 2 : 1,
            onTap: (i) => Navigator.pushReplacement(
              c,
              MaterialPageRoute(builder: (_) => Shell(initialIndex: i)),
            ),
          )
        : null,
  );
}

class Explore extends StatelessWidget {
  const Explore({super.key});
  static const movieGenres = [
    'Action',
    'Adventure',
    'Animation',
    'Comedy',
    'Crime',
    'Drama',
    'Horror',
    'Science Fiction',
    'Thriller',
    'Romance',
    'Fantasy',
    'Family',
  ];
  static const tvGenres = [
    'Action & Adventure',
    'Comedy',
    'Drama',
    'Documentary',
    'Kids',
    'Mystery',
    'News',
    'Reality',
    'Sci-Fi & Fantasy',
    'War & Politics',
  ];
  Widget heading(String text) => Padding(
    padding: const EdgeInsets.fromLTRB(32, 26, 32, 14),
    child: Text(
      text,
      style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900),
    ),
  );
  Widget tiles(List<String> list) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Column(
      children: [
        for (final name in list)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: GenreTile(name: name),
          ),
      ],
    ),
  );
  @override
  Widget build(BuildContext c) => CustomScrollView(
    slivers: [
      const SliverToBoxAdapter(child: Header()),
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(32, 28, 32, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'Explore',
                style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900),
              ),
              SizedBox(height: 8),
              Text(
                'Browse by category and discover\nsomething new',
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 20,
                  height: 1.35,
                ),
              ),
            ],
          ),
        ),
      ),
      SliverToBoxAdapter(child: heading('Movie Genres')),
      SliverToBoxAdapter(child: tiles(movieGenres)),
      SliverToBoxAdapter(child: heading('TV Genres')),
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.only(bottom: 120),
          child: tiles(tvGenres),
        ),
      ),
    ],
  );
}

class GenreTile extends StatelessWidget {
  final String name;
  const GenreTile({super.key, required this.name});
  @override
  Widget build(BuildContext c) => Material(
    color: const Color(0xff1b0d0f),
    borderRadius: BorderRadius.circular(22),
    child: InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => Navigator.push(
        c,
        MaterialPageRoute(builder: (_) => GenreResults(name: name)),
      ),
      child: Container(
        height: 92,
        padding: const EdgeInsets.symmetric(horizontal: 22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: const Color(0xff5a2026), width: 1.3),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                name,
                style: const TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const Icon(Icons.arrow_forward, color: red, size: 25),
          ],
        ),
      ),
    ),
  );
}

class GenreResults extends StatelessWidget {
  final String name;
  const GenreResults({super.key, required this.name});
  @override
  Widget build(BuildContext c) => Scaffold(
    backgroundColor: bg,
    body: SafeArea(
      child: Column(
        children: [
          const Header(),
          Padding(
            padding: const EdgeInsets.fromLTRB(32, 8, 32, 16),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                name,
                style: const TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<MediaItem>>(
              future: tmdb.list('discover/movie', type: 'movie'),
              builder: (c, s) {
                if (s.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(color: red),
                  );
                }
                final items = s.data ?? [];
                return GridView.builder(
                  padding: const EdgeInsets.fromLTRB(24, 8, 24, 28),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 14,
                    mainAxisSpacing: 18,
                    childAspectRatio: .62,
                  ),
                  itemCount: items.length,
                  itemBuilder: (_, i) => CardItem(items[i]),
                );
              },
            ),
          ),
        ],
      ),
    ),
    bottomNavigationBar: BottomBar(
      index: 3,
      onTap: (i) => Navigator.pushReplacement(
        c,
        MaterialPageRoute(builder: (_) => Shell(initialIndex: i)),
      ),
    ),
  );
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchState();
}

class _SearchState extends State<SearchPage> {
  final ctl = TextEditingController();
  Timer? timer;
  Future<List<MediaItem>>? result;
  @override
  void dispose() {
    timer?.cancel();
    ctl.dispose();
    super.dispose();
  }

  void go(String s) {
    timer?.cancel();
    timer = Timer(const Duration(milliseconds: 450), () {
      if (mounted)
        setState(() => result = s.trim().isEmpty ? null : tmdb.search(s));
    });
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    backgroundColor: bg,
    body: SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 20, 12),
            child: Row(
              children: [
                _HeaderIconButton(
                  icon: Icons.arrow_back,
                  tooltip: 'رجوع',
                  onTap: () => Navigator.pop(c),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: panel,
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color: Colors.white.withOpacity(.08),
                      ),
                    ),
                    child: TextField(
                      controller: ctl,
                      onChanged: go,
                      autofocus: true,
                      style: const TextStyle(fontSize: 15),
                      decoration: InputDecoration(
                        prefixIcon: Icon(
                          Icons.search,
                          color: Colors.white.withOpacity(.5),
                        ),
                        hintText: 'Search movies and TV shows',
                        hintStyle: TextStyle(
                          color: Colors.white.withOpacity(.4),
                        ),
                        filled: true,
                        fillColor: Colors.transparent,
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 14,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(999),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const BannerAdWidget(margin: EdgeInsets.only(bottom: 6)),
          Expanded(
            child: FutureBuilder<List<MediaItem>>(
              future: result,
              builder: (c, s) {
                if (s.connectionState == ConnectionState.waiting)
                  return const Center(
                    child: CircularProgressIndicator(color: red),
                  );
                final x = s.data ?? [];
                if (result != null && x.isEmpty) {
                  return const Center(
                    child: Text(
                      'No results',
                      style: TextStyle(color: Colors.white54),
                    ),
                  );
                }
                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
                  itemCount: x.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (_, i) => _SearchResultTile(item: x[i]),
                );
              },
            ),
          ),
        ],
      ),
    ),
  );
}

class _SearchResultTile extends StatelessWidget {
  final MediaItem item;
  const _SearchResultTile({required this.item});
  @override
  Widget build(BuildContext c) {
    final year = item.date.length >= 4 ? item.date.substring(0, 4) : '';
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => Navigator.push(
        c,
        MaterialPageRoute(builder: (_) => Details(item: item)),
      ),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.03),
          border: Border.all(color: Colors.white.withOpacity(.08)),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: CachedNetworkImage(
                imageUrl: image(item.poster, 'w200'),
                width: 50,
                height: 75,
                fit: BoxFit.cover,
                errorWidget: (_, __, ___) => const ColoredBox(
                  color: panel,
                  child: Icon(Icons.movie, color: Colors.white24, size: 20),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    [
                      if (year.isNotEmpty) year,
                      item.type == 'tv' ? 'TV' : 'Movie',
                    ].join('  •  '),
                    style: const TextStyle(
                      color: Colors.white60,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.chevron_right,
              color: Colors.white24,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}

class Saved extends StatefulWidget {
  const Saved({super.key});
  @override
  State<Saved> createState() => _SavedState();
}

class _SavedState extends State<Saved> {
  List<MediaItem> items = [];
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final a = p.getStringList('saved') ?? [];
    if (mounted)
      setState(
        () => items = a.map((x) => MediaItem.fromJson(jsonDecode(x))).toList(),
      );
  }

  @override
  Widget build(BuildContext c) => Column(
    children: [
      const Header(),
      Expanded(
        child: items.isEmpty
            ? const Center(
                child: Text(
                  'Nothing saved yet',
                  style: TextStyle(color: Colors.white60),
                ),
              )
            : GridView.builder(
                padding: const EdgeInsets.all(18),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 15,
                  mainAxisSpacing: 20,
                  childAspectRatio: .64,
                ),
                itemCount: items.length,
                itemBuilder: (_, i) => CardItem(items[i]),
              ),
      ),
    ],
  );
}

Future<void> recordRecentWatch(MediaItem item) async {
  final p = await SharedPreferences.getInstance();
  final list = p.getStringList('recent_watched') ?? <String>[];
  list.removeWhere((x) {
    try {
      final j = jsonDecode(x);
      return j['id'] == item.id && j['media_type'] == item.type;
    } catch (_) {
      return false;
    }
  });
  list.insert(
    0,
    jsonEncode({
      'id': item.id,
      'media_type': item.type,
      'title': item.title,
      'overview': item.overview,
      'poster_path': item.poster,
      'backdrop_path': item.backdrop,
      'vote_average': item.rating,
      'release_date': item.date,
      'watched_at': DateTime.now().toIso8601String(),
    }),
  );
  if (list.length > 50) list.removeRange(50, list.length);
  await p.setStringList('recent_watched', list);
}

Future<void> addDownload(MediaItem item) async {
  final p = await SharedPreferences.getInstance();
  final list = p.getStringList('downloads') ?? <String>[];
  final exists = list.any((x) {
    try {
      final j = jsonDecode(x);
      return j['id'] == item.id && j['media_type'] == item.type;
    } catch (_) {
      return false;
    }
  });
  if (!exists) {
    list.insert(
      0,
      jsonEncode({
        'id': item.id,
        'media_type': item.type,
        'title': item.title,
        'overview': item.overview,
        'poster_path': item.poster,
        'backdrop_path': item.backdrop,
        'vote_average': item.rating,
        'release_date': item.date,
        'added_at': DateTime.now().toIso8601String(),
      }),
    );
    await p.setStringList('downloads', list);
  }
}

class Details extends StatefulWidget {
  final MediaItem item;
  const Details({super.key, required this.item});
  @override
  State<Details> createState() => _DetailsState();
}

class _DetailsState extends State<Details> {
  Map<String, dynamic>? data;
  bool saved = false;
  bool downloaded = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final a = p.getStringList('saved') ?? [];
      saved = a.any((x) => jsonDecode(x)['id'] == widget.item.id);
      final downloads = p.getStringList('downloads') ?? <String>[];
      downloaded = downloads.any((x) => jsonDecode(x)['id'] == widget.item.id);
      final d = await tmdb.details(widget.item);
      if (mounted) setState(() => data = d);
    } catch (_) {}
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    final a = p.getStringList('saved') ?? [];
    if (saved) {
      a.removeWhere((x) => jsonDecode(x)['id'] == widget.item.id);
    } else {
      a.add(
        jsonEncode({
          'id': widget.item.id,
          'media_type': widget.item.type,
          'title': widget.item.title,
          'overview': widget.item.overview,
          'poster_path': widget.item.poster,
          'backdrop_path': widget.item.backdrop,
          'vote_average': widget.item.rating,
          'release_date': widget.item.date,
        }),
      );
    }
    await p.setStringList('saved', a);
    if (mounted) setState(() => saved = !saved);
  }

  Future<void> download() async {
    await addDownload(widget.item);
    if (!mounted) return;
    setState(() => downloaded = true);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تمت إضافة العمل إلى التحميلات')),
    );
  }

  List<Map<String, dynamic>> listMap(dynamic value) {
    if (value is! List) return [];
    return value
        .whereType<Map>()
        .map((x) => Map<String, dynamic>.from(x))
        .toList();
  }

  @override
  Widget build(BuildContext c) {
    final m = widget.item;
    final d = data ?? <String, dynamic>{};
    final cast = listMap((d['credits'] as Map?)?['cast']).take(9).toList();
    final crew = listMap((d['credits'] as Map?)?['crew']);
    final director = crew.where((x) => x['job'] == 'Director').take(1).toList();
    final recommendations = listMap(
      (d['recommendations'] as Map?)?['results'],
    ).take(9).toList();
    final genres = listMap(d['genres']);
    final runtime = d['runtime'];
    final year = m.date.length >= 4 ? m.date.substring(0, 4) : '';

    return Scaffold(
      backgroundColor: bg,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: bg,
            pinned: true,
            expandedHeight: 300,
            leading: _HeaderIconButton(
              icon: Icons.arrow_back,
              tooltip: 'رجوع',
              onTap: () => Navigator.pop(c),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  CachedNetworkImage(
                    imageUrl: image(m.backdrop, 'w1280'),
                    fit: BoxFit.cover,
                  ),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, bg],
                        stops: [0.3, 1],
                      ),
                    ),
                  ),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerRight,
                        end: Alignment.centerLeft,
                        colors: [Colors.transparent, Color(0x99070809)],
                      ),
                    ),
                  ),
                  Positioned(
                    left: 20,
                    bottom: 16,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(.55),
                            blurRadius: 22,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: CachedNetworkImage(
                          imageUrl: image(m.poster, 'w500'),
                          width: 138,
                          height: 202,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 22, 20, 120),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                Text(
                  m.title,
                  style: const TextStyle(
                    fontSize: 36,
                    height: 1.08,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                if ((d['tagline'] ?? '').toString().isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text(
                    '“${d['tagline']}”',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 19,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ],
                const SizedBox(height: 18),
                Row(
                  children: [
                    const Icon(Icons.star, color: Color(0xffffc72c), size: 18),
                    const SizedBox(width: 4),
                    Text(
                      m.rating.toStringAsFixed(1),
                      style: const TextStyle(
                        color: Color(0xffffcf40),
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    if (year.isNotEmpty) ...[
                      const SizedBox(width: 8),
                      const _MetaDot(),
                      const SizedBox(width: 8),
                      Text(
                        year,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                    if (runtime is num && runtime > 0) ...[
                      const SizedBox(width: 8),
                      const _MetaDot(),
                      const SizedBox(width: 8),
                      Text(
                        '${runtime}m',
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                    const SizedBox(width: 8),
                    const _MetaDot(),
                    const SizedBox(width: 8),
                    Text(
                      m.type == 'tv' ? 'TV' : 'Movie',
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Wrap(
                  spacing: 9,
                  runSpacing: 9,
                  children: genres.isEmpty
                      ? [const _GenreChip('Drama')]
                      : [
                          for (final g in genres.take(5))
                            _GenreChip('${g['name'] ?? ''}'),
                        ],
                ),
                const SizedBox(height: 28),
                const _SectionHeading('Overview'),
                const SizedBox(height: 10),
                Text(
                  m.overview.isEmpty ? 'No overview available' : m.overview,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 18,
                    height: 1.55,
                  ),
                ),
                const SizedBox(height: 26),
                Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(999),
                        onTap: () async {
                          await recordRecentWatch(m);
                          if (!c.mounted) return;
                          await Navigator.push(
                            c,
                            MaterialPageRoute(builder: (_) => Watch(item: m)),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [red, Color(0xffff4242)],
                            ),
                            borderRadius: BorderRadius.circular(999),
                            boxShadow: [
                              BoxShadow(
                                color: red.withOpacity(.4),
                                blurRadius: 18,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.play_arrow_rounded, size: 22),
                              SizedBox(width: 6),
                              Text(
                                'Watch Now',
                                style: TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 15),
                          side: const BorderSide(color: Colors.white30),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(999),
                          ),
                        ),
                        onPressed: () {},
                        icon: const Icon(Icons.play_circle_outline),
                        label: const Text('Trailer'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    IconButton.filled(
                      onPressed: save,
                      icon: Icon(
                        saved ? Icons.bookmark : Icons.bookmark_border,
                      ),
                    ),
                    const SizedBox(width: 10),
                    IconButton.filled(
                      onPressed: () {},
                      icon: const Icon(Icons.share),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: download,
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(
                        color: downloaded ? Colors.greenAccent : Colors.white30,
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    icon: Icon(
                      downloaded
                          ? Icons.download_done
                          : Icons.download_outlined,
                    ),
                    label: Text(
                      downloaded
                          ? 'تمت الإضافة إلى التحميلات'
                          : 'إضافة إلى التحميلات',
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                if (director.isNotEmpty) ...[
                  const Text(
                    'DIRECTOR',
                    style: TextStyle(
                      color: Colors.white60,
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 12),
                  PersonRow(person: director.first),
                  const SizedBox(height: 28),
                ],
                const _SectionHeading('Top Cast'),
                const SizedBox(height: 14),
                CastCarousel(cast: cast),
                const SizedBox(height: 20),
                const BannerAdWidget(),
                const SizedBox(height: 10),
                if (recommendations.isNotEmpty) ...[
                  const _SectionHeading('More Like This'),
                  const SizedBox(height: 14),
                  RecommendationGrid(items: recommendations, type: m.type),
                ],
              ]),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomBar(
        index: m.type == 'tv' ? 2 : 1,
        onTap: (i) {
          Navigator.pushReplacement(
            c,
            MaterialPageRoute(builder: (_) => Shell(initialIndex: i)),
          );
        },
      ),
    );
  }
}

class _MetaDot extends StatelessWidget {
  const _MetaDot();
  @override
  Widget build(BuildContext c) => Container(
    width: 3,
    height: 3,
    decoration: const BoxDecoration(
      color: Colors.white38,
      shape: BoxShape.circle,
    ),
  );
}

class _GenreChip extends StatelessWidget {
  final String label;
  const _GenreChip(this.label);
  @override
  Widget build(BuildContext c) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(.05),
      border: Border.all(color: Colors.white.withOpacity(.14)),
      borderRadius: BorderRadius.circular(999),
    ),
    child: Text(
      label,
      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
    ),
  );
}

class _SectionHeading extends StatelessWidget {
  final String text;
  const _SectionHeading(this.text);
  @override
  Widget build(BuildContext c) => Row(
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      Container(width: 4, height: 22, color: red),
      const SizedBox(width: 10),
      Text(
        text,
        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
      ),
    ],
  );
}

class PersonRow extends StatelessWidget {
  final Map<String, dynamic> person;
  const PersonRow({super.key, required this.person});
  @override
  Widget build(BuildContext c) => Container(
    height: 82,
    padding: const EdgeInsets.symmetric(horizontal: 12),
    decoration: BoxDecoration(
      color: panel,
      borderRadius: BorderRadius.circular(42),
      border: Border.all(color: Colors.white12),
    ),
    child: Row(
      children: [
        CircleAvatar(
          radius: 28,
          backgroundImage: CachedNetworkImageProvider(
            image('${person['profile_path'] ?? ''}', 'w185'),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Text(
            '${person['name'] ?? ''}',
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
          ),
        ),
      ],
    ),
  );
}

class CastCarousel extends StatelessWidget {
  final List<Map<String, dynamic>> cast;
  const CastCarousel({super.key, required this.cast});
  @override
  Widget build(BuildContext c) => SizedBox(
    height: 205,
    child: ListView.separated(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.only(right: 4),
      itemCount: cast.length,
      separatorBuilder: (_, __) => const SizedBox(width: 16),
      itemBuilder: (_, i) {
        final x = cast[i];
        return SizedBox(
          width: 126,
          child: Column(
            children: [
              ClipOval(
                child: CachedNetworkImage(
                  imageUrl: image('${x['profile_path'] ?? ''}', 'w185'),
                  width: 108,
                  height: 108,
                  fit: BoxFit.cover,
                  errorWidget: (_, __, ___) => const ColoredBox(
                    color: panel,
                    child: Icon(Icons.person, color: Colors.white38),
                  ),
                ),
              ),
              const SizedBox(height: 9),
              Text(
                '${x['name'] ?? ''}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 3),
              Text(
                '${x['character'] ?? ''}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white54, fontSize: 12),
              ),
            ],
          ),
        );
      },
    ),
  );
}

class RecommendationGrid extends StatelessWidget {
  final List<Map<String, dynamic>> items;
  final String type;
  const RecommendationGrid({
    super.key,
    required this.items,
    required this.type,
  });
  @override
  Widget build(BuildContext c) => GridView.builder(
    shrinkWrap: true,
    physics: const NeverScrollableScrollPhysics(),
    itemCount: items.length,
    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 3,
      crossAxisSpacing: 10,
      mainAxisSpacing: 18,
      childAspectRatio: .53,
    ),
    itemBuilder: (_, i) => CardItem(
      MediaItem.fromJson(items[i], type),
      width: double.infinity,
      compact: true,
    ),
  );
}

class Watch extends StatefulWidget {
  final MediaItem item;
  const Watch({super.key, required this.item});
  @override
  State<Watch> createState() => _WatchState();
}

class _WatchState extends State<Watch> {
  late final WebViewController _controller;
  bool loading = true;
  String? error;
  bool _webFullscreen = false;

  String _buildEmbedUrl() {
    final type = widget.item.type == 'tv' ? 'tv' : 'movie';
    if (type == 'tv') {
      return '${ApiConfig.embedBase}/tv/${widget.item.id}/1/1?color=${ApiConfig.embedColor}';
    }
    return '${ApiConfig.embedBase}/movie/${widget.item.id}?color=${ApiConfig.embedColor}';
  }

  Future<void> _loadPlayback() async {
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }
    try {
      // التشغيل القديم المعتمد في النسخ السابقة: تحميل صفحة Embed مباشرة.
      // لا نستخدم Token/Providers/Sources هنا حتى لا يتغير مسار التشغيل القديم.
      final embedUrl = _buildEmbedUrl();
      final target = Uri.tryParse(embedUrl);
      if (target == null ||
          !(target.scheme == 'http' || target.scheme == 'https')) {
        throw Exception('Invalid Embed URL');
      }
      await _controller.loadRequest(target);
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          loading = false;
          error = e.toString().replaceFirst('Exception: ', '');
        });
      }
    }
  }

  Future<void> _setWebFullscreen(bool enabled) async {
    _webFullscreen = enabled;
    await SystemChrome.setPreferredOrientations(
      enabled
          ? const [
              DeviceOrientation.landscapeLeft,
              DeviceOrientation.landscapeRight,
            ]
          : const [
              DeviceOrientation.portraitUp,
              DeviceOrientation.portraitDown,
            ],
    );
    await SystemChrome.setEnabledSystemUIMode(
      enabled ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge,
    );
    await _applyPlayerBottomSafeArea(enabled);
    if (mounted) setState(() {});
  }

  Future<void> _applyPlayerBottomSafeArea(bool fullscreen) async {
    final controlCss = fullscreen
        ? ''
        : '''
          :is(.plyr__controls, .vjs-control-bar, .jw-controlbar,
               .jw-controls, .video-js .vjs-control-bar,
               [class*="controls" i], [class*="control-bar" i],
               [class*="video-controls" i], [class*="progress" i],
               [id*="controls" i], [id*="control-bar" i]) {
            transform: translateY(-48px) !important;
            bottom: max(48px, env(safe-area-inset-bottom, 0px)) !important;
            padding-bottom: 8px !important;
          }
        ''';
    await _controller.runJavaScript('''
      (() => {
        const id = 'afveo-bottom-safe-area';
        let style = document.getElementById(id);
        if (!style) {
          style = document.createElement('style');
          style.id = id;
          document.head.appendChild(style);
        }
        style.textContent = `
          html, body { background: #000 !important; }
          body {
            padding-bottom: 0 !important;
            box-sizing: border-box !important;
          }
          video, iframe, #player, .player, [class*="player" i] {
            max-height: 100% !important;
          }
          $controlCss
        `;
      })();
    ''');
  }

  Future<void> _installFullscreenBridge() async {
    await _controller.runJavaScript('''
      (() => {
        if (window.__afveoFullscreenBridgeInstalled) return;
        window.__afveoFullscreenBridgeInstalled = true;
        const notify = (state) => {
          try { AFVeoFullscreen.postMessage(state ? 'enter' : 'exit'); } catch (_) {}
        };
        const originalRequest = Element.prototype.requestFullscreen;
        Element.prototype.requestFullscreen = function() {
          notify(true);
          if (originalRequest) {
            return originalRequest.call(this).catch(() => undefined);
          }
          return Promise.resolve();
        };
        const originalExit = document.exitFullscreen;
        document.exitFullscreen = function() {
          notify(false);
          if (originalExit) {
            return originalExit.call(document).catch(() => undefined);
          }
          return Promise.resolve();
        };
        document.addEventListener('fullscreenchange', () => {
          notify(Boolean(document.fullscreenElement));
        });
        document.addEventListener('click', (event) => {
          const target = event.target.closest && event.target.closest(
            '[aria-label*="fullscreen" i], [title*="fullscreen" i], ' +
            '[class*="fullscreen" i], [data-testid*="fullscreen" i]'
          );
          if (target) {
            setTimeout(() => notify(Boolean(document.fullscreenElement)), 250);
          }
        }, true);
      })();
    ''');
  }

  Future<void> _hideVideoPlaceholder() async {
    await _controller.runJavaScript('''
      (() => {
        const clearPoster = () => {
          document.querySelectorAll('video').forEach((video) => {
            video.removeAttribute('poster');
            video.style.backgroundImage = 'none';
          });
          document.querySelectorAll('.vjs-poster, .plyr__poster, .jw-preview, .video-poster, .video-placeholder').forEach((node) => {
            node.style.backgroundImage = 'none';
            node.style.backgroundColor = 'transparent';
            node.style.opacity = '0';
            node.style.pointerEvents = 'none';
          });
        };
        clearPoster();
        setTimeout(clearPoster, 300);
        setTimeout(clearPoster, 1000);
        setTimeout(clearPoster, 2500);
      })();
    ''');
  }

  Future<void> _enterPlayerFullscreen() async {
    await SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  Future<void> _restoreAppOrientation() async {
    await SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: bg,
        systemNavigationBarColor: Color(0xff0d0e11),
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarIconBrightness: Brightness.light,
        systemNavigationBarContrastEnforced: false,
      ),
    );
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }

  @override
  void initState() {
    super.initState();
    recordRecentWatch(widget.item);
    _restoreAppOrientation();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel(
        'AFVeoFullscreen',
        onMessageReceived: (message) {
          _setWebFullscreen(message.message == 'enter');
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => mounted
              ? setState(() {
                  loading = true;
                  error = null;
                })
              : null,
          onPageFinished: (_) async {
            await _installFullscreenBridge();
            await _applyPlayerBottomSafeArea(_webFullscreen);
            await _hideVideoPlaceholder();
            if (mounted) setState(() => loading = false);
          },
          onWebResourceError: (e) {
            if (mounted && e.isForMainFrame == true) {
              setState(() {
                loading = false;
                error = e.description;
              });
            }
          },
        ),
      );
    _loadPlayback();
  }

  @override
  void dispose() {
    _restoreAppOrientation();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      // حذف الشريط العلوي من شاشة المشاهدة؛ الرجوع يعمل من زر Android.
      body: SafeArea(
        top: true,
        bottom: false,
        child: Stack(
          children: [
            Padding(
              padding: EdgeInsets.only(
                bottom: _webFullscreen
                    ? 0
                    : MediaQuery.viewPaddingOf(context).bottom + 10,
              ),
              child: WebViewWidget(controller: _controller),
            ),
            if (loading)
              const ColoredBox(
                color: Colors.black,
                child: Center(child: CircularProgressIndicator(color: red)),
              ),
            if (error != null && !loading)
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.error_outline, color: red, size: 48),
                      const SizedBox(height: 12),
                      Text(
                        error!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                        onPressed: () => _controller.reload(),
                        icon: const Icon(Icons.refresh),
                        label: const Text('إعادة المحاولة'),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class RecentWatchedPage extends StatefulWidget {
  const RecentWatchedPage({super.key});
  @override
  State<RecentWatchedPage> createState() => _RecentWatchedPageState();
}

class _RecentWatchedPageState extends State<RecentWatchedPage> {
  List<MediaItem> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('recent_watched') ?? <String>[];
    if (!mounted) return;
    setState(() {
      items = raw.map((x) => MediaItem.fromJson(jsonDecode(x))).toList();
    });
  }

  Future<void> _remove(MediaItem item) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('recent_watched') ?? <String>[];
    raw.removeWhere((x) {
      final j = jsonDecode(x);
      return j['id'] == item.id && j['media_type'] == item.type;
    });
    await p.setStringList('recent_watched', raw);
    await _load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: bg,
    appBar: AppBar(
      backgroundColor: bg,
      title: const Text(
        'تمت مشاهدته مؤخرًا',
        style: TextStyle(fontWeight: FontWeight.w800),
      ),
    ),
    body: items.isEmpty
        ? const Center(
            child: Text(
              'لا توجد أعمال تمت مشاهدتها مؤخرًا',
              style: TextStyle(color: Colors.white60),
            ),
          )
        : ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (_, i) {
              final item = items[i];
              return Dismissible(
                key: ValueKey('${item.type}-${item.id}'),
                direction: DismissDirection.endToStart,
                onDismissed: (_) => _remove(item),
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  decoration: BoxDecoration(
                    color: Colors.red.shade900,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(Icons.delete_outline),
                ),
                child: Card(
                  color: panel,
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(10),
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: CachedNetworkImage(
                        imageUrl: image(item.poster, 'w185'),
                        width: 58,
                        height: 82,
                        fit: BoxFit.cover,
                      ),
                    ),
                    title: Text(
                      item.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: const Text(
                      'تمت مشاهدته مؤخرًا',
                      style: TextStyle(color: Colors.white54),
                    ),
                    trailing: IconButton(
                      icon: const Icon(
                        Icons.delete_outline,
                        color: Colors.white60,
                      ),
                      onPressed: () => _remove(item),
                    ),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => Details(item: item)),
                    ),
                  ),
                ),
              );
            },
          ),
  );
}

class _MenuLabel extends StatelessWidget {
  final String text;
  const _MenuLabel(this.text);
  @override
  Widget build(BuildContext c) => Text(
    text,
    style: TextStyle(
      fontSize: 12,
      fontWeight: FontWeight.w800,
      letterSpacing: 1.1,
      color: Colors.white.withOpacity(.5),
    ),
  );
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _signedIn = false;
  String _accountName = '';
  String _avatarPath = '';
  int _savedCount = 0;
  int _historyCount = 0;

  @override
  void initState() {
    super.initState();
    _loadAccountData();
  }

  Future<void> _loadAccountData() async {
    final p = await SharedPreferences.getInstance();
    final saved = p.getStringList('saved') ?? <String>[];
    final history = p.getStringList('recent_watched') ?? <String>[];
    if (!mounted) return;
    setState(() {
      _signedIn = p.getBool('account_signed_in') ?? false;
      _accountName = p.getString('account_name') ?? '';
      _avatarPath = p.getString('avatar_path') ?? '';
      _savedCount = saved.length;
      _historyCount = history.length;
    });
  }

  Future<void> _pickAvatar() async {
    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 82,
      maxWidth: 900,
    );
    if (picked == null) return;
    final p = await SharedPreferences.getInstance();
    await p.setString('avatar_path', picked.path);
    await _loadAccountData();
  }

  Future<void> _showAccountDialog({required bool create}) async {
    final controller = TextEditingController(text: _accountName);
    final password = TextEditingController();
    final formKey = GlobalKey<FormState>();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: panel,
        title: Text(create ? 'إنشاء حساب' : 'تسجيل الدخول'),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: controller,
                decoration: const InputDecoration(
                  labelText: 'الاسم أو البريد الإلكتروني',
                ),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'أدخل الاسم' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: password,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'كلمة المرور'),
                validator: (v) =>
                    (v == null || v.length < 4) ? 'أدخل كلمة مرور صحيحة' : null,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () async {
              if (!(formKey.currentState?.validate() ?? false)) return;
              final p = await SharedPreferences.getInstance();
              await p.setBool('account_signed_in', true);
              await p.setString('account_name', controller.text.trim());
              if (!mounted) return;
              Navigator.pop(dialogContext);
              await _loadAccountData();
            },
            child: Text(create ? 'إنشاء' : 'دخول'),
          ),
        ],
      ),
    );
    controller.dispose();
    password.dispose();
  }

  Future<void> _clearData({required bool savedOnly}) async {
    final p = await SharedPreferences.getInstance();
    if (savedOnly) {
      await p.remove('saved');
    } else {
      await p.remove('history');
      await p.remove('watch_history');
      await p.remove('recent');
    }
    await _loadAccountData();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(savedOnly ? 'تم مسح المفضلة' : 'تم مسح سجل المشاهدة'),
        ),
      );
    }
  }

  Future<void> _confirmClear({required bool savedOnly}) async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: panel,
        title: Text(savedOnly ? 'مسح المفضلة؟' : 'مسح سجل المشاهدة؟'),
        content: const Text('لا يمكن التراجع عن هذا الإجراء بعد تأكيده.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              _clearData(savedOnly: savedOnly);
            },
            child: const Text('مسح الآن'),
          ),
        ],
      ),
    );
  }

  Widget tile({
    required IconData icon,
    required String title,
    String? subtitle,
    VoidCallback? onTap,
    Color? iconColor,
  }) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
    leading: Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: (iconColor ?? red).withOpacity(.14),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(icon, color: iconColor ?? red, size: 21),
    ),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
    subtitle: subtitle == null
        ? null
        : Text(subtitle, style: const TextStyle(color: Colors.white54)),
    trailing: onTap == null
        ? null
        : const Icon(Icons.chevron_right, color: Colors.white38),
    onTap: onTap,
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: bg,
    appBar: AppBar(
      backgroundColor: bg,
      elevation: 0,
      title: const Text(
        'الإعدادات',
        style: TextStyle(fontWeight: FontWeight.w800),
      ),
    ),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [red.withOpacity(.95), const Color(0xff8d1821)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Row(
            children: [
              GestureDetector(
                onTap: _pickAvatar,
                child: CircleAvatar(
                  radius: 28,
                  backgroundColor: Colors.white24,
                  backgroundImage:
                      _avatarPath.isNotEmpty && File(_avatarPath).existsSync()
                      ? FileImage(File(_avatarPath))
                      : null,
                  child: _avatarPath.isEmpty || !File(_avatarPath).existsSync()
                      ? const Icon(
                          Icons.add_a_photo_outlined,
                          color: Colors.white,
                          size: 25,
                        )
                      : null,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _signedIn && _accountName.isNotEmpty
                          ? _accountName
                          : 'مرحبًا بك في AFVeo',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _signedIn
                          ? 'حسابك متصل'
                          : 'سجّل الدخول لحفظ تجربتك ومزامنتها',
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                icon: const Icon(Icons.more_vert),
                onSelected: (value) {
                  if (value == 'login') _showAccountDialog(create: false);
                  if (value == 'create') _showAccountDialog(create: true);
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'login', child: Text('تسجيل الدخول')),
                  PopupMenuItem(value: 'create', child: Text('إنشاء حساب')),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const _MenuLabel('حسابك'),
        const SizedBox(height: 8),
        Card(
          color: panel,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: Colors.white.withOpacity(.08)),
          ),
          child: Column(
            children: [
              tile(
                icon: Icons.login_rounded,
                title: 'تسجيل الدخول',
                subtitle: 'الوصول إلى حسابك',
                onTap: () => _showAccountDialog(create: false),
              ),
              const Divider(height: 1, color: Colors.white10),
              tile(
                icon: Icons.person_add_alt_1_rounded,
                title: 'إنشاء حساب',
                subtitle: 'أنشئ حسابًا جديدًا في AFVeo',
                onTap: () => _showAccountDialog(create: true),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const _MenuLabel('مكتبتك'),
        const SizedBox(height: 8),
        Card(
          color: panel,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: Colors.white.withOpacity(.08)),
          ),
          child: Column(
            children: [
              tile(
                icon: Icons.download_rounded,
                title: 'التحميلات',
                subtitle: 'ستتوفر هنا الأفلام المحمّلة مستقبلًا',
                onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('قسم التحميلات قيد التجهيز')),
                ),
              ),
              const Divider(height: 1, color: Colors.white10),
              tile(
                icon: Icons.history_rounded,
                title: 'تمت مشاهدته مؤخرًا',
                subtitle: '$_historyCount عنصرًا محفوظًا',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const RecentWatchedPage()),
                ),
              ),
              const Divider(height: 1, color: Colors.white10),
              tile(
                icon: Icons.bookmark_rounded,
                title: 'المفضلة',
                subtitle: '$_savedCount فيلمًا أو مسلسلًا',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const Shell(initialIndex: 4),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const _MenuLabel('إدارة البيانات'),
        const SizedBox(height: 8),
        Card(
          color: panel,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: Colors.white.withOpacity(.08)),
          ),
          child: Column(
            children: [
              tile(
                icon: Icons.history_rounded,
                title: 'تمت مشاهدته مؤخرًا',
                subtitle: 'فتح قائمة الأعمال التي شاهدتها مؤخرًا',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const RecentWatchedPage()),
                ),
              ),
              const Divider(height: 1, color: Colors.white10),
              tile(
                icon: Icons.delete_outline_rounded,
                iconColor: Colors.orangeAccent,
                title: 'مسح المفضلة',
                subtitle: 'حذف كل الأفلام والمسلسلات المحفوظة',
                onTap: () => _confirmClear(savedOnly: true),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const _MenuLabel('التطبيق'),
        const SizedBox(height: 8),
        Card(
          color: panel,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: Colors.white.withOpacity(.08)),
          ),
          child: Column(
            children: [
              tile(
                icon: Icons.info_outline_rounded,
                title: 'الإصدار',
                subtitle: 'AFVeo 1.9.0',
              ),
              const Divider(height: 1, color: Colors.white10),
              tile(
                icon: Icons.campaign_outlined,
                title: 'الإعلانات والتنبيهات',
                subtitle: 'تدار من لوحة الإدارة المركزية',
              ),
              const Divider(height: 1, color: Colors.white10),
              tile(
                icon: Icons.support_agent_rounded,
                title: 'الدعم والتواصل',
                subtitle: 'تابع آخر الأخبار والمساعدة',
                onTap: () async {
                  final link = '${AdminRuntime.social['telegram'] ?? ''}'
                      .trim();
                  if (link.isNotEmpty)
                    await launchUrl(
                      Uri.parse(link),
                      mode: LaunchMode.externalApplication,
                    );
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        Center(
          child: Text(
            'AFVeo • مشاهدة ممتعة',
            style: TextStyle(color: Colors.white38, fontSize: 12),
          ),
        ),
      ],
    ),
  );
}

class ApiDebugPage extends StatefulWidget {
  const ApiDebugPage({super.key});

  @override
  State<ApiDebugPage> createState() => _ApiDebugPageState();
}

class _ApiDebugPageState extends State<ApiDebugPage> {
  @override
  Widget build(BuildContext context) {
    final entries = List<ApiDebugEntry>.from(apiDebugLog);
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('تشخيص API'),
        actions: [
          IconButton(
            tooltip: 'مسح السجل',
            icon: const Icon(Icons.delete_outline),
            onPressed: () => setState(() => apiDebugLog.clear()),
          ),
        ],
      ),
      body: entries.isEmpty
          ? const Center(
              child: Text(
                'لا توجد استجابات بعد',
                style: TextStyle(color: Colors.white70),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: entries.length,
              itemBuilder: (_, i) {
                final e = entries[i];
                final statusColor = e.statusCode >= 200 && e.statusCode < 300
                    ? Colors.greenAccent
                    : Colors.redAccent;
                return Card(
                  color: const Color(0xff171717),
                  child: ExpansionTile(
                    title: Text(
                      '${e.operation} — HTTP ${e.statusCode}',
                      style: TextStyle(color: statusColor),
                    ),
                    subtitle: Text(
                      e.contentType.isEmpty ? e.url : e.contentType,
                      style: const TextStyle(
                        color: Colors.white60,
                        fontSize: 11,
                      ),
                    ),
                    childrenPadding: const EdgeInsets.all(12),
                    children: [
                      SelectableText(
                        'URL: ${e.url}\n\nHeaders:\n${e.headers.entries.map((x) => '${x.key}: ${x.value}').join('\n')}\n\nBody:\n${e.bodyPreview}',
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
