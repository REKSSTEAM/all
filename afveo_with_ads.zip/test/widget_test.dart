import 'package:flutter_test/flutter_test.dart';
import 'package:afveo/main.dart';

void main() {
  testWidgets('AFVeo app starts', (tester) async {
    await tester.pumpWidget(const App());
    expect(find.text('AFVeo'), findsWidgets);
  });
}
